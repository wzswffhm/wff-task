License
=======

.. literalinclude:: ../LICENSE
