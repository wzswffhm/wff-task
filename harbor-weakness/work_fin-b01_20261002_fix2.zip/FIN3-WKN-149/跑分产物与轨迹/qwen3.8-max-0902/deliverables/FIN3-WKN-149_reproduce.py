#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FIN3-WKN-149 「多资产稳健配置专户」三季度宏观压力测试与调仓建议 —— 可复算代码
================================================================================
运行方式 : python3 FIN3-WKN-149_reproduce.py
输入     : /app/input_files/ （只读，27 个市场快照 CSV + 参数/方案/规则/模板文件）
输出     : stdout 打印备忘录全部数字；/app/output/FIN3-WKN-149_charts/ 下生成 10 张 PNG。
分析截至日: 2026-09-15（组合净值 10,000 万元）

关键口径（均在备忘录第二章中说明，代码不硬编码任何结论数值）：
 (1) 三个 A 股指数文件中落在上交所非交易日的记录判定为异常记录并剔除（实际识别出
     2026-09-12 周六 2 条：OHLC 全等于 pre_close、成交额仅为邻日均量的约 2%、交易日历
     无该日、同期创业板指数文件无该日记录）。银行间/离岸/美股序列的历外记录属于跨市场
     交易日历差异（如调休补班日银行间开市），保留并采用“最近可得观测”原则对齐。
 (2) 对齐：全部跨市场序列先对齐到上交所估值日（当日无观测时前向填充最近观测）；
     序列覆盖起点之前 / 终点之后为结构性空值，不参与填充、不按 0 计算。
 (3) 组合收益样本区间 = 全部收益成分可用的公共区间：
     起点取 DR007 首个有效日（人民币现金按 DR007 计息所需），终点取中债收益率曲线
     截断日（国债久期折算所需）。
 (4) 资产收益：A 股指数 = 收盘价简单收益；国债组合 = -Σ(关键期限久期贡献×收益率变动)，
     收益率以小数计；标普500 人民币收益 = (1+r_SPX,USD)×(1+r_USDCNH)-1（复合，不用加法）；
     美元现金 = USD/CNH 重估收益（输入中无覆盖全样本的美元存款利率序列，与委员会冲击
     参数中美元现金仅含汇率冲击的口径一致）；人民币现金 = DR007/243 逐日计息。
 (5) 组合日收益 = Σ(方案权重×资产日收益)，每日再平衡（恒定权重）。年化系数 243。
 (6) params_committee_shocks.csv 的 cgb_shock_bp 列数值按“百分点”口径采用
     （+0.10 = +0.10% = +10bp）。理由：若按字面 bp（+0.10bp）则国债贡献≈0，与
     “久期折算”要求矛盾，且与历史校准冲击（10 日累计变动中位数，量级 ±30bp）不可比。
 (7) 历史窗口选取级联（rules_windows.csv）：一级规则“窗口内 10 日组合日收益全部为负”
     在样本内无解（0 个），据同条规则第二句操作化为：按累计跌幅排序，二级取“累计收益
     为负”的最差窗口（≤20 个）；S4 无任何累计为负窗口，三级取全部候选窗口并如实披露。
 (8) 校准冲击 = 全部保留窗口内各风险因子 10 个交易日累计变动的中位数
     （基期 = 窗口首日前一个上交所交易日）。
 (9) 风险指标：历史模拟法。1 日 VaR_q = -分位数(r, 1-q)；1 日 ES_q = 尾部（≤VaR 分位）
     均值取负；10 日 VaR99 基于重叠 10 日复利累计收益分布的 1% 分位。
(10) 反向压力测试：10 日风险因子向量 x=(三指数收益, SPX美元收益, USDCNH变动, 五期限Δy)，
     损失线性化 L(x)=a'x（SPX 人民币收益近似 r_SPX+r_FX），马氏距离 d(x)=sqrt(x'Σ⁻¹x)，
     Σ 为样本内重叠 10 日累计变动的协方差阵（以零冲击为基准中心），用伪逆。
     给定目标损失 L*，最小距离解 x* = L*·Σa/(a'Σa)，d* = |L*|/sqrt(a'Σa)。
"""
import os, sys, json, warnings
import numpy as np
import pandas as pd

warnings.filterwarnings('ignore')
pd.set_option('display.width', 320)
pd.set_option('display.max_rows', 900)
pd.set_option('display.max_columns', 60)

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
plt.rcParams['font.sans-serif'] = ['Noto Sans CJK SC', 'Noto Sans CJK JP', 'WenQuanYi Zen Hei']
plt.rcParams['axes.unicode_minus'] = False

IN = '/app/input_files'
OUT = '/app/output'
CH = os.path.join(OUT, 'FIN3-WKN-149_charts')
os.makedirs(CH, exist_ok=True)
CUTOFF = pd.Timestamp('2026-09-15')     # 分析截至日（来自任务口径，与快照末端一致）
NAV = 10000.0                            # 组合净值（万元）
AF = 243                                 # 年化系数（上交所年均交易日）
TENORS = [1, 2, 5, 10, 30]

def sec(title):
    print('\n' + '=' * 100)
    print(title)
    print('=' * 100)

def pct(x, nd=2):   return f"{x*100:.{nd}f}%"
def bp(x, nd=2):    return f"{x*10000:.{nd}f}bp"
def wan(x, nd=2):   return f"{x:,.{nd}f}万元"

# ============================================================================
# 0. 读取参数 / 方案 / 规则文件
# ============================================================================
hold   = pd.read_csv(f'{IN}/params_holdings.csv')
pos    = pd.read_csv(f'{IN}/params_positions.csv')
limits = pd.read_csv(f'{IN}/params_limits.csv')
dur    = pd.read_csv(f'{IN}/params_duration.csv')
comm_sh= pd.read_csv(f'{IN}/params_committee_shocks.csv')
plans  = pd.read_csv(f'{IN}/plans_candidates.csv')
r_scen = pd.read_csv(f'{IN}/rules_scenarios.csv')
r_win  = pd.read_csv(f'{IN}/rules_windows.csv')
r_chk  = pd.read_csv(f'{IN}/rules_checks.csv')
r_reb  = pd.read_csv(f'{IN}/rules_rebalance.csv')
manifest = pd.read_csv(f'{IN}/snapshot_data_manifest.csv')

DUR_MAP = {'1年': 1, '2年': 2, '5年': 5, '10年': 10, '30年': 30}
Dc = {DUR_MAP[r.tenor]: r.duration_contribution for r in dur.itertuples()}
DUR_TOTAL = sum(Dc.values())

COLS = ['EQ_000300', 'EQ_000905', 'EQ_399006', 'CGB', 'USD_CASH', 'SPX', 'CNY_CASH']
h = hold.set_index('asset_class')
W = {'当前组合': h.weight_current.reindex(COLS).values.astype(float),
     '推荐方案': h.weight_recommended.reindex(COLS).values.astype(float)}
for r in plans.itertuples():
    W[r.plan_id] = np.array([r.w_000300, r.w_000905, r.w_399006, r.w_cgb,
                             r.w_usd_cash, r.w_spx_qdii, r.w_cny_cash], dtype=float)
PLAN_ORDER = ['当前组合', '方案A', '方案B', '方案C', '推荐方案']

# ============================================================================
# 1. 交易日历与数据装载（含异常记录识别）
# ============================================================================
cal = pd.read_csv(f'{IN}/snapshot_trade_calendar.csv', parse_dates=['date'])
assert (cal.is_trading_day == 1).all()
td = pd.DatetimeIndex(sorted(cal.date))
TDSET = set(td)

def load_raw(files):
    df = pd.concat([pd.read_csv(f'{IN}/{f}', parse_dates=['date']) for f in files])
    return df.sort_values('date').reset_index(drop=True)

FILES = {
    'EQ300' : (['snapshot_000300SH_seg1.csv', 'snapshot_000300SH_seg2.csv'], 'close'),
    'EQ900' : (['snapshot_000905SH_seg1.csv', 'snapshot_000905SH_seg2.csv'], 'close'),
    'GEM'   : (['snapshot_399006SZ_seg1.csv', 'snapshot_399006SZ_seg2.csv'], 'close'),
    'USD'   : (['snapshot_usdcnh_seg1.csv', 'snapshot_usdcnh_seg2.csv'], 'usdcnh'),
    'SPX'   : (['snapshot_spx.csv'], 'close'),
    'DR007' : (['snapshot_dr007.csv'], 'dr007'),
    'SHIBOR': (['snapshot_shibor_seg1.csv', 'snapshot_shibor_seg2.csv'], 'shibor_on'),
    'UST10' : (['snapshot_ust_10y.csv'], 'yield_pct'),
    'USTM2' : (['snapshot_ust_m2.csv'], 'yield_pct'),
    'USTM4' : (['snapshot_ust_m4.csv'], 'yield_pct'),
    'CGB1'  : (['snapshot_cgb_yield_1y.csv'], 'yield_pct'),
    'CGB2'  : (['snapshot_cgb_yield_2y.csv'], 'yield_pct'),
    'CGB5'  : (['snapshot_cgb_yield_5y.csv'], 'yield_pct'),
    'CGB10' : (['snapshot_cgb_yield_10y.csv'], 'yield_pct'),
    'CGB30' : (['snapshot_cgb_yield_30y.csv'], 'yield_pct'),
    'LPR1'  : (['snapshot_lpr_1y.csv'], 'lpr_1y'),
    'LPR5'  : (['snapshot_lpr_5y.csv'], 'lpr_5y'),
    'PMI'   : (['snapshot_pmi_manufacturing.csv'], 'pmi_mfg'),
    'PPI'   : (['snapshot_ppi_yoy.csv'], 'ppi_yoy'),
    'AFRE'  : (['snapshot_afre_stock.csv'], 'afre_stock'),
}
RAW = {k: load_raw(v[0]) for k, v in FILES.items()}

sec('第一部分 数据核验（第二章素材）——1.1 清单交叉核对（manifest 与实际文件内容）')
man_rows = []
for r in manifest.itertuples():
    df = pd.read_csv(f'{IN}/{r.file}', parse_dates=['date'])
    ok_n = len(df) == r.records
    ok_s = df.date.min().date() == pd.Timestamp(r.start).date()
    ok_e = df.date.max().date() == pd.Timestamp(r.end).date()
    man_rows.append((r.file, r.records, len(df), r.start, str(df.date.min().date()),
                     r.end, str(df.date.max().date()),
                     '一致' if (ok_n and ok_s and ok_e) else '不一致',
                     r.possible_truncation if pd.notna(r.possible_truncation) else '(空)'))
man = pd.DataFrame(man_rows, columns=['文件', '清单行数', '实际行数', '清单起', '实际起',
                                      '清单止', '实际止', '核对', 'truncation标记'])
print(man.to_string(index=False))
print('\n结论：清单与实际文件的行数/起止日全部一致；possible_truncation 标记几乎全为空，')
print('但按内容核验，中债收益率曲线 5 条序列实际止于 2026-06-09，早于分析截至日 2026-09-15，')
print('属实质性截断——以文件实际内容为准。')

sec('1.2 休市日异常记录识别（A 股指数文件）')
anomalies = []
for k in ['EQ300', 'EQ900', 'GEM']:
    df = RAW[k]
    off = df[~df.date.isin(TDSET)]
    for r in off.itertuples():
        amt20 = df[(df.date < r.date)].amount.tail(20).mean()
        anomalies.append(dict(序列=k, 日期=str(r.date.date()), 星期=r.date.day_name(),
                              open=r.open, high=r.high, low=r.low, close=r.close,
                              pre_close=r.pre_close, 成交额=r.amount,
                              前20日均额=amt20, 额比=r.amount / amt20,
                              OHLC是否全等于pre_close=(r.open == r.high == r.low == r.close == r.pre_close)))
anom = pd.DataFrame(anomalies)
print(anom.to_string(index=False))
print('\n识别依据：①日期不在上交所交易日历（2026-09-12 为周六，且非调休补班日——银行间/资金面');
print('序列该日均无记录）；②OHLC 五价全等于 pre_close（无波动）；③成交额仅为前 20 日均额的约 2%；')
print('④同期创业板指数 seg2 文件无该日记录（行数 898 恰为剔除后的一致行数）。处理：整行剔除，共 2 条。')
for k in ['EQ300', 'EQ900', 'GEM']:
    RAW[k] = RAW[k][RAW[k].date.isin(TDSET)].reset_index(drop=True)

sec('1.3 各序列覆盖区间 / 历外记录 / 内部缺口 / 结构性空值')
audit_rows = []
for k, (fl, col) in FILES.items():
    df = pd.concat([pd.read_csv(f'{IN}/{f}', parse_dates=['date']) for f in fl]).sort_values('date')
    n0 = len(df)
    off = int((~df.date.isin(TDSET)).sum())
    on = df[df.date.isin(TDSET)]
    nan = int(df[col].isna().sum())
    lo, hi = df.date.min(), df.date.max()
    lo_v, hi_v = df.dropna(subset=[col]).date.min(), df.dropna(subset=[col]).date.max()
    expect = td[(td >= lo_v) & (td <= hi_v)]
    internal_gap = int((~pd.DatetimeIndex(expect).isin(set(on.date))).sum())
    audit_rows.append(dict(序列=k, 原始行数=n0, 历外记录=off, 空值=nan,
                           覆盖起=str(lo_v.date()), 覆盖止=str(hi_v.date()),
                           覆盖内应有SSE日=len(expect), 覆盖内缺失=internal_gap,
                           止于截至日=('是' if hi_v == CUTOFF else f'否(缺{(CUTOFF-hi_v).days}天)')))
audit = pd.DataFrame(audit_rows)
print(audit.to_string(index=False))
print('\n说明：历外记录=落在上交所非交易日的记录。A股指数的历外记录为异常（已剔除）；银行间(CGB/DR007/')
print('SHIBOR/LPR)、离岸(USD)、美股(SPX/UST)序列的历外记录为调休补班日或境外交易日，属正常日历差异，')
print('对齐时按“最近可得观测”处理。内部缺口=序列覆盖区间内应有而上交所日无观测的天数（跨市场假日），')
print('对齐时前向填充；覆盖区间之外为结构性空值，不填充、不按 0 计算。')
print('结构性空值：LPR5Y 在 2019-08-20（首次发布）之前 406 行为空；各指数 seg1 首日 pre_close 为空（未使用）。')
print('月度序列缺失：PMI 缺 2026-08 月；AFRE 止于 2026-04；PPI 止于 2026-08；LPR1 止于 2026-07-20；')
print('LPR5 止于 2026-08-20；CGB 五期限止于 2026-06-09。')

# ============================================================================
# 2. 对齐至上交所估值日 + 收益构建
# ============================================================================
def align(df, col):
    s = df.set_index('date')[col].astype(float)
    s = s[~s.index.duplicated(keep='last')].sort_index()
    full = s.reindex(s.index.union(td)).sort_index().ffill()
    out = full.reindex(td)
    out[td < s.index.min()] = np.nan   # 覆盖起点前：结构性空值
    out[td > s.index.max()] = np.nan   # 覆盖终点后：结构性空值（禁止前向填充）
    return out

LVL = {k: align(RAW[k], FILES[k][1]) for k in FILES}
CGB = {t: LVL[f'CGB{t}'] for t in TENORS}

dy = {t: CGB[t].diff() / 100.0 for t in TENORS}          # 收益率变动（小数）
r_cgb = sum(-Dc[t] * dy[t] for t in TENORS)               # 久期折算，禁止简单加总
r_spx_usd = LVL['SPX'].pct_change()
r_usd = LVL['USD'].pct_change()
r_spx_cny = (1 + r_spx_usd) * (1 + r_usd) - 1             # 复合折算，禁止加法近似
RET = pd.DataFrame({'EQ_000300': LVL['EQ300'].pct_change(),
                    'EQ_000905': LVL['EQ900'].pct_change(),
                    'EQ_399006': LVL['GEM'].pct_change(),
                    'CGB': r_cgb,
                    'USD_CASH': r_usd,
                    'SPX': r_spx_cny,
                    'CNY_CASH': LVL['DR007'] / 100.0 / AF}, index=td)

starts = [RET[c].first_valid_index() for c in COLS]
ends = [RET[c].last_valid_index() for c in COLS]
S0, S1_ = max(starts), min(ends)
sample = td[(td >= S0) & (td <= S1_)]
R = RET.loc[sample, COLS]
assert R.notna().all().all(), '样本区间内存在未处理空值'

sec('第二部分 样本区间（第二章素材）')
print(f'交易日历：{td[0].date()} ~ {td[-1].date()}，上交所交易日共 {len(td)} 个；分析截至日 {CUTOFF.date()}。')
print(f'组合收益样本区间：{S0.date()} ~ {S1_.date()}，共 {len(sample)} 个交易日（收益观测 {len(R)} 个）。')
print(f'  起点原因：DR007/SHIBOR 导出自 {LVL["DR007"].first_valid_index().date()} 起（人民币现金计息所需）；')
print(f'  终点原因：中债国债收益率曲线（1/2/5/10/30Y）截断于 {LVL["CGB10"].last_valid_index().date()}，')
print(f'            其后 {int((td > S1_).sum())} 个交易日无国债估值，结构性空值不得填充或按 0 计算。')
print(f'  样本区间之前 {int((td < S0).sum())} 个交易日、之后 {int((td > S1_).sum())} 个交易日不参与组合收益计算。')

# ============================================================================
# 3. 当前组合风险画像（第三章）
# ============================================================================
from numpy.lib.stride_tricks import sliding_window_view

def roll10(rp):
    return sliding_window_view(1.0 + rp, 10).prod(axis=1) - 1.0

def risk_metrics(rp, idx):
    nav = np.cumprod(1 + rp)
    peak = np.maximum.accumulate(nav)
    dd = nav / peak - 1
    q01, q05 = np.quantile(rp, 0.01), np.quantile(rp, 0.05)
    es99 = -rp[rp <= q01].mean(); es95 = -rp[rp <= q05].mean()
    r10 = roll10(rp); r10_idx = idx[9:]
    var99_10 = -np.quantile(r10, 0.01)
    i_tr = int(np.argmin(dd)); i_pk = int(np.argmax(nav[:i_tr + 1]))
    rec = np.where(nav[i_tr:] >= nav[i_pk])[0]
    i_rec = i_tr + rec[0] if len(rec) else None
    i10 = int(np.argmin(r10))
    return dict(annvol=rp.std(ddof=1) * np.sqrt(AF), annret=nav[-1] ** (AF / len(rp)) - 1,
                var95=-q05, var99=-q01, es95=es95, es99=es99,
                var99_10=var99_10, worst10=r10.min(),
                worst10_start=idx[i10], worst10_end=r10_idx[i10],
                maxdd=dd.min(), mdd_peak=idx[i_pk], mdd_trough=idx[i_tr],
                mdd_recov=idx[i_rec] if i_rec is not None else None,
                worst1d=rp.min(), worst1d_date=idx[int(np.argmin(rp))],
                nav_end=nav[-1], nav=nav, r10=r10, r10_idx=r10_idx, rp=rp)

sec('第三部分 当前组合风险画像（第三章素材）')
print('当前持仓（params_positions.csv / params_holdings.csv）：')
posv = pos.copy()
print(posv.to_string(index=False))
print(f'净值 {NAV:,.0f} 万元；权益合计 {pct(W["当前组合"][:3].sum())}。')

M = {name: risk_metrics(R.values @ w, sample) for name, w in W.items()}

print('\n各资产日收益统计特征（样本区间）：')
stat = pd.DataFrame({'均值bp/日': R.mean() * 1e4, '标准差%': R.std(ddof=1) * 100,
                     '年化波动%': R.std(ddof=1) * np.sqrt(AF) * 100,
                     '偏度': R.skew(), '峰度': R.kurt(),
                     '最小%': R.min() * 100, '最大%': R.max() * 100}).round(3)
print(stat.to_string())
print('\n相关系数矩阵：')
print(R.corr().round(3).to_string())

print('\n组合层面指标（各方案，每日再平衡）：')
rows = []
for name in PLAN_ORDER:
    m = M[name]
    rows.append(dict(组合=name, 年化波动=pct(m['annvol']), 年化收益=pct(m['annret']),
                     VaR95_1d=pct(m['var95']), VaR99_1d=pct(m['var99']),
                     ES95_1d=pct(m['es95']), ES99_1d=pct(m['es99']),
                     VaR99_10d=pct(m['var99_10']),
                     最差10日=pct(m['worst10']), 最差10日区间=f"{m['worst10_start'].date()}~{m['worst10_end'].date()}",
                     最大回撤=pct(m['maxdd']),
                     回撤区间=f"{m['mdd_peak'].date()}~{m['mdd_trough'].date()}",
                     修复日=(m['mdd_recov'].date().isoformat() if m['mdd_recov'] is not None else '未修复'),
                     最差单日=pct(m['worst1d']), 单日日期=str(m['worst1d_date'].date()),
                     期末净值=round(m['nav_end'], 4)))
print(pd.DataFrame(rows).to_string(index=False))

cov = np.cov(R.values.T)
print('\n当前组合各资产风险贡献占比（Euler 分解）：')
for name in PLAN_ORDER[:1] + ['推荐方案']:
    w = W[name]; cr = cov @ w; rc = w * cr / (w @ cr)
    print(f"  {name}: " + ', '.join(f'{c}={rc[i]*100:.1f}%' for i, c in enumerate(COLS)))

# ============================================================================
# 4. 情景月度识别（第四章）
# ============================================================================
def month_end(s):
    x = s.dropna(); return x.groupby(x.index.to_period('M')).last()
def month_mean(s):
    x = s.dropna(); return x.groupby(x.index.to_period('M')).mean()

me300, mspx, musd = month_end(LVL['EQ300']), month_end(LVL['SPX']), month_end(LVL['USD'])
ret300_m = me300.pct_change(); retspx_m = mspx.pct_change(); chgusd_m = musd.pct_change()
mean10y_m = month_mean(LVL['CGB10']); meandr_m = month_mean(LVL['DR007'])

pmi = RAW['PMI'].set_index('date').pmi_mfg; pmi.index = pmi.index.to_period('M')
ppi = RAW['PPI'].set_index('date').ppi_yoy;  ppi.index = ppi.index.to_period('M')
afre = RAW['AFRE'].set_index('date').afre_stock; afre.index = afre.index.to_period('M')
afre_yoy = afre / afre.shift(12) - 1

def monthly_lpr(df, col):
    s = df.dropna().set_index('date')[col].sort_index()
    pr = pd.period_range(s.index.min().to_period('M'), s.index.max().to_period('M'), freq='M')
    return s.groupby(s.index.to_period('M')).last().reindex(pr).ffill()
ml1, ml5 = monthly_lpr(RAW['LPR1'], 'lpr_1y'), monthly_lpr(RAW['LPR5'], 'lpr_5y')
cut1, cut5 = ml1.diff() < 0, ml5.diff() < 0     # 当月下调 = 当月最后一个观测低于上月末

ALLM = pd.period_range('2018-01', '2026-09', freq='M')
def gv(s, M):
    try:
        v = s.get(M, np.nan)
        return None if pd.isna(v) else float(v)
    except Exception:
        return None

rows1 = []
for mo in ALLM:
    p, pp = gv(pmi, mo), gv(pmi, mo - 1)
    y, yp = gv(mean10y_m, mo), gv(mean10y_m, mo - 1)
    c1 = gv(cut1, mo); c5 = gv(cut5, mo)
    cuts = [x for x in (c1, c5) if x is not None]
    b1_eval = (p is not None) and len(cuts) > 0
    b1 = b1_eval and (p < 50) and any(cuts)
    b2_eval = all(v is not None for v in (p, pp, y, yp))
    b2 = b2_eval and (pp - p >= 0.5) and (y < yp)
    qual = bool(b1 or b2)
    if qual: st, why = '合格', ('PMI<50且LPR下调' if b1 else '') + ('|' if b1 and b2 else '') + ('PMI降≥0.5且10Y月均下行' if b2 else '')
    elif b1_eval and b2_eval: st, why = '不合格', ''
    else: st, why = '不可判定', ''
    rows1.append((str(mo), p, (any(cuts) if cuts else None), y, st, why.strip('|')))
S1 = pd.DataFrame(rows1, columns=['month', 'pmi', 'lpr_cut', 'y10_mean', 'status', 'why'])

rows2 = []
for mo in ALLM:
    a, ap_, y, yp, r = gv(ppi, mo), gv(ppi, mo - 1), gv(mean10y_m, mo), gv(mean10y_m, mo - 1), gv(ret300_m, mo)
    if any(v is None for v in (a, ap_, y, yp, r)): rows2.append((str(mo), '不可判定')); continue
    rows2.append((str(mo), '合格' if (a > ap_ and y > yp and r < 0) else '不合格'))
S2 = pd.DataFrame(rows2, columns=['month', 'status'])

rows3 = []
for mo in ALLM:
    rs, rc = gv(retspx_m, mo), gv(chgusd_m, mo)
    if rs is None and rc is None: rows3.append((str(mo), '不可判定', '', rs, rc)); continue
    t1 = rs is not None and rs <= -0.03; t2 = rc is not None and rc >= 0.015
    st = '合格' if (t1 or t2) else ('不合格' if (rs is not None and rc is not None) else '不可判定')
    rows3.append((str(mo), st, '|'.join([x for x, f in [('SPX≤-3%', t1), ('FX≥+1.5%', t2)] if f]), rs, rc))
S3 = pd.DataFrame(rows3, columns=['month', 'status', 'why', 'ret_spx', 'chg_usd'])

rows4 = []
for mo in ALLM:
    ay, ap_, dm, dp, r = gv(afre_yoy, mo), gv(afre_yoy, mo - 1), gv(meandr_m, mo), gv(meandr_m, mo - 1), gv(ret300_m, mo)
    if any(v is None for v in (ay, ap_, dm, dp, r)): rows4.append((str(mo), '不可判定')); continue
    rows4.append((str(mo), '合格' if (ay < ap_ and dm > dp and r < 0) else '不合格'))
S4 = pd.DataFrame(rows4, columns=['month', 'status'])
SC = {'S1': S1, 'S2': S2, 'S3': S3, 'S4': S4}

sec('第四部分 情景月度识别结果（第四章素材）')
for r_ in r_scen.itertuples():
    print(f"  {r_.scenario_id} {r_.scenario}: {r_.rule}")
print('（“权益指数当月下跌”以沪深300当月收益<0 为准；月度值按日期所在月归属；2026-09 为截至 09-15 的月内数据。）')
for sid, df in SC.items():
    q = df[df.status == '合格']
    n_un = int((df.status == '不可判定').sum())
    un_months = df.loc[df.status == '不可判定', 'month'].tolist()
    print(f"\n{sid}: 合格 {len(q)} 个月；不可判定 {n_un} 个月")
    print('  合格月份:', ', '.join(q.month.tolist()))
    if sid == 'S1':
        print('  触发分支:', '; '.join(f"{r_.month}({r_.why})" for r_ in q.itertuples()))
    if sid == 'S3':
        print('  触发原因:', '; '.join(f"{r_.month}({r_.why})" for r_ in q.itertuples()))
    print('  不可判定月份:', ', '.join(un_months[:30]), '...' if n_un > 30 else '')
print('\n不可判定成因：2018 年 PMI/PPI/AFRE 同比及 DR007 尚未起算（缺上月或前 12 个月基期）；')
print('2026-05 之后 AFRE 缺失（S4）；2026-07 之后中债收益率缺失（S1 分支2 / S2）；2026-08 PMI 缺失（S1）；')
print('2026-08/09 LPR 未导出（S1 分支1）。上述月份按“不可判定”处理，不计入合格月份。')

# ============================================================================
# 5. 历史窗口与校准冲击（第四章）
# ============================================================================
rp_cur = M['当前组合']['rp']
tdlist = list(td); cgb_end = LVL['CGB10'].last_valid_index(); samp0 = sample[0]

def make_windows(qual_months):
    out = []
    for ms in qual_months:
        nxt = (pd.Period(ms) + 1).start_time
        idx = [i for i, d in enumerate(tdlist) if d >= nxt]
        if len(idx) == 0:
            out.append(dict(month=ms, start=None, end=None, base=None, note='无后续交易日')); continue
        i0 = idx[0]
        if i0 + 9 >= len(tdlist):
            out.append(dict(month=ms, start=tdlist[i0], end=None, base=None, note='窗口不足10个交易日')); continue
        wdays = tdlist[i0:i0 + 10]; base = tdlist[i0 - 1]
        if wdays[-1] > cgb_end:
            out.append(dict(month=ms, start=wdays[0], end=wdays[-1], base=base, note='超出国债曲线覆盖(2026-06-09)，剔除')); continue
        if wdays[0] < samp0:
            out.append(dict(month=ms, start=wdays[0], end=wdays[-1], base=base,
                            note=f'早于组合收益样本起点({samp0.date()})，剔除')); continue
        out.append(dict(month=ms, start=wdays[0], end=wdays[-1], base=base, note=''))
    return out

def window_stats(w):
    r = rp_cur[(sample >= w['start']) & (sample <= w['end'])]
    w['cum'] = float(np.prod(1 + r) - 1); w['negdays'] = int((r < 0).sum())
    w['allneg'] = bool((r < 0).all()); return w

def factor_change(base, end):
    f = {}
    for k, c in [('EQ300', 'EQ_000300'), ('EQ900', 'EQ_000905'), ('GEM', 'EQ_399006'), ('SPX', 'SPX_usd')]:
        f[c] = LVL[k].loc[end] / LVL[k].loc[base] - 1
    f['USDCNH'] = LVL['USD'].loc[end] / LVL['USD'].loc[base] - 1
    for t in TENORS:
        f[f'DY{t}bp'] = (LVL[f'CGB{t}'].loc[end] - LVL[f'CGB{t}'].loc[base]) * 100
    return f

WIN, CALIB = {}, {}
sec('第五部分 历史窗口选取与校准冲击（第四章素材）')
for sid, df in SC.items():
    cands = [window_stats(w) for w in make_windows(df[df.status == '合格'].month.tolist())]
    cdf = pd.DataFrame(cands)
    ok = cdf[cdf.note == ''].copy()
    tier1 = ok[ok.allneg]
    tier2 = ok[ok.cum < 0].sort_values('cum')
    if len(tier1) > 0:
        keep, tier = tier1.sort_values('cum').head(20), f'一级（10日全负）：{len(tier1)}个'
    elif len(tier2) > 0:
        keep, tier = tier2.head(20), f'二级（累计为负，按跌幅排序取前≤20）：{len(tier2)}个中取{min(len(tier2),20)}个'
    else:
        keep, tier = ok.sort_values('cum'), f'三级（无累计为负窗口，取全部候选{len(ok)}个）'
    WIN[sid] = (cdf, keep, tier)
    fc = pd.DataFrame([factor_change(r.base, r.end) for r in keep.itertuples()])
    CALIB[sid] = fc.median()
    print(f'\n===== {sid} =====')
    print(cdf[['month', 'start', 'end', 'cum', 'negdays', 'allneg', 'note']].to_string(index=False))
    print(f'级联选取：一级(10日全负)={len(tier1)}个 -> {tier}')
    print(f'保留窗口（{len(keep)}个）: ' + ', '.join(f"{r.month}[{r.start.date()}~{r.end.date()}]" for r in keep.itertuples()))
    print('窗口内因子累计变动：')
    print(fc.round(4).to_string())
    print('校准冲击（中位数）:', {k: round(v, 4) for k, v in CALIB[sid].items()})

# ============================================================================
# 6. 压力测试：4 方案 × 4 情景 × 2 套冲击（第五章）+ 当前组合基线
# ============================================================================
def parse_cgb(s):
    d = {}
    for kv in s.split(','):
        k, v = kv.split(':'); d[int(k.replace('Y', ''))] = float(v)
    return d

COMM = {}
for r in comm_sh.itertuples():
    dypp = parse_cgb(r.cgb_shock_bp)          # 百分点口径（见文件头注释(6)）
    COMM[r.scenario_id] = dict(e300=r.cn_equity_shock, e905=r.cn_equity_shock,
                               eGEM=r.cn_equity_shock, spx=r.spx_usd_shock,
                               fx=r.usdcnh_shock, dy={t: dypp[t] / 100.0 for t in TENORS})
def calib_shock(sid):
    v = CALIB[sid]
    return dict(e300=v['EQ_000300'], e905=v['EQ_000905'], eGEM=v['EQ_399006'],
                spx=v['SPX_usd'], fx=v['USDCNH'], dy={t: v[f'DY{t}bp'] / 10000.0 for t in TENORS})
CAL = {sid: calib_shock(sid) for sid in COMM}

def shock_returns(sh):
    """7 资产冲击收益向量（顺序=COLS）；人民币现金在压力情景中不产生冲击收益。"""
    spx_cny = (1 + sh['spx']) * (1 + sh['fx']) - 1
    cgb_ret = -sum(Dc[t] * sh['dy'][t] for t in TENORS)
    return np.array([sh['e300'], sh['e905'], sh['eGEM'], cgb_ret, sh['fx'], spx_cny, 0.0])

SHOCKS = {}   # (sid, tag) -> 7 维冲击收益向量
for sid in ['S1', 'S2', 'S3', 'S4']:
    SHOCKS[(sid, '委员会')] = shock_returns(COMM[sid])
    SHOCKS[(sid, '历史校准')] = shock_returns(CAL[sid])

def decompose(w, rv):
    cn_eq = w[0] * rv[0] + w[1] * rv[1] + w[2] * rv[2]
    parts = dict(境内权益=cn_eq, 标普500人民币=w[5] * rv[5], 美元现金=w[4] * rv[4], 国债=w[3] * rv[3])
    tot = sum(parts.values()) + w[6] * rv[6]
    return parts, tot

sec('第六部分 压力测试全表（第五章素材）：4 方案 × 4 情景 × 2 套冲击（另列当前组合基线）')
rows = []
for name in PLAN_ORDER:
    w = W[name]
    for sid in ['S1', 'S2', 'S3', 'S4']:
        for tag in ['委员会', '历史校准']:
            rv = SHOCKS[(sid, tag)]
            parts, tot = decompose(w, rv)
            chk = sum(parts.values()) + w[6] * rv[6] - tot
            rows.append(dict(方案=name, 情景=sid, 冲击=tag,
                             境内权益=parts['境内权益'] * 100, 标普500人民币=parts['标普500人民币'] * 100,
                             美元现金=parts['美元现金'] * 100, 国债=parts['国债'] * 100,
                             合计=tot * 100, 金额万元=tot * NAV, 校验=chk))
ST = pd.DataFrame(rows)
assert ST['校验'].abs().max() < 1e-12, '四部分之和 != 合计'
disp = ST.round(2).copy(); disp['金额万元'] = disp['金额万元'].round(1); disp['校验'] = disp['校验'].apply(lambda x: f'{x:.1e}')
print(disp.to_string(index=False))
print('\n（单位：%；金额单位：万元；校验=四部分之和-合计，均为 0。）')

maxloss = {}
print('\n各方案最大压力损失（8 个组合中的最大损失）：')
for name in PLAN_ORDER:
    sub = ST[ST.方案 == name]
    i = sub['合计'].idxmin(); w_ = sub.loc[i]
    maxloss[name] = dict(loss=-w_['合计'] / 100, sid=w_.情景, tag=w_.冲击, amt=-w_['金额万元'])
    print(f"  {name}: {pct(-w_['合计']/100)}（{w_['合计']:.2f}%），来源 {w_.情景}/{w_.冲击}，损益 {wan(w_['金额万元'],1)}")

# 两套冲击严格程度比较（第五章）
print('\n各情景两套冲击的委员会 vs 历史校准严格度（以推荐方案损失计）：')
for sid in ['S1', 'S2', 'S3', 'S4']:
    lc = ST[(ST.方案 == '推荐方案') & (ST.情景 == sid) & (ST.冲击 == '委员会')]['合计'].iloc[0]
    lk = ST[(ST.方案 == '推荐方案') & (ST.情景 == sid) & (ST.冲击 == '历史校准')]['合计'].iloc[0]
    print(f"  {sid}: 委员会 {lc:.2f}% vs 历史校准 {lk:.2f}% -> {'委员会更严' if lc < lk else '历史校准更严'}")

# ============================================================================
# 7. 九项约束检查（第六章）+ 推荐方案唯一性网格（第七章）
# ============================================================================
def static_checks(w):
    w300, w905, wgem, wcgb, wusd, wspx, wcny = w
    eq = w300 + w905 + wgem; fxexp = wusd + wspx
    return dict(C1=abs(w.sum() - 1.0), C2=eq, C3_lo=wcny, C4=wcgb, C5=fxexp)

def stress_maxloss(w):
    return max(-(w @ SHOCKS[k]) for k in SHOCKS)

def hist_metrics_fast(w):
    rp = R.values @ w
    q01 = np.quantile(rp, 0.01)
    es99 = -rp[rp <= q01].mean()
    var99_10 = -np.quantile(roll10(rp), 0.01)
    return es99, var99_10

sec('第七部分 九项约束逐条检查（第六章素材）')
chk_rows = []
for name in PLAN_ORDER:
    w = W[name]; sc = static_checks(w); es99, v10 = hist_metrics_fast(w); ml = stress_maxloss(w)
    res = {
        'C1': (abs(sc['C1']) <= 0.0005, f"权重合计={w.sum()*100:.2f}%（容差0.05pp）"),
        'C2': (sc['C2'] <= 0.60 + 1e-12, f"权益合计={sc['C2']*100:.2f}% ≤60%"),
        'C3': (0.08 - 1e-12 <= sc['C3_lo'] <= 0.20 + 1e-12, f"人民币现金={sc['C3_lo']*100:.2f}% ∈[8%,20%]"),
        'C4': (sc['C4'] >= 0.15 - 1e-12, f"国债={sc['C4']*100:.2f}% ≥15%"),
        'C5': (sc['C5'] <= 0.25 + 1e-12, f"外币敞口=美元现金{w[4]*100:.2f}%+标普QDII{w[5]*100:.2f}%={sc['C5']*100:.2f}% ≤25%"),
        'C6': (es99 <= 0.035 + 1e-12, f"1日ES99={es99*100:.2f}% ≤3.5%"),
        'C7': (v10 <= 0.06 + 1e-12, f"10日VaR99={v10*100:.2f}% ≤6.0%"),
        'C8': (ml <= 0.08 + 1e-12, f"最大压力损失={ml*100:.2f}% ≤8.0%"),
    }
    if name == '推荐方案':
        res['C9'] = (ml <= 0.07 + 1e-12, f"最大压力损失={ml*100:.2f}% ≤7.0%（推荐方案缓冲线）")
    else:
        res['C9'] = (None, '不适用（仅对最终推荐方案）')
    chk_rows.append((name, res))
    line = [name]
    for c in ['C1', 'C2', 'C3', 'C4', 'C5', 'C6', 'C7', 'C8', 'C9']:
        ok, txt = res[c]
        mark = '不适用' if ok is None else ('通过' if ok else '未通过')
        line.append(f'{c}[{mark}]')
    print('  '.join(line))
    for c in ['C1', 'C2', 'C3', 'C4', 'C5', 'C6', 'C7', 'C8', 'C9']:
        ok, txt = res[c]
        print(f'    {c}: {txt} -> ' + ('不适用' if ok is None else ('通过' if ok else '未通过')))
    # 超限幅度
    if sc['C5'] > 0.25: print(f"    C5 超限幅度: +{(sc['C5']-0.25)*100:.2f}pp")
    if ml > 0.08:       print(f"    C8 超限幅度: +{(ml-0.08)*100:.2f}pp")
    if name == '推荐方案' and ml > 0.07: print(f"    C9 超限幅度: +{(ml-0.07)*100:.2f}pp")

print('\n外币敞口口径说明：params_limits.csv L5 注明“美元现金及存款 + 不对冲汇率的标普500 QDII 均计入外币敞口”。')
print('  方案C 若漏计标普500 QDII，则外币敞口=20.00%（表面达标）；按正确口径=30.00%，超限 +5.00pp。')
print('  其余方案外币敞口=10%+10%=20.00%，均 ≤25%。')

# —— 唯一性网格：美元现金/SPX 固定 10%，境内权益按当前权重等比缩减 R(pp)，
#    释放资金 c(pp) 入人民币现金、(R-c)(pp) 入国债；检查九项约束；turnover=R。
sec('第七部分（续） 推荐方案构造验证与唯一性网格搜索（第七章素材）')
rec_rule = dict(r_reb.set_index('key').value.astype(str))
print('recommendation_rule 原文：', rec_rule['recommendation_rule'])
w_rec = W['推荐方案']; w_cur = W['当前组合']
eq_cur = w_cur[:3].sum(); eq_rec = w_rec[:3].sum()
factor = eq_rec / eq_cur
print(f'构造验证：境内权益 {eq_cur*100:.2f}% -> {eq_rec*100:.2f}%，缩减 {100*(eq_cur-eq_rec):.1f}pp，缩减系数={factor:.4f}')
for i, c in enumerate(['沪深300', '中证500', '创业板']):
    print(f'  {c}: {w_cur[i]*100:.2f}%×{factor:.2f}={w_cur[i]*factor*100:.2f}% vs 推荐 {w_rec[i]*100:.2f}%')
print(f'  国债: {w_cur[3]*100:.2f}% + {(w_rec[3]-w_cur[3])*100:.1f}pp = {w_rec[3]*100:.2f}%')
print(f'  人民币现金: {w_cur[6]*100:.2f}% + {(w_rec[6]-w_cur[6])*100:.1f}pp = {w_rec[6]*100:.2f}%（恰为 C3 上限 20%）')
print(f'  美元现金/SPX QDII: {w_rec[4]*100:.0f}%/{w_rec[5]*100:.0f}%（不变）；权重合计={w_rec.sum()*100:.2f}%')

grid = []
Rs = np.arange(0, 25.01, 0.5)
for Rr in Rs:
    for c in np.arange(0, min(Rr, 10.0) + 1e-9, 0.5):
        f_ = (50 - Rr) / 50.0
        w = np.array([0.25 * f_, 0.15 * f_, 0.10 * f_, 0.20 + (Rr - c) / 100, 0.10, 0.10, 0.10 + c / 100])
        es99, v10 = hist_metrics_fast(w); ml = stress_maxloss(w); sc = static_checks(w)
        p = dict(R=Rr, c=c, turnover=Rr / 100, es99=es99, v10=v10, ml=ml,
                 ok=(abs(sc['C1']) <= 0.0005 and sc['C2'] <= 0.6 and 0.08 <= sc['C3_lo'] <= 0.2
                     and sc['C4'] >= 0.15 and sc['C5'] <= 0.25 and es99 <= 0.035
                     and v10 <= 0.06 and ml <= 0.08 and ml <= 0.07))
        grid.append(p)
G = pd.DataFrame(grid)
P = G[G.ok].sort_values(['turnover', 'ml']).reset_index(drop=True)
print(f'\n网格：减配 R∈[0,25]pp 步长0.5 × 现金增配 c∈[0,min(R,10)]pp 步长0.5，共 {len(G)} 个组合；')
print(f'通过全部九项检查（含 C9≤7%）的组合 {len(P)} 个。')
print('最低换手率的前 8 个通过组合：')
_top = P.head(8).copy()
_top['turnover'] = (_top['turnover'] * 100).round(2)
_top['C9裕度pp'] = ((0.07 - _top['ml']) * 100).round(2)     # 用未缩放的 ml（小数）计算，须在缩放前
_top['es99'] = (_top['es99'] * 100).round(2)
_top['v10'] = (_top['v10'] * 100).round(2)
_top['ml'] = (_top['ml'] * 100).round(2)
print(_top.drop(columns=['ok']).to_string(index=False))
rec_row = G[(np.isclose(G.R, 20.5)) & (np.isclose(G.c, 10.0))].iloc[0]
print(f"\n推荐方案在网格中的位置：R=20.5, c=10.0，通过九项={bool(rec_row.ok)}，"
      f"最大压力损失={rec_row.ml*100:.2f}%，C9 裕度={(0.07-rec_row.ml)*100:.2f}pp")

# 同换手率（R=20.5pp）下不同 c 的次优组合比较
same = G[np.isclose(G.R, 20.5)].sort_values('c', ascending=False)
print('\n同换手率（卖出 20.50%）下的备选拆分（次优组合比较）：')
print(same.assign(cgb=lambda d: ((0.20 + (20.5 - d.c) / 100) * 100).round(2),
                  cash=lambda d: ((0.10 + d.c / 100) * 100).round(2),
                  es99=lambda d: (d.es99 * 100).round(2), v10=lambda d: (d.v10 * 100).round(2),
                  ml=lambda d: (d.ml * 100).round(2), ok=lambda d: d.ok.astype(int))
      [['c', 'cgb', 'cash', 'es99', 'v10', 'ml', 'ok']].to_string(index=False))

# 脆弱性：S4 委员会情景下权益冲击可承受上限
def max_eq_shock_S4(w):
    base = COMM['S4']
    lo, hi = 0.18, 1.2
    for _ in range(60):
        mid = (lo + hi) / 2
        sh = dict(base); sh2 = dict(e300=-mid, e905=-mid, eGEM=-mid, spx=sh['spx'], fx=sh['fx'], dy=sh['dy'])
        loss = -(w @ shock_returns(sh2))
        if loss <= 0.07: lo = mid
        else: hi = mid
    return lo
print('\n脆弱性检验（C9=7% 约束下，S4 情景可承受的境内权益冲击上限；委员会假设为 -18%）：')
for name in ['方案A', '方案B', '方案C', '推荐方案']:
    print(f'  {name}: -{max_eq_shock_S4(W[name])*100:.2f}%')
for Rr, c in [(10.0, 0.0), (13.0, 0.0), (16.0, 10.0), (20.5, 10.0)]:
    f_ = (50 - Rr) / 50.0
    w = np.array([0.25 * f_, 0.15 * f_, 0.10 * f_, 0.20 + (Rr - c) / 100, 0.10, 0.10, 0.10 + c / 100])
    print(f'  网格(R={Rr},c={c}): -{max_eq_shock_S4(w)*100:.2f}%')

# ============================================================================
# 8. 调仓执行模拟（第七章）
# ============================================================================
sec('第八部分 调仓执行（第七章素材）：当前组合 -> 推荐方案')
trades = []
names = {'EQ_000300': '沪深300指数基金', 'EQ_000905': '中证500指数基金', 'EQ_399006': '创业板指数基金',
         'CGB': '中长期国债组合', 'USD_CASH': '美元现金及存款', 'SPX': '标普500 QDII基金',
         'CNY_CASH': '人民币现金及货基'}
for i, c in enumerate(COLS):
    amt = (w_rec[i] - w_cur[i]) * NAV
    trades.append(dict(资产=names[c], 方向=('卖出' if amt < 0 else ('买入' if amt > 0 else '不动')),
                       金额万元=abs(amt), 目标权重=w_rec[i]))
sells = sum(t['金额万元'] for t in trades if t['方向'] == '卖出')
buys = sum(t['金额万元'] for t in trades if t['方向'] == '买入')
print(pd.DataFrame(trades).assign(金额万元=lambda d: d['金额万元'].round(2),
                                  目标权重=lambda d: (d['目标权重'] * 100).round(2)).to_string(index=False))
print(f'卖出合计 {sells:,.2f} 万元；买入合计 {buys:,.2f} 万元；单向换手率 = {sells/NAV*100:.2f}%')
print('定价基准：2026-09-15 收盘价/估值日价格（rules_rebalance.price_basis）。')
print('QDII：本方案标普500 QDII 不交易，T+7 赎回款规则不触发。')

cash0 = w_cur[6] * NAV
print(f'\n说明：监测口径的"现金"为人民币现金及货基整体（L3）。货基申购系现金桶内部划转，不构成现金流；'
      f'人民币现金及货基由 10.00% 增至 20.00%（+1,000.00 万元）为卖出净额扣除国债买入后的自然剩余，'
      f'不作为独立交易步骤。现金路径仅跟踪非现金资产的卖出回款与买入付款。')
flow = [t for t in trades if t['资产'] != '人民币现金及货基' and t['方向'] != '不动']
sell_ts = [t for t in flow if t['方向'] == '卖出']
buy_ts = [t for t in flow if t['方向'] == '买入']
# 先卖出后买入（规则顺序）
steps_sf = ['起始'] + [f'卖出{t["资产"]} {t["金额万元"]:,.2f}万' for t in sell_ts] \
           + [f'买入{t["资产"]} {t["金额万元"]:,.2f}万' for t in buy_ts]
path_sell_first = [cash0]; c_ = cash0
for t in sell_ts: c_ += t['金额万元']; path_sell_first.append(c_)
for t in buy_ts: c_ -= t['金额万元']; path_sell_first.append(c_)
# 先买入后卖出（反向路径，用于对比）
steps_bf = ['起始'] + [f'买入{t["资产"]} {t["金额万元"]:,.2f}万' for t in buy_ts] \
           + [f'卖出{t["资产"]} {t["金额万元"]:,.2f}万' for t in sell_ts]
path_buy_first = [cash0]; c_ = cash0
for t in buy_ts: c_ -= t['金额万元']; path_buy_first.append(c_)
for t in sell_ts: c_ += t['金额万元']; path_buy_first.append(c_)
pf_sf = pd.DataFrame({'步骤': steps_sf,
                      '现金万元': np.round(path_sell_first, 2),
                      '占比%': np.round(np.array(path_sell_first) / NAV * 100, 2)})
pf_bf = pd.DataFrame({'步骤': steps_bf,
                      '现金万元': np.round(path_buy_first, 2),
                      '占比%': np.round(np.array(path_buy_first) / NAV * 100, 2)})
print('\n现金占比路径 A：先卖出后买入（规则顺序，现金下限 8%）：')
print(pf_sf.to_string(index=False))
print('\n现金占比路径 B：先买入后卖出（对比路径）：')
print(pf_bf.to_string(index=False))
print(f'先卖后买：全程最低现金占比 {np.min(path_sell_first)/NAV*100:.2f}%，' +
      ('未击穿' if min(path_sell_first) / NAV >= 0.08 else '击穿') + ' 8% 下限。')
first_buy = next(t for t in trades if t['方向'] == '买入')
print(f'先买后卖：先买入{first_buy["资产"]} {first_buy["金额万元"]:,.2f} 万元后现金 {path_buy_first[1]:,.2f} 万元（{path_buy_first[1]/NAV*100:.2f}%），'
      '立即击穿 8% 下限（且出现透支），不可行。结论：必须按规则先卖出后买入。')

# ============================================================================
# 9. 反向压力测试与马氏距离（第八章）
# ============================================================================
sec('第九部分 反向压力测试与马氏距离（第八章素材）')
# 10 日因子累计变动（重叠窗口）
facs = {}
facs['EQ_000300'] = LVL['EQ300'].shift(-9) / LVL['EQ300'] - 1
facs['EQ_000905'] = LVL['EQ900'].shift(-9) / LVL['EQ900'] - 1
facs['EQ_399006'] = LVL['GEM'].shift(-9) / LVL['GEM'] - 1
facs['SPX_usd'] = LVL['SPX'].shift(-9) / LVL['SPX'] - 1
facs['USDCNH'] = LVL['USD'].shift(-9) / LVL['USD'] - 1
for t in TENORS:
    facs[f'DY{t}'] = (LVL[f'CGB{t}'].shift(-9) - LVL[f'CGB{t}']) / 100.0
FKEYS = ['EQ_000300', 'EQ_000905', 'EQ_399006', 'SPX_usd', 'USDCNH'] + [f'DY{t}' for t in TENORS]
F = pd.DataFrame(facs)[FKEYS].loc[sample].dropna()
SIG = np.cov(F.values.T)
SIGI = np.linalg.pinv(SIG)
print(f'因子协差阵基于 {len(F)} 个重叠 10 日窗口（{F.index[0].date()} ~ {F.index[-1].date()}）。')

wR = W['推荐方案']
a = np.array([wR[0], wR[1], wR[2], wR[5], wR[5] + wR[4],
              -wR[3] * Dc[1], -wR[3] * Dc[2], -wR[3] * Dc[5], -wR[3] * Dc[10], -wR[3] * Dc[30]])
ava = float(a @ SIG @ a)
vol10 = np.sqrt(ava)
print(f'推荐方案线性化 10 日组合波动 = {vol10*100:.2f}%（sqrt(a\'Σa)）。')

def maha(x): return float(np.sqrt(x @ SIGI @ x))
def rev_scenario(target):
    x = target * (SIG @ a) / ava
    return x, maha(x)

x7, d7 = rev_scenario(-0.07)
x8, d8 = rev_scenario(-0.08)
print(f'\n反向压力测试（推荐方案）：触及 7% 缓冲线的最小距离解 d*={d7:.2f}；触及 8% 上限 d*={d8:.2f}')
rvs = pd.DataFrame({'因子': FKEYS,
                    '触及7%变动': [x7[i] * 100 if i < 5 else x7[i] * 10000 for i in range(10)],
                    '单位': ['%'] * 5 + ['bp'] * 5,
                    '触及8%变动': [x8[i] * 100 if i < 5 else x8[i] * 10000 for i in range(10)]}).round(2)
print(rvs.to_string(index=False))

def shock_vec(sh):
    return np.array([sh['e300'], sh['e905'], sh['eGEM'], sh['spx'], sh['fx'],
                     sh['dy'][1], sh['dy'][2], sh['dy'][5], sh['dy'][10], sh['dy'][30]])
print('\n马氏距离对比（以零冲击为基准中心，Σ 为 10 日因子协方差）：')
drows = []
for sid in ['S1', 'S2', 'S3', 'S4']:
    dc = maha(shock_vec(COMM[sid])); dk = maha(shock_vec(CAL[sid]))
    keep = WIN[sid][1]
    dw = []
    for r in keep.itertuples():
        fcw = factor_change(r.base, r.end)
        xw = np.array([fcw[k] for k in ['EQ_000300', 'EQ_000905', 'EQ_399006', 'SPX_usd', 'USDCNH']]
                      + [fcw[f'DY{t}bp'] / 10000.0 for t in TENORS])
        dw.append(maha(xw))
    drows.append(dict(情景=sid, 委员会冲击距离=round(dc, 2), 校准冲击距离=round(dk, 2),
                      保留窗口距离中位=round(float(np.median(dw)), 2)))
drows.append(dict(情景='反向-7%', 委员会冲击距离=round(d7, 2), 校准冲击距离=None, 保留窗口距离中位=None))
drows.append(dict(情景='反向-8%', 委员会冲击距离=round(d8, 2), 校准冲击距离=None, 保留窗口距离中位=None))
print(pd.DataFrame(drows).to_string(index=False))

ml_rec = maxloss['推荐方案']['loss']
print(f"\n推荐方案最大压力损失 {ml_rec*100:.2f}%（{maxloss['推荐方案']['sid']}/{maxloss['推荐方案']['tag']}）：")
print(f"  对 C9(7%) 裕度 = {(0.07-ml_rec)*100:.2f}pp；对 C8(8%) 裕度 = {(0.08-ml_rec)*100:.2f}pp")
print(f"  放大倍数（整体等比放大最严情景冲击至触及 7% / 8%）：{0.07/ml_rec:.2f}x / {0.08/ml_rec:.2f}x")
mR = M['推荐方案']
print(f"  样本内最差 10 日累计损失 = {mR['worst10']*100:.2f}%（{mR['worst10_start'].date()} ~ {mR['worst10_end'].date()}）")

# ============================================================================
# 10. 监测指标 M1~M8（第八章）
# ============================================================================
sec('第十部分 八个监测指标（第八章素材，模板 template_monitor.csv）')
def last_n(s, n, upto=None):
    x = s.dropna()
    if upto is not None: x = x[x.index <= upto]
    return x.iloc[-n:]
mon = []
c300 = LVL['EQ300']; m1_base = c300.dropna().iloc[-21]
m1 = c300.dropna().iloc[-1] / m1_base - 1
mon.append(('M1', '沪深300 20日收益', pct(m1), '-5.00%', str(c300.last_valid_index().date()), '低于阈值触发', m1 < -0.05, f'{m1*100:.2f}%'))
u = LVL['USD']; m2 = u.dropna().iloc[-1] / u.dropna().iloc[-21] - 1
mon.append(('M2', 'USD/CNH 20日变化', pct(m2), '+2.00%', str(u.last_valid_index().date()), '高于阈值触发', m2 > 0.02, f'{m2*100:.2f}%'))
d = LVL['DR007'].dropna(); m3 = (d.iloc[-20:].mean() - d.iloc[-80:-20].mean()) * 100
mon.append(('M3', 'DR007 20日均值-此前60日均值', f'{m3:.2f}bp', '+20.00bp', str(d.index[-1].date()), '高于阈值触发', m3 > 20, f'{m3:.2f}bp'))
y10 = LVL['CGB10'].dropna(); m4 = (y10.iloc[-1] - y10.iloc[-21]) * 100
mon.append(('M4', '中债10Y 20日变化', f'{m4:.2f}bp', '+10.00bp', str(y10.index[-1].date()) + '（数据滞后）', '高于阈值触发', m4 > 10, f'{m4:.2f}bp'))
yus = LVL['UST10'].dropna(); m5 = (yus.iloc[-1] - yus.iloc[-21]) * 100
mon.append(('M5', '美债10Y 20日变化', f'{m5:.2f}bp', '+40.00bp', str(yus.index[-1].date()), '高于阈值触发', m5 > 40, f'{m5:.2f}bp'))
p_ = RAW['PPI'].set_index('date').ppi_yoy.sort_index(); m6 = p_.iloc[-1] - p_.iloc[-4]
mon.append(('M6', 'PPI同比-3个月前', f'{m6:+.2f}pp', '+1.50pp', str(p_.index[-1].date()), '高于阈值触发', m6 > 1.5, f'{m6:+.2f}个百分点'))
pm_ = RAW['PMI'].set_index('date').pmi_mfg.sort_index(); m7 = pm_.iloc[-1]
mon.append(('M7', '制造业PMI最新月值', f'{m7:.2f}', '49.00', str(pm_.index[-1].date()) + '（缺2026-08）', '低于阈值触发', m7 < 49, f'{m7:.2f}'))
af = RAW['AFRE'].set_index('date').afre_stock.sort_index(); m8 = af.iloc[-1] / af.iloc[-13] - 1
mon.append(('M8', '社融存量同比', pct(m8), '8.00%', str(af.index[-1].date()) + '（数据滞后）', '低于阈值触发', m8 < 0.08, f'{m8*100:.2f}%'))
MON = pd.DataFrame(mon, columns=['monitor_id', 'indicator', 'latest', 'threshold', 'data_asof', 'direction', 'triggered', 'latest_value'])
print(MON[['monitor_id', 'indicator', 'threshold', 'direction', 'latest_value', 'data_asof', 'triggered']].to_string(index=False))
print('\n状态：triggered=True 即触发。M4/M8 数据滞后于分析截至日，触发结论以最新可得数据为准，须在数据补齐后复判。')

# ============================================================================
# 11. 图表（10 张 PNG，中文标注，含限额参考线）
# ============================================================================
sec('第十一部分 生成图表')
C = dict(curve='#1f77b4', red='#d62728', orange='#ff7f0e', green='#2ca02c', gray='#7f7f7f',
         purple='#9467bd', brown='#8c564b')
PN = {k: f'{CH}/FIN3-WKN-149_{v}.png' for k, v in {
    1: 'chart01_数据覆盖与缺口', 2: 'chart02_方案累计净值', 3: 'chart03_风险指标与限额',
    4: 'chart04_情景合格月份', 5: 'chart05_历史窗口校准冲击', 6: 'chart06_两套冲击对比',
    7: 'chart07_方案决策与限额', 8: 'chart08_调仓现金路径', 9: 'chart09_反向压力测试',
    10: 'chart10_监测指标触发状态'}.items()}
LBL = {'EQ300': '沪深300', 'EQ900': '中证500', 'GEM': '创业板指', 'USD': 'USD/CNH', 'SPX': '标普500',
       'DR007': 'DR007', 'SHIBOR': 'Shibor', 'UST10': '美债10Y', 'USTM2': '美债2M', 'USTM4': '美债4M',
       'CGB1': '中债1Y', 'CGB2': '中债2Y', 'CGB5': '中债5Y', 'CGB10': '中债10Y', 'CGB30': '中债30Y',
       'LPR1': 'LPR1Y', 'LPR5': 'LPR5Y', 'PMI': '制造业PMI', 'PPI': 'PPI同比', 'AFRE': '社融存量'}

# chart01 数据覆盖与缺口
fig, ax = plt.subplots(figsize=(13, 8))
order = ['EQ300', 'EQ900', 'GEM', 'CGB1', 'CGB2', 'CGB5', 'CGB10', 'CGB30', 'USD', 'SPX',
         'SHIBOR', 'DR007', 'LPR1', 'LPR5', 'PMI', 'PPI', 'AFRE', 'UST10', 'USTM2', 'USTM4']
for i, k in enumerate(order):
    df = RAW[k] if k not in ('EQ300', 'EQ900', 'GEM', 'USD', 'SHIBOR') else load_raw(FILES[k][0])
    s = df.dropna(subset=[FILES[k][1]])
    lo, hi = s.date.min(), s.date.max()
    ax.barh(i, (hi - lo).days, left=lo, height=0.6, color=C['curve'], alpha=0.75)
    if k in ('CGB1', 'CGB10', 'AFRE', 'PPI', 'LPR1', 'LPR5'):
        ax.text(hi + pd.Timedelta(days=20), i, f'止于{hi.date()}', va='center', fontsize=8, color=C['red'])
ax.axvline(CUTOFF, color=C['red'], ls='-', lw=1.5)
ax.text(CUTOFF + pd.Timedelta(days=15), len(order) - 0.4, '分析截至日 2026-09-15', color=C['red'], fontsize=9)
ax.axvline(pd.Timestamp('2026-06-09'), color=C['orange'], ls='--', lw=1.2)
ax.text(pd.Timestamp('2026-06-09') - pd.Timedelta(days=420), len(order) - 0.4,
        '中债曲线截断 2026-06-09', color=C['orange'], fontsize=9)
ax.axvline(pd.Timestamp('2018-09-03'), color=C['green'], ls=':', lw=1.2)
ax.text(pd.Timestamp('2018-09-03') + pd.Timedelta(days=15), -0.9, '收益样本起点 2018-09-03', color=C['green'], fontsize=9)
ax.scatter([pd.Timestamp('2026-09-12')], [order.index('EQ300')], marker='x', color='k', s=60, zorder=5)
ax.scatter([pd.Timestamp('2026-09-12')], [order.index('EQ900')], marker='x', color='k', s=60, zorder=5)
ax.text(pd.Timestamp('2026-02-01'), order.index('EQ900') + 0.55, '× 2026-09-12(周六)异常记录，已剔除', fontsize=8)
ax.set_yticks(range(len(order))); ax.set_yticklabels([LBL[k] for k in order], fontsize=9)
ax.invert_yaxis(); ax.xaxis.set_major_locator(mdates.YearLocator())
ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y'))
ax.set_xlim(pd.Timestamp('2017-10-01'), pd.Timestamp('2027-06-01'))
ax.set_title('图1 数据覆盖与缺口：各序列实际覆盖区间、截断与异常记录（2018-01-02 ~ 2026-09-15）')
ax.grid(axis='x', alpha=0.3)
fig.tight_layout(); fig.savefig(PN[1], dpi=150); plt.close(fig)

# chart02 方案累计净值
fig, ax = plt.subplots(figsize=(12, 6.5))
for name, col in zip(PLAN_ORDER, [C['gray'], C['orange'], C['green'], C['purple'], C['red']]):
    ax.plot(sample, M[name]['nav'], label=f'{name}（期末 {M[name]["nav_end"]:.3f}）', color=col,
            lw=2.2 if name == '推荐方案' else 1.3)
ax.set_title(f'图2 各方案累计净值（每日再平衡，{S0.date()} ~ {S1_.date()}，共 {len(sample)} 个交易日）')
ax.legend(loc='upper left', fontsize=9); ax.grid(alpha=0.3); ax.set_ylabel('净值（期初=1）')
fig.tight_layout(); fig.savefig(PN[2], dpi=150); plt.close(fig)

# chart03 风险指标与限额
fig, axes = plt.subplots(1, 2, figsize=(13, 5.5))
for ax, key, lim, ttl in [(axes[0], 'es99', 3.5, '1 日 ES99（限额 L6 ≤ 3.5%）'),
                          (axes[1], 'var99_10', 6.0, '10 日 VaR99（限额 L7 ≤ 6.0%）')]:
    vals = [M[n][key] * 100 for n in PLAN_ORDER]
    cols = [C['red'] if v > lim else C['curve'] for v in vals]
    ax.bar(PLAN_ORDER, vals, color=cols, alpha=0.85)
    ax.axhline(lim, color=C['red'], ls='--', lw=1.5, label=f'限额 {lim:.1f}%')
    for i, v in enumerate(vals): ax.text(i, v + 0.06, f'{v:.2f}', ha='center', fontsize=9)
    ax.set_title(ttl); ax.legend(); ax.grid(axis='y', alpha=0.3); ax.set_ylabel('%')
fig.suptitle('图3 历史风险指标与限额参考线（样本 2018-09-03 ~ 2026-06-09）', y=1.0)
fig.tight_layout(); fig.savefig(PN[3], dpi=150); plt.close(fig)

# chart04 情景合格月份
fig, ax = plt.subplots(figsize=(13, 4.5))
for j, sid in enumerate(['S1', 'S2', 'S3', 'S4']):
    df = SC[sid]
    for r in df.itertuples():
        m = pd.Period(r.month).to_timestamp()
        if r.status == '合格': ax.scatter(m, j, marker='s', s=42, color=C['red'], zorder=3)
        elif r.status == '不可判定': ax.scatter(m, j, marker='x', s=26, color=C['orange'], zorder=3)
        else: ax.scatter(m, j, marker='.', s=12, color='#bbbbbb', zorder=2)
ax.set_yticks(range(4))
ax.set_yticklabels([f'{s} {r_scen[r_scen.scenario_id == s].scenario.iloc[0]}' for s in ['S1', 'S2', 'S3', 'S4']], fontsize=9)
ax.xaxis.set_major_locator(mdates.YearLocator()); ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y'))
ax.set_xlim(pd.Timestamp('2017-11-01'), pd.Timestamp('2026-12-01')); ax.invert_yaxis()
from matplotlib.lines import Line2D
ax.legend(handles=[Line2D([], [], marker='s', color='w', markerfacecolor=C['red'], markersize=8, label='合格'),
                   Line2D([], [], marker='x', color=C['orange'], ls='', markersize=8, label='不可判定（数据缺失）'),
                   Line2D([], [], marker='.', color='#bbbbbb', ls='', markersize=8, label='不合格')],
          loc='lower left', fontsize=9, ncol=3)
ax.set_title('图4 四情景月度识别结果（2018-01 ~ 2026-09；2026-09 为截至 09-15 的月内数据）')
ax.grid(axis='x', alpha=0.3)
fig.tight_layout(); fig.savefig(PN[4], dpi=150); plt.close(fig)

# chart05 历史窗口校准冲击
fig, axes = plt.subplots(2, 2, figsize=(14, 9))
for ax, sid in zip(axes.flat, ['S1', 'S2', 'S3', 'S4']):
    v = CALIB[sid]
    nm5 = ['沪深300', '中证500', '创业板', 'SPX(USD)', 'USDCNH']
    vals = [v['EQ_000300'] * 100, v['EQ_000905'] * 100, v['EQ_399006'] * 100, v['SPX_usd'] * 100, v['USDCNH'] * 100]
    b1 = ax.bar(range(5), vals, color=[C['red'] if x < 0 else C['green'] for x in vals], alpha=0.85)
    ax.set_xticks(range(5)); ax.set_xticklabels(nm5, fontsize=9); ax.set_ylabel('10日累计变动 %')
    ax.axhline(0, color='k', lw=0.8); ax.grid(axis='y', alpha=0.3)
    for i, x in enumerate(vals): ax.text(i, x + (0.15 if x >= 0 else -0.35), f'{x:.2f}', ha='center', fontsize=8)
    ax2 = ax.twinx()
    bvals = [v[f'DY{t}bp'] for t in TENORS]
    ax2.bar(np.arange(5, 10) - 0.0, bvals, width=0.9, color=[C['purple'] if x < 0 else C['brown'] for x in bvals], alpha=0.6)
    ax2.set_xticks(np.arange(5, 10)); ax2.set_xticklabels([f'{t}Y' for t in TENORS], fontsize=9)
    ax2.set_ylabel('Δy (bp)', color=C['brown'])
    for i, x in enumerate(bvals): ax2.text(5 + i, x + (0.4 if x >= 0 else -1.0), f'{x:.1f}', ha='center', fontsize=8, color=C['brown'])
    ax.set_title(f'{sid} {r_scen[r_scen.scenario_id==sid].scenario.iloc[0]}（保留窗口 {len(WIN[sid][1])} 个，中位数）', fontsize=11)
    ax.set_xlim(-0.6, 9.6)
fig.suptitle('图5 各情景历史窗口校准冲击（左轴：权益/SPX/汇率 10 日累计变动%；右轴：国债收益率变动 bp）', y=1.0)
fig.tight_layout(); fig.savefig(PN[5], dpi=150); plt.close(fig)

# chart06 两套冲击对比（损失严格程度）
fig, axes = plt.subplots(1, 4, figsize=(16, 5), sharey=True)
for ax, sid in zip(axes, ['S1', 'S2', 'S3', 'S4']):
    sub = ST[(ST.情景 == sid) & (ST.方案.isin(PLAN_ORDER))]
    xs = np.arange(len(PLAN_ORDER)); wd = 0.38
    vc = [-sub[(sub.方案 == n) & (sub.冲击 == '委员会')]['合计'].iloc[0] for n in PLAN_ORDER]
    vk = [-sub[(sub.方案 == n) & (sub.冲击 == '历史校准')]['合计'].iloc[0] for n in PLAN_ORDER]
    ax.bar(xs - wd / 2, vc, wd, label='委员会冲击', color=C['red'], alpha=0.85)
    ax.bar(xs + wd / 2, vk, wd, label='历史校准冲击', color=C['curve'], alpha=0.85)
    ax.set_xticks(xs); ax.set_xticklabels(PLAN_ORDER, fontsize=8, rotation=20)
    ax.set_title(f'{sid} {r_scen[r_scen.scenario_id==sid].scenario.iloc[0]}', fontsize=10)
    ax.axhline(0, color='k', lw=0.8); ax.grid(axis='y', alpha=0.3)
axes[0].set_ylabel('压力损失 %（正=损失）'); axes[0].legend(fontsize=9)
fig.suptitle('图6 委员会沿用冲击 vs 历史校准冲击的严格程度（各方案压力损失对比）', y=1.0)
fig.tight_layout(); fig.savefig(PN[6], dpi=150); plt.close(fig)

# chart07 方案决策与限额
fig, ax = plt.subplots(figsize=(11, 5.5))
names_ = PLAN_ORDER
vals = [maxloss[n]['loss'] * 100 for n in names_]
cols = [C['red'] if v > 8 else (C['orange'] if v > 7 else C['green']) for v in vals]
ax.barh(names_, vals, color=cols, alpha=0.85)
ax.axvline(8, color=C['red'], ls='--', lw=1.8, label='L8 压力损失上限 8%')
ax.axvline(7, color=C['orange'], ls=':', lw=1.8, label='L9 推荐方案缓冲线 7%')
for i, n in enumerate(names_):
    ax.text(vals[i] + 0.12, i, f'{vals[i]:.2f}%（{maxloss[n]["sid"]}/{maxloss[n]["tag"]}）', va='center', fontsize=9)
ax.set_xlim(0, 11.5); ax.set_xlabel('最大压力损失 %（4 情景 × 2 套冲击）')
ax.set_title('图7 各方案最大压力损失与限额参考线'); ax.legend(loc='lower right'); ax.grid(axis='x', alpha=0.3)
fig.tight_layout(); fig.savefig(PN[7], dpi=150); plt.close(fig)

# chart08 调仓现金路径
fig, ax = plt.subplots(figsize=(11.5, 5.5))
x1 = np.arange(len(path_sell_first)); x2 = np.arange(len(path_buy_first))
ax.plot(x1, np.array(path_sell_first) / NAV * 100, 'o-', color=C['green'], lw=2, label='先卖出后买入（规则顺序）')
ax.plot(x2, np.array(path_buy_first) / NAV * 100, 's--', color=C['red'], lw=2, label='先买入后卖出（对比路径）')
ax.axhline(8, color=C['red'], ls=':', lw=1.8, label='人民币现金下限 8%')
ax.axhline(0, color='k', lw=0.8)
short_lbl = {'沪深300指数基金': '沪深300', '中证500指数基金': '中证500', '创业板指数基金': '创业板',
             '中长期国债组合': '国债', '美元现金及存款': '美元现金', '标普500 QDII基金': 'SPX QDII'}
def _short(s):
    if s == '起始': return '起始'
    act = '卖' if s.startswith('卖出') else '买'
    body = s[2:]
    for k, v in short_lbl.items(): body = body.replace(k, v)
    body = body.replace('指数基金', '').replace('组合', '').replace('及存款', '')
    amt = body.split(' ')[-1]
    nm = body.split(' ')[0]
    return f'{act}{nm}\n{amt}'
chart_lbl = [_short(s) for s in steps_sf]
ax.set_xticks(x1)
ax.set_xticklabels(chart_lbl, fontsize=9)
for i, v in enumerate(np.array(path_sell_first) / NAV * 100): ax.text(i, v + 0.8, f'{v:.2f}%', ha='center', fontsize=9, color=C['green'])
for i, v in enumerate(np.array(path_buy_first) / NAV * 100):
    if i > 0: ax.text(i, v - 1.6, f'{v:.2f}%', ha='center', fontsize=9, color=C['red'])
_minbf = min(np.array(path_buy_first) / NAV * 100)
ax.annotate(f'击穿下限（现金透支 {_minbf:.2f}%）', xy=(1, path_buy_first[1] / NAV * 100),
            xytext=(1.4, -4.5), fontsize=10, color=C['red'],
            arrowprops=dict(arrowstyle='->', color=C['red']))
ax.set_ylabel('人民币现金及货基占比 %'); ax.set_ylim(-6, 36)
ax.set_title('图8 调仓执行现金占比路径（当前组合 → 推荐方案，净值 10,000 万元）')
ax.legend(loc='upper left'); ax.grid(alpha=0.3)
fig.tight_layout(); fig.savefig(PN[8], dpi=150); plt.close(fig)

# chart09 反向压力测试
fig = plt.figure(figsize=(14, 6))
ax1 = fig.add_subplot(1, 2, 1)
nm9 = ['沪深300', '中证500', '创业板', 'SPX(USD)', 'USDCNH', '1Y', '2Y', '5Y', '10Y', '30Y']
v9 = [x7[i] * 100 for i in range(5)] + [x7[i] * 10000 for i in range(5, 10)]
cols9 = [C['red'] if v < 0 else C['green'] for v in v9[:5]] + [C['purple'] if v < 0 else C['brown'] for v in v9[5:]]
ax1.bar(range(10), v9, color=cols9, alpha=0.85)
ax1.set_xticks(range(10)); ax1.set_xticklabels(nm9, fontsize=9, rotation=30)
ax1.axhline(0, color='k', lw=0.8)
for i, v in enumerate(v9): ax1.text(i, v + (0.4 if v >= 0 else -1.1), f'{v:.2f}', ha='center', fontsize=8)
ax1.set_ylabel('因子变动（左5项：%；右5项：bp）')
ax1.set_title(f'最可能（最小马氏距离）情景：推荐方案损失达 7%\nd*={d7:.2f}（10 日因子口径）', fontsize=11)
ax1.grid(axis='y', alpha=0.3)
ax2 = fig.add_subplot(1, 2, 2)
dn = ['反向-7%', '反向-8%'] + [f'{s}委员会' for s in ['S1', 'S2', 'S3', 'S4']] + [f'{s}校准' for s in ['S1', 'S2', 'S3', 'S4']]
dv = [d7, d8] + [maha(shock_vec(COMM[s])) for s in ['S1', 'S2', 'S3', 'S4']] + [maha(shock_vec(CAL[s])) for s in ['S1', 'S2', 'S3', 'S4']]
cols2 = [C['orange']] * 2 + [C['red']] * 4 + [C['curve']] * 4
ax2.bar(range(len(dv)), dv, color=cols2, alpha=0.85)
ax2.set_xticks(range(len(dv))); ax2.set_xticklabels(dn, fontsize=8.5, rotation=40, ha='right')
for i, v in enumerate(dv): ax2.text(i, v + 0.1, f'{v:.2f}', ha='center', fontsize=8.5)
ax2.set_ylabel('马氏距离 d（以零冲击为中心，Σ=10日因子协方差）')
ax2.set_title('各冲击向量的历史合理性（距离越小越“可能”）', fontsize=11)
ax2.grid(axis='y', alpha=0.3)
fig.suptitle('图9 反向压力测试：触及 7% 缓冲线的最可能情景与马氏距离对比', y=1.0)
fig.tight_layout(); fig.savefig(PN[9], dpi=150); plt.close(fig)

# chart10 监测指标触发状态
fig, axes = plt.subplots(2, 4, figsize=(16, 7.5))
mvals = [dict(name='M1 沪深300 20日收益', v=m1 * 100, th=-5.0, unit='%', trig=m1 < -0.05, asof=str(c300.last_valid_index().date())),
         dict(name='M2 USDCNH 20日变化', v=m2 * 100, th=2.0, unit='%', trig=m2 > 0.02, asof=str(u.last_valid_index().date())),
         dict(name='M3 DR007 均值变化', v=m3, th=20.0, unit='bp', trig=m3 > 20, asof=str(d.index[-1].date())),
         dict(name='M4 中债10Y 20日变化', v=m4, th=10.0, unit='bp', trig=m4 > 10, asof=str(y10.index[-1].date()) + '(滞后)'),
         dict(name='M5 美债10Y 20日变化', v=m5, th=40.0, unit='bp', trig=m5 > 40, asof=str(yus.index[-1].date())),
         dict(name='M6 PPI同比加速', v=m6, th=1.5, unit='pp', trig=m6 > 1.5, asof=str(p_.index[-1].date())),
         dict(name='M7 制造业PMI', v=m7, th=49.0, unit='', trig=m7 < 49, asof=str(pm_.index[-1].date()) + '(缺08月)'),
         dict(name='M8 社融存量同比', v=m8 * 100, th=8.0, unit='%', trig=m8 < 0.08, asof=str(af.index[-1].date()) + '(滞后)')]
for ax, mv in zip(axes.flat, mvals):
    lo = min(mv['v'], mv['th']); hi = max(mv['v'], mv['th']); pad = max(abs(hi) * 0.35, 0.5)
    ax.bar([0], [mv['v']], width=0.5, color=C['red'] if mv['trig'] else C['green'], alpha=0.85)
    ax.axhline(mv['th'], color='k', ls='--', lw=1.3)
    ax.text(0.32, mv['th'], f"阈值 {mv['th']:.2f}{mv['unit']}", fontsize=8.5, va='center')
    ax.text(0, mv['v'] + (pad * 0.15 if mv['v'] >= 0 else -pad * 0.3), f"{mv['v']:.2f}{mv['unit']}",
            ha='center', fontsize=9.5, fontweight='bold')
    ax.set_xlim(-0.6, 1.15); ax.set_ylim(lo - pad, hi + pad); ax.set_xticks([])
    ax.set_title(('触发! ' if mv['trig'] else '正常 ') + mv['name'], fontsize=10,
                 color=C['red'] if mv['trig'] else C['green'])
    ax.text(0.5, -0.12, f'数据截至 {mv["asof"]}', transform=ax.transAxes, ha='center', fontsize=8, color=C['gray'])
fig.suptitle('图10 八个监测指标最新值与阈值（数据截至日见图下标注；分析截至日 2026-09-15）', y=1.0)
fig.tight_layout(); fig.savefig(PN[10], dpi=150); plt.close(fig)

for k in sorted(PN): print('已生成:', PN[k])

# ============================================================================
# 12. 汇总关键数字（供备忘录交叉核对）
# ============================================================================
sec('第十二部分 关键结论数字汇总')
print('样本区间: 2018-09-03 ~ 2026-06-09,', len(sample), '个交易日（收益观测', len(R), '）')
print('当前组合: 最大压力损失', pct(maxloss['当前组合']['loss']), '| ES99', pct(M['当前组合']['es99']),
      '| 10日VaR99', pct(M['当前组合']['var99_10']), '| 最大回撤', pct(M['当前组合']['maxdd']))
for n in ['方案A', '方案B', '方案C', '推荐方案']:
    print(f'{n}: 最大压力损失 {pct(maxloss[n]["loss"])}（{maxloss[n]["sid"]}/{maxloss[n]["tag"]}）'
          f' | ES99 {pct(M[n]["es99"])} | 10日VaR99 {pct(M[n]["var99_10"])}')
print('推荐方案: 权重 =', dict(zip(names.values(), [f'{x*100:.2f}%' for x in w_rec])),
      '| 单向换手率', f'{sells/NAV*100:.2f}%', '| C9 裕度', f'{(0.07-maxloss["推荐方案"]["loss"])*100:.2f}pp',
      '| 反向7%马氏距离', f'{d7:.2f}')
print('监测触发:', MON[MON.triggered][['monitor_id', 'latest_value']].to_dict('records'))
print('\n全部计算完成。')
