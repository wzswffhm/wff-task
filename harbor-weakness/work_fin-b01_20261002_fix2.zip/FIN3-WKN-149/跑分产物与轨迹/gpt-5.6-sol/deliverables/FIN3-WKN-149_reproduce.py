from pathlib import Path
import glob, re, math, warnings
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib import font_manager

warnings.filterwarnings('ignore')

OUT = Path(__file__).resolve().parent
BASE = OUT.parent / 'input_files'
CHART = OUT / 'FIN3-WKN-149_charts'
CHART.mkdir(parents=True, exist_ok=True)
ASOF = pd.Timestamp('2026-09-15')
TOTAL = 10000.0

# Use an installed CJK font so every generated figure keeps Chinese labels.
for family in ['Noto Sans CJK SC', 'Noto Serif CJK SC', 'Noto Sans Mono CJK SC']:
    if any(family in f.name for f in font_manager.fontManager.ttflist):
        plt.rcParams['font.sans-serif'] = [family]
        break
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['figure.dpi'] = 130

ASSET_NAMES = ['沪深300', '中证500', '创业板', '国债', '美元现金', '标普500人民币', '人民币现金']
EQ_KEYS = ['EQ_000300', 'EQ_000905', 'EQ_399006']
ASSET_KEY = {'沪深300':'EQ_000300','中证500':'EQ_000905','创业板':'EQ_399006','国债':'CGB','美元现金':'USD_CASH','标普500人民币':'SPX','人民币现金':'CNY_CASH'}
KEY_TO_ASSET = {v:k for k,v in ASSET_KEY.items()}


def read_csv(name, parse_dates=True):
    df = pd.read_csv(BASE / name)
    if parse_dates and 'date' in df:
        df['date'] = pd.to_datetime(df['date'])
    return df


def concat_segments(prefix):
    files = sorted(glob.glob(str(BASE / f'{prefix}_seg*.csv')))
    df = pd.concat([pd.read_csv(f) for f in files], ignore_index=True)
    df['date'] = pd.to_datetime(df['date'])
    df = df.sort_values('date').reset_index(drop=True)
    return df, [Path(f).name for f in files]


def series_from_file(name, value_col):
    d = read_csv(name)[['date', value_col]].drop_duplicates('date').set_index('date')[value_col]
    return d.sort_index()


def aligned_daily(s, calendar):
    s = s.sort_index()
    first, last = s.first_valid_index(), s.last_valid_index()
    out = s.reindex(calendar)
    out = out.ffill()
    out.loc[out.index < first] = np.nan
    out.loc[out.index > last] = np.nan
    return out


def pct(x): return f'{x*100:.2f}%'
def bp(x): return f'{x:.2f}bp'
def amt(x): return f'{x:,.2f}'
def dstr(x): return pd.Timestamp(x).strftime('%Y-%m-%d') if pd.notna(x) else '—'
def signpct(x): return f'{x*100:+.2f}%'
def signbp(x): return f'{x:+.2f}bp'

def parse_cgb_shock(text):
    out = {}
    for tenor, value in re.findall(r'(1Y|2Y|5Y|10Y|30Y):([+-]?\d+(?:\.\d+)?)', text):
        out[tenor] = float(value)  # source values are percentage points; 0.20 = 20 bp
    return out


def cumulative_return(s):
    s = s.dropna()
    return (1 + s).prod() - 1 if len(s) else np.nan


def format_table(df, index=False):
    data = df.copy()
    if index:
        data = data.reset_index()
    cols = [str(c) for c in data.columns]
    rows = [[str(v) for v in row] for row in data.astype(object).where(data.notna(), '—').values.tolist()]
    widths = [max(len(cols[j]), *(len(r[j]) for r in rows)) if rows else len(cols[j]) for j in range(len(cols))]
    header = '| ' + ' | '.join(cols[j].ljust(widths[j]) for j in range(len(cols))) + ' |'
    sep = '| ' + ' | '.join('-' * widths[j] for j in range(len(cols))) + ' |'
    body = ['| ' + ' | '.join(r[j].ljust(widths[j]) for j in range(len(cols))) + ' |' for r in rows]
    return '\n'.join([header, sep] + body)

# ----------------------------- Data validation -----------------------------
cal_raw = read_csv('snapshot_trade_calendar.csv')
calendar = cal_raw.loc[(cal_raw['exchange'] == 'SSE') & (cal_raw['is_trading_day'] == 1), 'date'].drop_duplicates().sort_values()
calendar = pd.DatetimeIndex(calendar)

manifest = read_csv('snapshot_data_manifest.csv', parse_dates=False)
validation_rows = []
validation_anomalies = []

def validate_file(name, value_cols=None, daily=True):
    df = read_csv(name)
    dates = df['date']
    observed = pd.DatetimeIndex(dates.dropna().drop_duplicates()).sort_values()
    row = {'file':name, 'records_actual':len(df), 'actual_start':observed.min() if len(observed) else pd.NaT, 'actual_end':observed.max() if len(observed) else pd.NaT,
           'manifest_records': manifest.loc[manifest.file.eq(name), 'records'].iloc[0] if any(manifest.file.eq(name)) else np.nan,
           'manifest_end': manifest.loc[manifest.file.eq(name), 'end'].iloc[0] if any(manifest.file.eq(name)) else '',
           'nulls':int(df.isna().sum().sum()), 'gaps':'—'}
    dup = int(dates.duplicated().sum())
    bad_dates = int(dates.isna().sum())
    if dup or bad_dates:
        validation_anomalies.append(f'{name}: 重复日期 {dup} 条，非法/空日期 {bad_dates} 条')
    if daily and len(observed):
        expected = calendar[(calendar >= observed.min()) & (calendar <= observed.max())]
        missing = expected.difference(observed)
        row['gaps'] = f'{len(missing)} 个上交所交易日' if len(missing) else '无'
        if len(missing): validation_anomalies.append(f'{name}: 覆盖区间内缺少 {len(missing)} 个上交所交易日（未按0填充）')
        non_sse = observed.difference(calendar)
        if len(non_sse): validation_anomalies.append(f'{name}: {len(non_sse)} 条记录不在上交所交易日历')
    if value_cols:
        for c in value_cols:
            vals = pd.to_numeric(df[c], errors='coerce')
            if vals.isna().any():
                validation_anomalies.append(f'{name}.{c}: {int(vals.isna().sum())} 个空值')
            if c not in ['yield_pct','pmi_mfg','ppi_yoy','afre_stock','lpr_1y','lpr_5y','dr007','shibor_on','shibor_1w'] and (vals.dropna() <= 0).any():
                validation_anomalies.append(f'{name}.{c}: 存在非正值')
    validation_rows.append(row)

# Validate every raw snapshot before any return or scenario calculation.
for name in sorted(Path(BASE).glob('snapshot_*.csv')):
    name = name.name
    if name == 'snapshot_data_manifest.csv':
        continue
    df0 = read_csv(name, parse_dates=False)
    value_cols = [c for c in df0.columns if c not in ['date','exchange','is_trading_day']]
    daily = not any(x in name for x in ['pmi','ppi','afre','lpr_'])
    validate_file(name, value_cols, daily=daily)

# Explicitly separate structural missing values from market-date gaps.
for name, col in [('snapshot_000300SH_seg1.csv','pre_close'), ('snapshot_000905SH_seg1.csv','pre_close'), ('snapshot_399006SZ_seg1.csv','pre_close')]:
    validation_anomalies.append(f'{name}.{col}: 首条记录为空，为无前一交易日的结构性空值，不参与计算')
validation_anomalies.append('snapshot_lpr_5y.csv.lpr_5y: 2018-01-02至2019-08-16为结构性空值；月度规则仅使用月内最后一个非空观测，不向前填充')
validation_anomalies.append('snapshot_ust_m4.csv: 仅有 6 条观测，作为覆盖核验记录；不进入组合历史收益、情景规则或限额计算')

# ----------------------------- Raw series and aligned prices -----------------------------
eq_files = {'沪深300':'000300SH','中证500':'000905SH','创业板':'399006SZ'}
eq_raw = {}
eq_close = {}
for asset, code in eq_files.items():
    d, files = concat_segments(f'snapshot_{code}')
    eq_raw[asset] = d
    eq_close[asset] = aligned_daily(d.set_index('date')['close'], calendar)

usdcnh_raw, _ = concat_segments('snapshot_usdcnh')
usdcnh = aligned_daily(usdcnh_raw.set_index('date')['usdcnh'], calendar)
spx_raw = read_csv('snapshot_spx.csv')
spx = aligned_daily(spx_raw.set_index('date')['close'], calendar)

yield_series = {}
for tenor, fname in [('1Y','snapshot_cgb_yield_1y.csv'),('2Y','snapshot_cgb_yield_2y.csv'),('5Y','snapshot_cgb_yield_5y.csv'),('10Y','snapshot_cgb_yield_10y.csv'),('30Y','snapshot_cgb_yield_30y.csv')]:
    yield_series[tenor] = aligned_daily(series_from_file(fname,'yield_pct'), calendar)
yields = pd.DataFrame(yield_series, index=calendar)
duration = read_csv('params_duration.csv').set_index('tenor')['duration_contribution'].to_dict()
DUR = pd.Series({'1Y':duration['1年'],'2Y':duration['2年'],'5Y':duration['5年'],'10Y':duration['10年'],'30Y':duration['30年']})

# Common risk sample is the intersection of all daily market series used in returns.
market_daily = pd.DataFrame({**eq_close, 'usdcnh':usdcnh, 'spx':spx})
market_daily = market_daily.join(yields)
common = market_daily.dropna().index
hist_start = common.min()
hist_end = common.max()
hist_prices = market_daily.loc[common]

# ----------------------------- Daily asset returns -----------------------------
ret = pd.DataFrame(index=common[1:])
for asset in ['沪深300','中证500','创业板']:
    ret[asset] = hist_prices[asset].pct_change()
ret['国债'] = -(hist_prices[DUR.index].diff().mul(DUR, axis=1).sum(axis=1) / 100).iloc[1:]
ret['美元现金'] = hist_prices['usdcnh'].pct_change().iloc[1:]
ret['标普500人民币'] = ((hist_prices['spx'] / hist_prices['spx'].shift(1)) * (hist_prices['usdcnh'] / hist_prices['usdcnh'].shift(1)) - 1).iloc[1:]
# No cash-rate series is supplied for the RMB money fund; principal-only proxy is explicit, not null imputation.
ret['人民币现金'] = 0.0
ret = ret.dropna()

holdings = read_csv('params_holdings.csv')
positions = read_csv('params_positions.csv')
plans = read_csv('plans_candidates.csv')
limits = read_csv('params_limits.csv').set_index('id')
check_rules = read_csv('rules_checks.csv').set_index('check_id')
weight_tol = float(re.search(r'容差 ([0-9.]+) 个百分点', check_rules.loc['C1','description']).group(1)) / 100
current_weights = dict(zip(holdings['asset_class'], holdings['weight_current']))
recommended_weights = dict(zip(holdings['asset_class'], holdings['weight_recommended']))
plan_weights = {}
for _, r in plans.iterrows():
    plan_weights[r['plan_id']] = {'EQ_000300':r.w_000300,'EQ_000905':r.w_000905,'EQ_399006':r.w_399006,'CGB':r.w_cgb,'USD_CASH':r.w_usd_cash,'SPX':r.w_spx_qdii,'CNY_CASH':r.w_cny_cash}
all_weights = {'当前组合':current_weights, **plan_weights, '推荐方案':recommended_weights}


def weight_vector(weights):
    return np.array([weights[ASSET_KEY[a]] for a in ASSET_NAMES], dtype=float)

def portfolio_series(weights):
    return ret[ASSET_NAMES].dot(weight_vector(weights))

def metrics(weights):
    p = portfolio_series(weights)
    losses = -p
    var95, var99 = np.quantile(losses, [.95,.99])
    es95 = losses[losses >= var95].mean()
    es99 = losses[losses >= var99].mean()
    r10 = (1+p).rolling(10).apply(np.prod, raw=True)-1
    loss10 = -r10.dropna()
    nav = (1+p).cumprod()
    running = nav.cummax()
    dd = nav / running - 1
    trough = dd.idxmin()
    peak_date = nav.loc[:trough].idxmax()
    peak_value = nav.loc[peak_date]
    recovery = nav.loc[trough:][nav.loc[trough:] >= peak_value]
    recovery_date = recovery.index[0] if len(recovery) else pd.NaT
    cov = ret[ASSET_NAMES].cov().values
    w = weight_vector(weights)
    pvar = float(w @ cov @ w)
    rc = w * (cov @ w) / pvar
    return {'daily':p, 'nav':nav, 'annual_vol':p.std()*np.sqrt(252), 'var95':var95, 'var99':var99, 'es95':es95, 'es99':es99,
            'var10':np.quantile(loss10,.99), 'max10':loss10.max(), 'max10_end':loss10.idxmax(), 'max10_start':loss10.index[max(0, loss10.index.get_loc(loss10.idxmax())-9)],
            'maxdd':-dd.min(), 'dd_peak':peak_date, 'dd_trough':trough, 'dd_recovery':recovery_date, 'worst_day':losses.max(), 'worst_day_date':losses.idxmax(), 'rc':rc}

metric_all = {k:metrics(v) for k,v in all_weights.items()}

# ----------------------------- Monthly scenarios -----------------------------
def monthly_last(name, col):
    d = read_csv(name).set_index('date')[col].sort_index()
    return d.groupby(d.index.to_period('M')).last().set_axis(pd.PeriodIndex(d.groupby(d.index.to_period('M')).last().index, freq='M'))

def monthly_mean(name, col):
    d = read_csv(name).set_index('date')[col].sort_index()
    return d.groupby(d.index.to_period('M')).mean()

def monthly_price_return(s):
    return s.groupby(s.index.to_period('M')).agg(lambda x: x.iloc[-1]/x.iloc[0]-1)

pmi = monthly_last('snapshot_pmi_manufacturing.csv','pmi_mfg')
ppi = monthly_last('snapshot_ppi_yoy.csv','ppi_yoy')
lpr1 = monthly_last('snapshot_lpr_1y.csv','lpr_1y')
lpr5 = monthly_last('snapshot_lpr_5y.csv','lpr_5y')
afre = monthly_last('snapshot_afre_stock.csv','afre_stock')
drf = monthly_mean('snapshot_dr007.csv','dr007')
cgb10_month = yields['10Y'].dropna().groupby(yields['10Y'].dropna().index.to_period('M')).mean()
eq_month = monthly_price_return(eq_raw['沪深300'].set_index('date')['close'])
spx_month = monthly_price_return(spx_raw.set_index('date')['close'])
fx_month = monthly_price_return(usdcnh_raw.set_index('date')['usdcnh'])
months = pd.period_range(min(pmi.index.min(), eq_month.index.min()), max(pmi.index.max(), eq_month.index.max()), freq='M')
m = pd.DataFrame(index=months)
for name, s in [('pmi',pmi),('ppi',ppi),('lpr1',lpr1),('lpr5',lpr5),('cgb10',cgb10_month),('eqret',eq_month),('spxret',spx_month),('fxret',fx_month),('afre',afre),('dr007',drf)]: m[name]=s.reindex(months)
m['pmi_diff']=m.pmi.diff(); m['lpr1_diff']=m.lpr1.diff(); m['lpr5_diff']=m.lpr5.diff(); m['cgb10_diff']=m.cgb10.diff(); m['ppi_diff']=m.ppi.diff(); m['afre_yoy']=m.afre.pct_change(12); m['afre_yoy_diff']=m.afre_yoy.diff(); m['dr_diff']=m.dr007.diff()
qual = {}
qual['S1'] = ((m.pmi < 50) & ((m.lpr1_diff < 0) | (m.lpr5_diff < 0))) | ((m.pmi_diff <= -0.5) & (m.cgb10_diff < 0))
qual['S2'] = (m.ppi_diff > 0) & (m.cgb10_diff > 0) & (m.eqret < 0)
qual['S3'] = (m.spxret <= -0.03) | (m.fxret >= 0.015)
qual['S4'] = (m.afre_yoy_diff < 0) & (m.dr_diff > 0) & (m.eqret < 0)
for k in qual: qual[k] = m.index[qual[k].fillna(False)].tolist()

shocks = read_csv('params_committee_shocks.csv')
shock_dict = {}
for _, r in shocks.iterrows():
    shock_dict[r.scenario_id] = {'scenario':r.scenario, 'cn':r.cn_equity_shock, 'spx':r.spx_usd_shock, 'fx':r.usdcnh_shock, 'cgb':parse_cgb_shock(r.cgb_shock_bp)}

def factor_window(win):
    pre = hist_prices.index[hist_prices.index.get_loc(win[0])-1]
    post = win[-1]
    eq_w = np.array([current_weights[k] for k in EQ_KEYS]); eq_w = eq_w/eq_w.sum()
    dom_daily = ret.loc[win, ['沪深300','中证500','创业板']].values @ eq_w
    return {'cn':(1+dom_daily).prod()-1, 'spx':hist_prices.loc[post,'spx']/hist_prices.loc[pre,'spx']-1, 'fx':hist_prices.loc[post,'usdcnh']/hist_prices.loc[pre,'usdcnh']-1,
            'cgb':{t:(hist_prices.loc[post,t]-hist_prices.loc[pre,t])*100 for t in DUR.index}, 'start':win[0], 'end':win[-1], 'port':(1+ret.loc[win,ASSET_NAMES].dot(weight_vector(current_weights))).prod()-1}

window_records = {sid:[] for sid in qual}
fallback_records = {sid:[] for sid in qual}
for sid, qmonths in qual.items():
    for month in qmonths:
        after = hist_prices.index[hist_prices.index > month.to_timestamp(how='end')]
        if len(after) < 10: continue
        win = after[:10]
        if win[-1] > hist_end: continue
        p = ret.loc[win, ASSET_NAMES].dot(weight_vector(current_weights))
        if len(p) == 10:
            rec = factor_window(win)
            if (p < 0).all():
                window_records[sid].append(rec)
            fallback_records[sid].append(rec)
selected_windows = {}
calibration = {}
window_selection_mode = {}
for sid, rows in window_records.items():
    strict_rows = sorted(rows, key=lambda z:z['port'])
    if strict_rows:
        chosen = strict_rows[:min(20,len(strict_rows))]
        window_selection_mode[sid] = '严格条件'
    else:
        # The supplied data has no ten-day run with every daily return negative.
        # Use the same qualified-month windows ranked by cumulative loss so all required stress cells remain computable, and disclose the fallback.
        chosen = sorted(fallback_records[sid], key=lambda z:z['port'])[:min(20,len(fallback_records[sid]))]
        window_selection_mode[sid] = '累计跌幅排序回退'
    selected_windows[sid] = chosen
    calibration[sid] = {'cn':np.median([x['cn'] for x in chosen]) if chosen else np.nan,
                        'spx':np.median([x['spx'] for x in chosen]) if chosen else np.nan,
                        'fx':np.median([x['fx'] for x in chosen]) if chosen else np.nan,
                        'cgb':{t:np.median([x['cgb'][t] for x in chosen]) if chosen else np.nan for t in DUR.index}}

# ----------------------------- Stress tests -----------------------------
def stress_components(weights, cn, spx_usd, fx, cgb_pct):
    domestic = sum(weights[k]*cn for k in EQ_KEYS)
    spx_rmb = weights['SPX']*((1+spx_usd)*(1+fx)-1)
    usd = weights['USD_CASH']*fx
    bond_return = -sum(DUR[t]*(cgb_pct[t]/100) for t in DUR.index)
    cgb = weights['CGB']*bond_return
    return {'境内权益':domestic, '标普500（人民币计）':spx_rmb, '美元现金':usd, '国债':cgb, '组合损益':domestic+spx_rmb+usd+cgb}

stress_rows=[]
for sid, sd in shock_dict.items():
    for shock_type in ['委员会沿用','历史校准']:
        if shock_type == '委员会沿用':
            cn, spxv, fxv, cgb = sd['cn'], sd['spx'], sd['fx'], sd['cgb']
        else:
            ca = calibration[sid]; cn, spxv, fxv = ca['cn'], ca['spx'], ca['fx']; cgb = {t:ca['cgb'][t]/100 for t in DUR.index}
        for plan, weights in all_weights.items():
            comp = stress_components(weights, cn, spxv, fxv, cgb)
            stress_rows.append({'方案':plan,'情景编号':sid,'情景':sd['scenario'],'冲击':shock_type,**comp,'压力损失':-comp['组合损益']})
stress = pd.DataFrame(stress_rows)

# Candidate plus recommendation limit checks.
def check_plan(plan, weights, recommended=False):
    mm=metric_all[plan]; ss=stress.loc[stress.方案.eq(plan)]
    vals = {'L1':sum(weights.values()), 'L2':sum(weights[k] for k in EQ_KEYS), 'L3':weights['CNY_CASH'], 'L4':weights['CGB'], 'L5':weights['USD_CASH']+weights['SPX'], 'L6':mm['es99'], 'L7':mm['var10'], 'L8':ss['压力损失'].max(), 'L9':ss['压力损失'].max()}
    passfail = {'L1':abs(vals['L1']-limits.loc['L1','upper'])<=weight_tol,'L2':vals['L2']<=limits.loc['L2','upper'],'L3':limits.loc['L3','lower']<=vals['L3']<=limits.loc['L3','upper'],'L4':vals['L4']>=limits.loc['L4','upper'],'L5':vals['L5']<=limits.loc['L5','upper'],'L6':vals['L6']<=limits.loc['L6','upper'],'L7':vals['L7']<=limits.loc['L7','upper'],'L8':vals['L8']<=limits.loc['L8','upper'],'L9':(vals['L9']<=limits.loc['L9','upper'] if recommended else None)}
    return vals, passfail
checks = {k:check_plan(k,v,k=='推荐方案') for k,v in all_weights.items()}

# Same-turnover comparator: preserve cash/bond/external weights, but shift one percentage point toward the higher-volatility growth index.
alt_weights = recommended_weights.copy(); alt_weights['EQ_000300'] -= .01; alt_weights['EQ_399006'] += .01
all_weights['同换手次优比较'] = alt_weights
metric_all['同换手次优比较'] = metrics(alt_weights)
alt_stress = []
for sid, sd in shock_dict.items():
    for shock_type in ['委员会沿用','历史校准']:
        ca = calibration[sid] if shock_type=='历史校准' else None
        comp = stress_components(alt_weights, sd['cn'] if ca is None else ca['cn'], sd['spx'] if ca is None else ca['spx'], sd['fx'] if ca is None else ca['fx'], sd['cgb'] if ca is None else {t:ca['cgb'][t]/100 for t in DUR.index})
        alt_stress.append({'情景编号':sid,'冲击':shock_type,**comp,'压力损失':-comp['组合损益']})
alt_max_stress=max(x['压力损失'] for x in alt_stress)
rec_max_stress=stress.loc[stress.方案.eq('推荐方案'),'压力损失'].max()

# ----------------------------- Reverse stress and monitoring -----------------------------
# All rolling 10-day factor vectors supply the historical mean/covariance.
factor_rows=[]
for i in range(10, len(hist_prices)):
    win=hist_prices.index[i-9:i+1]; factor_rows.append(factor_window(win))
F = np.array([[r['cn'],r['spx'],r['fx'],*(r['cgb'][t] for t in DUR.index)] for r in factor_rows])
factor_names=['境内权益','标普500美元','USD/CNH','1Y国债','2Y国债','5Y国债','10Y国债','30Y国债']
fmean=F.mean(axis=0); fcov=np.cov(F,rowvar=False); fcov=fcov+np.eye(F.shape[1])*1e-10; finv=np.linalg.pinv(fcov)

def factor_distance(x):
    z=x-fmean; return float(np.sqrt(z@finv@z))
committee_vectors={sid:np.array([sd['cn'],sd['spx'],sd['fx'],*(sd['cgb'][t]*100 for t in DUR.index)]) for sid,sd in shock_dict.items()}
cal_vectors={sid:np.array([calibration[sid]['cn'],calibration[sid]['spx'],calibration[sid]['fx'],*(calibration[sid]['cgb'][t] for t in DUR.index)]) for sid in calibration}
committee_dist={sid:factor_distance(v) for sid,v in committee_vectors.items()}; cal_dist={sid:factor_distance(v) for sid,v in cal_vectors.items()}
nearest_sid=min(committee_dist,key=committee_dist.get)
# Minimum-distance linear reverse stress to the 7% recommendation buffer.
wrec=weight_vector(recommended_weights); coeff=np.array([-sum(recommended_weights[k] for k in EQ_KEYS), -recommended_weights['SPX'], -(recommended_weights['SPX']+recommended_weights['USD_CASH']), *(recommended_weights['CGB']*DUR[t]/10000 for t in DUR.index)])
target=limits.loc['L9','upper']; base_loss=-coeff@fmean; denom=float(coeff@fcov@coeff); lam=(target-base_loss)/denom
reverse_vec=fmean+fcov@coeff*lam
reverse_dist=factor_distance(reverse_vec)
reverse_loss=float(coeff@reverse_vec)

# Monitoring indicators from latest available observations.
def last20_change(s, factor=1.0):
    s=s.dropna(); return s.iloc[-1]/s.iloc[-21]-1 if len(s)>=21 else np.nan
m1=last20_change(eq_close['沪深300'].loc[:ASOF])
m2=last20_change(usdcnh.loc[:ASOF])
dr=read_csv('snapshot_dr007.csv').set_index('date')['dr007'].sort_index(); dr_recent=dr.loc[:ASOF].tail(20).mean(); dr_prior=dr.loc[:ASOF].iloc[-80:-20].mean(); m3=(dr_recent-dr_prior)*100
cgb10=series_from_file('snapshot_cgb_yield_10y.csv','yield_pct'); m4=(cgb10.iloc[-1]-cgb10.iloc[-21])*100 if len(cgb10)>=21 else np.nan
ust10=series_from_file('snapshot_ust_10y.csv','yield_pct'); m5=(ust10.loc[:ASOF].iloc[-1]-ust10.loc[:ASOF].iloc[-21])*100
ppi_raw=read_csv('snapshot_ppi_yoy.csv').set_index('date')['ppi_yoy']; m6=ppi_raw.iloc[-1]-ppi_raw.iloc[-4]
pmi_raw=read_csv('snapshot_pmi_manufacturing.csv').set_index('date')['pmi_mfg']; m7=pmi_raw.iloc[-1]
afre_raw=read_csv('snapshot_afre_stock.csv').set_index('date')['afre_stock']; m8=afre_raw.iloc[-1]/afre_raw.iloc[-13]-1
monitor = pd.DataFrame([
 ['M1','沪深300 20 日收益',m1,-.05,'低于阈值触发',dstr(eq_close['沪深300'].dropna().index[-1])],
 ['M2','USD/CNH 20 日变化',m2,.02,'高于阈值触发',dstr(usdcnh.dropna().index[-1])],
 ['M3','DR007 资金面变化',m3,20.0,'高于阈值触发',dstr(dr.index[-1])],
 ['M4','10 年期国债收益率 20 日变化',m4,10.0,'高于阈值触发',dstr(cgb10.index[-1])],
 ['M5','美国 10 年期国债收益率 20 日变化',m5,40.0,'高于阈值触发',dstr(ust10.index[-1])],
 ['M6','PPI 同比加速',m6,1.5,'高于阈值触发',dstr(ppi_raw.index[-1])],
 ['M7','制造业 PMI 荣枯线',m7,49.0,'低于阈值触发',dstr(pmi_raw.index[-1])],
 ['M8','社融存量增速',m8,.08,'低于阈值触发',dstr(afre_raw.index[-1])],
 ], columns=['id','indicator','value','threshold','direction','asof'])
monitor['triggered']=[(r.value<r.threshold if r.direction.startswith('低于') else r.value>r.threshold) for _,r in monitor.iterrows()]
monitor['status']=np.where(monitor.triggered,'触发','正常')
monitor.loc[monitor.id.isin(['M4','M6','M7','M8']) & (monitor['asof'] != dstr(ASOF)), 'status'] = monitor.loc[monitor.id.isin(['M4','M6','M7','M8']) & (monitor['asof'] != dstr(ASOF)), 'status'] + '（数据非分析日）'

# ----------------------------- Charts -----------------------------
def savefig(name):
    plt.tight_layout(); plt.savefig(CHART/name, dpi=180, bbox_inches='tight'); plt.close()

def chart01():
    fig, ax=plt.subplots(figsize=(13,10)); rows=validation_rows; y=np.arange(len(rows))
    starts=[r['actual_start'] for r in rows]; ends=[r['actual_end'] for r in rows]
    ax.barh(y, [e-s for s,e in zip(starts,ends)], left=starts, height=.65, color='#4472C4')
    ax.axvline(ASOF, color='#C00000', ls='--', label='分析截至日 2026-09-15')
    ax.axvline(hist_end, color='#ED7D31', ls=':', label='共同历史样本终止 2026-06-09')
    ax.set_yticks(y); ax.set_yticklabels([r['file'].replace('snapshot_','') for r in rows], fontsize=7); ax.invert_yaxis(); ax.xaxis.set_major_locator(mdates.YearLocator()); ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y')); ax.set_title('数据覆盖区间、缺口与分析截至日'); ax.legend(loc='lower right'); ax.grid(axis='x', alpha=.25); savefig('FIN3-WKN-149_chart01_数据覆盖与缺口.png')

def chart02():
    fig,ax=plt.subplots(figsize=(12,6))
    for name in ['当前组合','方案A','方案B','方案C','推荐方案']:
        ax.plot(metric_all[name]['nav'].index, metric_all[name]['nav'], label=name, lw=1.5)
    ax.set_title('历史累计净值（共同样本）'); ax.set_ylabel('累计净值'); ax.legend(ncol=3); ax.grid(alpha=.25); savefig('FIN3-WKN-149_chart02_方案累计净值.png')

def chart03():
    names=['当前组合','方案A','方案B','方案C','推荐方案']; labels=['1日 ES99','10日 VaR99','最大压力损失']; vals=np.array([[metric_all[n]['es99'],metric_all[n]['var10'],stress.loc[stress.方案.eq(n),'压力损失'].max()] for n in names]).T
    fig,axs=plt.subplots(1,3,figsize=(14,5))
    limit_values=[limits.loc['L6','upper'],limits.loc['L7','upper'],limits.loc['L8','upper']]
    for j,ax in enumerate(axs): ax.bar(names,vals[j]*100,color=['#5B9BD5','#70AD47','#ED7D31','#A5A5A5','#4472C4']); ax.axhline(limit_values[j]*100,color='#C00000',ls='--'); ax.set_title(labels[j]); ax.set_ylabel('%'); ax.tick_params(axis='x',rotation=35); ax.grid(axis='y',alpha=.25)
    fig.suptitle('历史风险指标与限额参考线'); savefig('FIN3-WKN-149_chart03_风险指标与限额.png')

def chart04():
    fig,ax=plt.subplots(figsize=(13,5)); colors=['#4472C4','#ED7D31','#70AD47','#A5A5A5']
    for i,(sid,ms) in enumerate(qual.items()):
        ax.scatter([x.to_timestamp() for x in ms],[i]*len(ms),label=sid,color=colors[i],s=22)
    ax.set_yticks(range(4)); ax.set_yticklabels([f'{sid} {shock_dict[sid]["scenario"]}' for sid in qual]); ax.set_title('四情景月度识别结果'); ax.xaxis.set_major_locator(mdates.YearLocator()); ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y')); ax.grid(axis='x',alpha=.25); savefig('FIN3-WKN-149_chart04_情景合格月份.png')

def chart05():
    fig,axs=plt.subplots(1,4,figsize=(15,5)); sids=list(qual)
    for j,sid in enumerate(sids):
        c=calibration[sid]; vals=[c['cn']*100,c['spx']*100,c['fx']*100,sum(DUR[t]*c['cgb'][t] for t in DUR.index)/DUR.sum()]
        axs[j].bar(['境内权益%','标普美元%','汇率%','久期加权国债bp'],[vals[0],vals[1],vals[2],vals[3]],color=['#4472C4','#ED7D31','#70AD47','#A5A5A5']); axs[j].axhline(0,color='black',lw=.7); axs[j].set_title(f'{sid}\n窗口 {len(selected_windows[sid])} 个'); axs[j].tick_params(axis='x',rotation=60); axs[j].grid(axis='y',alpha=.2)
    fig.suptitle('历史窗口校准冲击（中位数）'); savefig('FIN3-WKN-149_chart05_历史窗口校准冲击.png')

def chart06():
    fig,ax=plt.subplots(figsize=(12,6)); sids=list(qual); x=np.arange(4); width=.18
    for j,sid in enumerate(sids):
        comm=stress[(stress.方案.eq('推荐方案'))&(stress['情景编号'].eq(sid))&(stress.冲击.eq('委员会沿用'))]['压力损失'].iloc[0]*100
        cal=stress[(stress.方案.eq('推荐方案'))&(stress['情景编号'].eq(sid))&(stress.冲击.eq('历史校准'))]['压力损失'].iloc[0]*100
        ax.bar(j-width/2,comm,width,label='委员会沿用' if j==0 else '',color='#C00000'); ax.bar(j+width/2,cal,width,label='历史校准' if j==0 else '',color='#70AD47')
    ax.axhline(limits.loc['L9','upper']*100,color='#ED7D31',ls='--',label=f'推荐方案 {limits.loc["L9","upper"]*100:.0f}%缓冲线'); ax.set_xticks(x); ax.set_xticklabels(sids); ax.set_ylabel('压力损失 (%)'); ax.set_title('推荐方案两套冲击的严格程度对比'); ax.legend(); ax.grid(axis='y',alpha=.25); savefig('FIN3-WKN-149_chart06_两套冲击对比.png')

def chart07():
    names=['当前组合','方案A','方案B','方案C','推荐方案']; vals=[stress.loc[stress.方案.eq(n),'压力损失'].max()*100 for n in names]; fig,ax=plt.subplots(figsize=(11,5)); ax.bar(names,vals,color=['#A5A5A5','#ED7D31','#70AD47','#5B9BD5','#4472C4']); ax.axhline(limits.loc['L8','upper']*100,color='#C00000',ls='--',label=f'{limits.loc["L8","upper"]*100:.0f}%压力损失上限'); ax.axhline(limits.loc['L9','upper']*100,color='#ED7D31',ls=':',label=f'{limits.loc["L9","upper"]*100:.0f}%推荐缓冲线'); ax.set_ylabel('最大压力损失 (%)'); ax.set_title('方案决策与压力损失限额'); ax.legend(); ax.grid(axis='y',alpha=.25); savefig('FIN3-WKN-149_chart07_方案决策与限额.png')

def chart08():
    equity_sell=sum(max(current_weights[k]-recommended_weights[k],0) for k in EQ_KEYS); cgb_buy=max(recommended_weights['CGB']-current_weights['CGB'],0); cny_buy=max(recommended_weights['CNY_CASH']-current_weights['CNY_CASH'],0); cash0=current_weights['CNY_CASH']; cash_floor=limits.loc['L3','lower']; steps_sell=[cash0,cash0+equity_sell,cash0+equity_sell-cgb_buy,recommended_weights['CNY_CASH']]; steps_buy=[cash0,cash0-cgb_buy,cash0-cgb_buy-cny_buy,recommended_weights['CNY_CASH']]; fig,ax=plt.subplots(figsize=(10,5)); x=np.arange(4); ax.plot(x,np.array(steps_sell)*100,marker='o',label='先卖后买（可用/现金资产）'); ax.plot(x,np.array(steps_buy)*100,marker='o',label='先买后卖（现金资产）'); ax.axhline(cash_floor*100,color='#C00000',ls='--',label=f'{cash_floor*100:.0f}%现金下限'); ax.set_xticks(x); ax.set_xticklabels(['起点','第一笔','第二笔','完成']); ax.set_ylabel('现金占比 (%)'); ax.set_title('调仓现金路径'); ax.legend(); ax.grid(alpha=.25); savefig('FIN3-WKN-149_chart08_调仓现金路径.png')

def chart09():
    fig,ax=plt.subplots(figsize=(12,5)); labels=['境内权益','标普500美元','USD/CNH','久期加权国债bp']; near=committee_vectors[nearest_sid]; rev=reverse_vec; near4=[near[0]*100,near[1]*100,near[2]*100,sum(DUR[t]*near[3+i] for i,t in enumerate(DUR.index))/DUR.sum()]; rev4=[rev[0]*100,rev[1]*100,rev[2]*100,sum(DUR[t]*rev[3+i] for i,t in enumerate(DUR.index))/DUR.sum()]; x=np.arange(4); ax.bar(x-.18,near4,.36,label=f'最近委员会情景 {nearest_sid}（距离 {committee_dist[nearest_sid]:.2f}）',color='#C00000'); ax.bar(x+.18,rev4,.36,label=f'7%边界反向解（距离 {reverse_dist:.2f}）',color='#4472C4'); ax.axhline(0,color='black',lw=.7); ax.set_xticks(x); ax.set_xticklabels(labels); ax.set_title('反向压力测试：最近情景与7%边界最小距离解'); ax.legend(); ax.grid(axis='y',alpha=.25); savefig('FIN3-WKN-149_chart09_反向压力测试.png')

def chart10():
    fig,axs=plt.subplots(2,4,figsize=(14,7));
    for ax,(_,r) in zip(axs.ravel(),monitor.iterrows()):
        actual=r.value; threshold=r.threshold; scale=100 if r.id in ['M1','M2','M6','M8'] else 1
        ax.bar(['最新值','阈值'],[actual*scale,threshold*scale],color=['#C00000' if r.triggered else '#4472C4','#A5A5A5']); ax.set_title(f'{r.id} {r.indicator}',fontsize=9); ax.tick_params(axis='x',labelrotation=35); ax.grid(axis='y',alpha=.2); ax.text(.5,.92,'触发' if r.triggered else '正常',transform=ax.transAxes,ha='center',color='#C00000' if r.triggered else '#4472C4',fontsize=10)
    fig.suptitle('八个监测指标最新值与阈值'); savefig('FIN3-WKN-149_chart10_监测指标触发状态.png')

for f in [chart01,chart02,chart03,chart04,chart05,chart06,chart07,chart08,chart09,chart10]: f()

# ----------------------------- Memo -----------------------------
current_m=metric_all['当前组合']; rec_m=metric_all['推荐方案']; rec_vals, rec_pass=checks['推荐方案']

pos_tbl=positions[['asset','weight_current','market_value_10k_cny']].copy(); pos_tbl.columns=['资产','权重','金额（万元）']; pos_tbl['权重']=pos_tbl['权重'].map(pct); pos_tbl['金额（万元）']=pos_tbl['金额（万元）'].map(amt)
rc_tbl=pd.DataFrame({'资产':ASSET_NAMES,'风险贡献占比':metric_all['当前组合']['rc']}).assign(风险贡献占比=lambda x:x['风险贡献占比'].map(pct))
asset_stats=pd.DataFrame({'资产':ASSET_NAMES,'年化波动率':[ret[a].std()*np.sqrt(252) for a in ASSET_NAMES],'1日均值':[ret[a].mean() for a in ASSET_NAMES],'1日VaR99':[np.quantile(-ret[a],.99) for a in ASSET_NAMES],'1日ES99':[-ret[a][(-ret[a])>=np.quantile(-ret[a],.99)].mean() for a in ASSET_NAMES]})
for c in asset_stats.columns[1:]: asset_stats[c]=asset_stats[c].map(pct)
corr=ret[ASSET_NAMES].corr().round(2)

# Stress table with every plan x scenario x shock and four required contributions.
stress_md=[]
for plan in ['当前组合','方案A','方案B','方案C','推荐方案']:
    sub=stress[stress.方案.eq(plan)].copy(); sub['结果']=sub.apply(lambda r:f"境内 {signpct(r['境内权益'])}；标普人民币 {signpct(r['标普500（人民币计）'])}；美元现金 {signpct(r['美元现金'])}；国债 {signpct(r['国债'])}；合计 {signpct(r['组合损益'])}；压力损失 {pct(r['压力损失'])}",axis=1)
    stress_md.append(f'**{plan}**\n\n'+format_table(sub[['情景编号','情景','冲击','结果']]))

# Checks table.
limit_df=read_csv('params_limits.csv'); check_rows=[]
for plan in ['方案A','方案B','方案C','推荐方案']:
    vals, pf=checks[plan]
    for _,lim in limit_df.iterrows():
        lid=lim.id; v=vals[lid]; status='不适用' if lid=='L9' and plan!='推荐方案' else ('通过' if pf[lid] else '未通过')
        limit_text = (f'=100.00%' if lid == 'L1' else (f'in [{lim.lower*100:.2f}%, {lim.upper*100:.2f}%]' if lim.op == 'in' else f'{lim.op}{lim.upper*100:.2f}%'))
        if lid=='L1': value=f'{v*100:.2f}%'
        elif lid in ['L3','L4','L5','L6','L7','L8','L9']: value=pct(v)
        else: value=pct(v)
        excess='—'
        if status=='未通过':
            if lid in ['L2','L5','L6','L7','L8','L9']: excess=pct(v-lim.upper)
            elif lid=='L3': excess=pct(max(lim.lower-v,v-lim.upper))
            elif lid=='L4': excess=pct(lim.upper-v)
        check_rows.append([plan,lid,lim.constraint,value,limit_text,status,excess])
check_md=format_table(pd.DataFrame(check_rows,columns=['方案','限额','约束','实际值','限额','状态','超限幅度']))

# Factor calibration and scenario summaries.
cal_rows=[]
for sid in qual:
    c=calibration[sid]; cal_rows.append([sid,shock_dict[sid]['scenario'],len(qual[sid]),len(window_records[sid]),len(selected_windows[sid]),window_selection_mode[sid],dstr(min(x['start'] for x in selected_windows[sid])) if selected_windows[sid] else '—',dstr(max(x['end'] for x in selected_windows[sid])) if selected_windows[sid] else '—',signpct(c['cn']),signpct(c['spx']),signpct(c['fx']),signbp(sum(DUR[t]*c['cgb'][t] for t in DUR.index))])
cal_md=format_table(pd.DataFrame(cal_rows,columns=['情景','名称','合格月数','严格窗口数','校准窗口数','选取口径','窗口起始','窗口终止','境内权益','标普美元','USD/CNH','久期加权国债']))

# Validation report tables.
valdf=pd.DataFrame(validation_rows); valdf['实际覆盖']=valdf.apply(lambda r:f'{dstr(r.actual_start)}至{dstr(r.actual_end)}',axis=1); valdf['记录']=valdf.records_actual.astype(int).astype(str); valdf['缺口']=valdf.gaps; valdf['空值']=valdf.nulls.astype(int).astype(str); valdf=valdf[['file','记录','实际覆盖','缺口','空值','manifest_end']]; valdf.columns=['序列','实际记录','实际覆盖区间','区间内缺口','空值数','清单终止日']; val_md=format_table(valdf)

# Daily portfolio risk comparison.
planrisk=[]
for n in ['当前组合','方案A','方案B','方案C','推荐方案']:
    mm=metric_all[n]; planrisk.append([n,pct(mm['annual_vol']),pct(mm['es99']),pct(mm['var10']),pct(mm['max10']),f'{dstr(mm["max10_start"])}至{dstr(mm["max10_end"])}',pct(mm['maxdd']),f'{dstr(mm["dd_peak"])}至{dstr(mm["dd_trough"])}',dstr(mm['dd_recovery']),pct(mm['worst_day']),dstr(mm['worst_day_date'])])
planrisk_md=format_table(pd.DataFrame(planrisk,columns=['方案','年化波动','1日ES99','10日VaR99','最大10日损失','区间','最大回撤','回撤区间','修复日','最差单日','最差日']))

# Monitoring text.
def mon_fmt(r):
    if r.id in ['M1','M2','M6','M8']: return pct(r.value),pct(r.threshold)
    if r.id in ['M3','M4','M5']: return bp(r.value),bp(r.threshold)
    return f'{r.value:.2f}',f'{r.threshold:.2f}'
mon_rows=[]
for _,r in monitor.iterrows():
    av,tv=mon_fmt(r); mon_rows.append([r.id,r.indicator,av,tv,r['asof'],r.status,'是' if r.triggered else '否'])
mon_md=format_table(pd.DataFrame(mon_rows,columns=['编号','指标','最新值','阈值','数据截至','状态','触发']))

# Holding/rebalance table.
rec_hold=holdings[['asset','weight_recommended']].copy(); rec_hold['金额（万元）']=rec_hold.weight_recommended*TOTAL; rec_hold['权重']=rec_hold.weight_recommended.map(pct); rec_hold=rec_hold[['asset','权重','金额（万元）']]; rec_hold.columns=['资产','推荐权重','推荐金额（万元）']; rec_hold['推荐金额（万元）']=rec_hold['推荐金额（万元）'].map(amt); rec_hold_md=format_table(rec_hold)
trade=[]
for key, asset, cur, rec in [('EQ_000300','沪深300指数基金',current_weights['EQ_000300'],recommended_weights['EQ_000300']),('EQ_000905','中证500指数基金',current_weights['EQ_000905'],recommended_weights['EQ_000905']),('EQ_399006','创业板指数基金',current_weights['EQ_399006'],recommended_weights['EQ_399006']),('CGB','中长期国债组合',current_weights['CGB'],recommended_weights['CGB']),('CNY_CASH','人民币现金及货基',current_weights['CNY_CASH'],recommended_weights['CNY_CASH'])]:
    delta=(rec-cur)*TOTAL; trade.append([asset,'买入' if delta>0 else '卖出',amt(abs(delta)),pct(cur),pct(rec)])
trade_md=format_table(pd.DataFrame(trade,columns=['证券/资产','方向','金额（万元）','当前权重','推荐权重']))

# Exact current/recommendation stress summary.
equity_sell=sum(max(current_weights[k]-recommended_weights[k],0) for k in EQ_KEYS); cgb_buy=max(recommended_weights['CGB']-current_weights['CGB'],0); cny_buy=max(recommended_weights['CNY_CASH']-current_weights['CNY_CASH'],0); cash0=current_weights['CNY_CASH']; cash_after_sell=cash0+equity_sell; cash_after_cgb=cash_after_sell-cgb_buy
rec_st=stress[stress.方案.eq('推荐方案')]; curr_st=stress[stress.方案.eq('当前组合')]
rec_worst=rec_st.loc[rec_st['压力损失'].idxmax()]; curr_worst=curr_st.loc[curr_st['压力损失'].idxmax()]
margin8=limits.loc['L8','upper']-rec_worst['压力损失']; margin7=limits.loc['L9','upper']-rec_worst['压力损失']

memo=f'''# 多资产稳健配置专户 三季度宏观压力测试与调仓建议
## 风险委员会决策备忘录

分析截至日：**2026-09-15**；组合净值：**10,000.00 万元**；金额单位均为万元，百分比保留两位小数。

### 一、结论与建议

建议维持美元现金及存款、标普500 QDII 各 **10.00%**，将境内权益按当前权重同比例缩减至 **29.50%**，中长期国债升至 **30.50%**、人民币现金及货基升至 **20.00%**，执行推荐方案。当前组合、方案A、方案B、方案C及推荐方案的最大压力损失分别为 {pct(curr_st['压力损失'].max())}、{pct(stress.loc[stress.方案.eq('方案A'),'压力损失'].max())}、{pct(stress.loc[stress.方案.eq('方案B'),'压力损失'].max())}、{pct(stress.loc[stress.方案.eq('方案C'),'压力损失'].max())}、{pct(rec_st['压力损失'].max())}；推荐方案 1 日 ES99 为 {pct(rec_m['es99'])}、10 日 VaR99 为 {pct(rec_m['var10'])}、单向换手率为 **{pct(.205)}**。推荐方案未触发 8%压力上限且满足 7%缓冲线，建议不提请临时风险会议，但因国债快照及部分宏观序列滞后，应在数据补齐后复核。

### 二、数据核验与样本区间

共同历史风险样本为 **{dstr(ret.index.min())}至{dstr(ret.index.max())}，共 {len(ret):,} 个收益观测日**；终止原因是五条中债国债收益率序列实际均终止于 **2026-06-09**，不是清单中的分析截至日。分析截至日保留为 2026-09-15，用于最新监测和可用数据的场景识别。所有跨市场日序列先映射到上交所交易日历，再在各自实际首末观测区间内前向填充；区间外结构性空值不填充、不进入收益计算。

数据清单与实际核验如下（清单终止日仅作对照，实际文件覆盖优先）：

{val_md}

逐条异常与处理：

- 上交所交易日历实际含 **{len(calendar):,}** 个交易日，文件内没有标记为休市的记录；全部市场日记录均落在该交易日历内，未发现休市日异常记录。
- 三个指数分段文件首条 `pre_close` 各 1 个结构性空值，仅用于首日字段核验，不参与收益率计算；各分段日期无重复，分段边界连续。
- `snapshot_lpr_5y.csv` 在 2018-01-02 至 2019-08-16 有结构性空值；S1 月度规则只取月内最后一个非空值，不以 0 或前值替代。其余空值均按原始状态保留，任何空值均未按 0 参与计算。
- 创业板指数第二段实际比同区间上交所交易日少 1 个交易日，收益计算要求五类日风险序列共同非空，因此相关缺口所在日及其形成的无法计算收益日被剔除。
- 中债收益率实际覆盖至 2026-06-09；`snapshot_ust_m4.csv` 仅 6 条记录，作为覆盖核验，不用于组合历史收益、情景识别或限额计算。`possible_truncation` 只作为上游提示，不覆盖实际文件核验。

![数据覆盖与缺口](FIN3-WKN-149_charts/FIN3-WKN-149_chart01_数据覆盖与缺口.png)

图 1 说明：蓝色区间为文件实际覆盖，红线为分析截至日，橙色虚线为共同历史风险样本终止日；缺口未被填成收益或价格。

### 三、当前组合风险画像

当前持仓：

{format_table(pos_tbl)}

资产日收益统计（国债按五个关键期限久期贡献折算；标普500人民币收益为美元指数收益与 USD/CNH 变动的复合结果；人民币现金采用本金保守代理 0 收益，而非把空值填 0）：

{format_table(asset_stats)}

当前组合资产收益相关矩阵：

{format_table(corr.reset_index().rename(columns={'index':'资产'}), index=False)}

当前组合风险指标：年化波动率 **{pct(current_m['annual_vol'])}**，1 日 VaR95 **{pct(current_m['var95'])}**，1 日 VaR99 **{pct(current_m['var99'])}**，1 日 ES95 **{pct(current_m['es95'])}**，1 日 ES99 **{pct(current_m['es99'])}**，10 日 VaR99 **{pct(current_m['var10'])}**；最大 10 日累计损失 **{pct(current_m['max10'])}**（{dstr(current_m['max10_start'])}至{dstr(current_m['max10_end'])}），最大回撤 **{pct(current_m['maxdd'])}**（{dstr(current_m['dd_peak'])}至{dstr(current_m['dd_trough'])}，修复日 {dstr(current_m['dd_recovery'])}），最差单日损失 **{pct(current_m['worst_day'])}**（{dstr(current_m['worst_day_date'])}）。

各资产对当前组合方差风险贡献占比：

{format_table(rc_tbl)}

各方案历史风险对照：

{planrisk_md}

![方案累计净值](FIN3-WKN-149_charts/FIN3-WKN-149_chart02_方案累计净值.png)

图 2 说明：所有方案使用共同历史样本、每日按方案权重再平衡，曲线用于比较历史复合路径而非回测交易成本。

![风险指标与限额](FIN3-WKN-149_charts/FIN3-WKN-149_chart03_风险指标与限额.png)

图 3 说明：柱形为方案风险指标，横线分别为 1 日 ES99 3.50%、10 日 VaR99 6.00%和最大压力损失 8.00%限额。

### 四、情景识别与历史校准

月度识别严格使用 `rules_scenarios.csv`：S1 为 PMI/LPR 或 PMI/10Y国债宽松组合，S2 为 PPI、10Y国债和权益共同上行/下跌条件，S3 为标普500月跌幅或 USD/CNH 月升幅条件，S4 为社融同比增速、DR007和权益条件。全部合格月份数量分别为：S1 **{len(qual['S1'])}**、S2 **{len(qual['S2'])}**、S3 **{len(qual['S3'])}**、S4 **{len(qual['S4'])}**。

合格月份（按 YYYY-MM 列示）：

- S1：{', '.join(str(x) for x in qual['S1']) or '无'}
- S2：{', '.join(str(x) for x in qual['S2']) or '无'}
- S3：{', '.join(str(x) for x in qual['S3']) or '无'}
- S4：{', '.join(str(x) for x in qual['S4']) or '无'}

历史窗口从合格月次月第一个上交所交易日开始，窗口长度 10 个交易日，先按规则筛选当前组合 10 日收益每日均为负的窗口并按累计跌幅取前 20 个。实际数据中四个情景的严格窗口数均为 0；为避免把无法计算的空值伪装成结论，脚本透明采用同一情景合格月窗口按 10 日累计跌幅排序的回退口径（仍取前 20 个，若合格月不足 20 个则全部使用），并在表中标记选取口径。校准冲击为入选窗口各风险因子 10 日累计变动中位数：

{cal_md}

委员会沿用冲击中，S1、S2、S3、S4 的 10 年/30 年曲线分别为 `+20/+25bp`、`-15/-30bp`、`+10/+20bp`、`-45/-50bp`；历史校准采用实际 10 日窗口中位数，可能更温和，也可能出现不同的曲线形态。国债收益均按 `{', '.join(f'{t}:{DUR[t]:.1f}' for t in DUR.index)}` 的久期贡献折算，而不是收益率差简单加总。

![情景合格月份](FIN3-WKN-149_charts/FIN3-WKN-149_chart04_情景合格月份.png)

图 4 说明：散点为按原始月度规则识别的合格月份；缺失宏观观测不满足规则时不强行识别。

![历史窗口校准冲击](FIN3-WKN-149_charts/FIN3-WKN-149_chart05_历史窗口校准冲击.png)

图 5 说明：四个面板展示每一情景入选窗口的中位数校准冲击，国债柱形为久期加权收益率变动。

### 五、压力测试结果

压力损失定义为组合损益的相反数；每一行均拆分为境内权益、标普500人民币计、美元现金和国债四项，四项之和等于组合损益。以下覆盖 5 个参照组合（当前组合、三个候选方案、推荐方案）× 4 情景 × 2 套冲击；候选方案评估表另按要求逐条检查三候选方案及推荐方案。

{chr(10).join(stress_md)}

各方案最大压力损失及来源：

{format_table(pd.DataFrame([[n,pct(stress.loc[stress.方案.eq(n),'压力损失'].max()),stress.loc[stress.方案.eq(n)].sort_values('压力损失',ascending=False).iloc[0]['情景编号'],stress.loc[stress.方案.eq(n)].sort_values('压力损失',ascending=False).iloc[0]['冲击']] for n in ['当前组合','方案A','方案B','方案C','推荐方案']],columns=['方案','最大压力损失','来源情景','冲击']))}

委员会沿用冲击与历史校准冲击的严格程度取决于权益和汇率损失、以及国债曲线与久期方向的共同作用；因此不能仅按某一个期限或单一资产判断。

![两套冲击对比](FIN3-WKN-149_charts/FIN3-WKN-149_chart06_两套冲击对比.png)

图 6 说明：以推荐方案为例，比较每一情景委员会沿用冲击与历史校准冲击的组合压力损失，正值越大表示越严格。

### 六、候选方案评估与九项约束检查

外币资产敞口严格按 `params_limits.csv` 口径计算为 **美元现金及存款 + 不对冲汇率的标普500 QDII**；因此标普500 QDII 没有漏计或误计。L9 明确为“仅对最终推荐方案适用”，候选方案列为不适用，不将其误当作候选方案的强制限额。

{check_md}

超限幅度为相对对应上限/下限的比例百分点；“不适用”不计入通过率。当前组合的 L6-L9 也已计算并用于结论参照，其最大压力损失为 **{pct(curr_st['压力损失'].max())}**。

![方案决策与限额](FIN3-WKN-149_charts/FIN3-WKN-149_chart07_方案决策与限额.png)

图 7 说明：图中同时绘制 8%压力损失上限线和 7%推荐缓冲线，推荐方案应落在两线以下。

### 七、推荐方案与调仓执行

推荐方案完整权重与金额：

{rec_hold_md}

构造依据是 `rules_rebalance.csv` 的唯一规则：美元现金及标普500 QDII 各保持 {pct(recommended_weights['USD_CASH'])}；境内权益按当前权重乘以 {recommended_weights['EQ_000300']/current_weights['EQ_000300']:.2f}，分别为 {', '.join(pct(recommended_weights[k]) for k in EQ_KEYS)}；减配境内权益合计 {pct(equity_sell)}，释放资金中 {pct(cgb_buy)} 配置国债、{pct(cny_buy)} 配置人民币现金。推荐方案九项检查全部通过。其最大压力损失为 **{pct(rec_max_stress)}**，距 {limits.loc['L8','upper']*100:.0f}%限额余量 **{pct(margin8)}**，距 {limits.loc['L9','upper']*100:.0f}%缓冲线余量 **{pct(margin7)}**。

同一单向换手率 20.50%下，若保持国债、现金和外币权重不变，仅将 1.00 个百分点从沪深300改配创业板（境内权益总额和卖出金额不变），其 1 日 ES99 为 **{pct(metric_all['同换手次优比较']['es99'])}**、10 日 VaR99 为 **{pct(metric_all['同换手次优比较']['var10'])}**，均高于推荐方案的 {pct(rec_m['es99'])} 和 {pct(rec_m['var10'])}，而最大压力损失相同为 **{pct(alt_max_stress)}**。因此在“境内权益按当前权重同比例缩减”的构造规则下，推荐方案具有唯一性；该唯一性不是声称所有可能组合的压力损失都严格更低。

交易清单：

{trade_md}

按规则先卖出后买入：先卖出沪深300、中证500、创业板合计 {amt(equity_sell*TOTAL)} 万元，使可用现金/现金资产从 {pct(cash0)} 升至 {pct(cash_after_sell)}；再买入国债 {amt(cgb_buy*TOTAL)} 万元，回落至 {pct(cash_after_cgb)}；最后将 {amt(cny_buy*TOTAL)} 万元配置人民币现金及货基，现金资产仍为 {pct(recommended_weights['CNY_CASH'])}，全程不低于 {pct(limits.loc['L3','lower'])}。标普500 QDII 不赎回，因此不触发 T+7 结算约束。单向换手率为卖出金额 {amt(equity_sell*TOTAL)} / {amt(TOTAL)} = {pct(equity_sell)}。若先买后卖，第一笔买入国债后现金资产降至 {pct(cash0-cgb_buy)}，随后买入现金基金前已无法结算，且已击穿 {pct(limits.loc['L3','lower'])}下限；故不得采用先买后卖路径。

![调仓现金路径](FIN3-WKN-149_charts/FIN3-WKN-149_chart08_调仓现金路径.png)

图 8 说明：先卖后买路径保持现金资产不低于 8%，先买后卖路径在买入国债时即击穿下限，且不具备可执行的现金结算条件。

### 八、反向压力测试与监测预警

推荐方案最大压力损失情景为 **{rec_worst['情景编号']} {rec_worst['情景']} / {rec_worst['冲击']}**，损失 **{pct(rec_worst['压力损失'])}**；相对 {limits.loc['L8','upper']*100:.0f}%限额裕度为 **{pct(margin8)}**，相对 {limits.loc['L9','upper']*100:.0f}%缓冲线裕度为 **{pct(margin7)}**。相对当前组合最大压力损失，推荐方案为 **{rec_max_stress/curr_stress if (curr_stress:=curr_st['压力损失'].max()) else np.nan:.2f} 倍**。样本内最差 10 日累计损失为 **{pct(current_m['max10'])}**，区间为 **{dstr(current_m['max10_start'])}至{dstr(current_m['max10_end'])}**。

反向压力使用全部共同样本滚动 10 日风险因子向量（境内权益、标普500美元、USD/CNH、五个国债关键期限）计算均值和协方差。约束条件为：推荐权重固定、组合损失达到 {limits.loc['L9','upper']*100:.2f}%缓冲边界、风险因子只使用无空值的共同样本协方差；不将缺失值填 0。由最小马氏距离解析解得到的 {limits.loc['L9','upper']*100:.0f}%边界因子变动为：境内权益 **{signpct(reverse_vec[0])}**、标普500美元 **{signpct(reverse_vec[1])}**、USD/CNH **{signpct(reverse_vec[2])}**、1Y/2Y/5Y/10Y/30Y国债收益率分别 **{', '.join(signbp(reverse_vec[3+i]) for i in range(5))}**，最小马氏距离 **{reverse_dist:.2f}**。

四个委员会沿用冲击中，马氏距离最小的最可能命名情景为 **{nearest_sid} {shock_dict[nearest_sid]['scenario']}**（距离 **{committee_dist[nearest_sid]:.2f}**）；S1/S2/S3/S4距离分别为 {', '.join(f'{sid} {committee_dist[sid]:.2f}' for sid in committee_dist)}。历史校准窗口距离分别为 {', '.join(f'{sid} {cal_dist[sid]:.2f}' for sid in cal_dist)}。委员会沿用冲击距离与历史校准距离的比较只表示历史相似度，不替代压力测试的最坏损失判定。

![反向压力测试](FIN3-WKN-149_charts/FIN3-WKN-149_chart09_反向压力测试.png)

图 9 说明：红柱为马氏距离最近的委员会情景，蓝柱为令推荐方案达到 7%压力边界的最小距离因子解；国债为久期加权收益率变动。

八个监测指标：

{mon_md}

![监测指标触发状态](FIN3-WKN-149_charts/FIN3-WKN-149_chart10_监测指标触发状态.png)

图 10 说明：蓝色表示正常、红色表示按方向触发；国债、PPI、PMI和社融指标按其各自实际最新日期标注，未用 2026-09-15 之后不存在的值填补。

补齐数据后的重新判断安排：收到 2026-06-10 至 2026-09-15 的五条中债收益率后，先重做共同样本、日收益、历史窗口校准和 L6-L9，再更新 M4；收到最新社融存量后更新 M8，并重新执行 S4。若任一 L6-L9 未通过、推荐方案最大压力损失超过 7.00%，或 M1/M2/M3/M5 任一触发，则提交临时风险会议；仅因当前已知数据滞后不单独触发临时会议。

---

**附件清单**
- 图表文件：`FIN3-WKN-149_charts/` 下 10 张 PNG。
- 可复算代码：`FIN3-WKN-149_reproduce.py`。
'''
(OUT/'FIN3-WKN-149_风险委员会决策备忘录.md').write_text(memo, encoding='utf-8')
print('generated', OUT/'FIN3-WKN-149_风险委员会决策备忘录.md')
print('hist', dstr(hist_start), dstr(hist_end), len(ret))
print('recommended max stress', rec_max_stress, 'current', curr_stress, 'nearest', nearest_sid)
print('monitor')
print(monitor[['id','value','threshold','status','triggered']].to_string(index=False))
print('files', len(list(CHART.glob('*.png'))))
