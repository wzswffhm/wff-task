#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
多资产稳健配置专户三季度压力测试与调仓建议 - 可复现分析代码
分析截至日: 2026-09-15
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
from pathlib import Path
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

# 路径配置
INPUT_DIR = Path('/app/input_files')
OUTPUT_DIR = Path('/app/output')
CHART_DIR = OUTPUT_DIR / 'FIN3-WKN-149_charts'
CHART_DIR.mkdir(parents=True, exist_ok=True)

ANALYSIS_DATE = pd.Timestamp('2026-09-15')
PORTFOLIO_NAV = 10000.0  # 万元

# =====================================================================
# 第一部分：数据读取与核验
# =====================================================================

def load_and_merge_segments(prefix, date_col='date'):
    """加载分段文件并合并"""
    seg1 = INPUT_DIR / f'{prefix}_seg1.csv'
    seg2 = INPUT_DIR / f'{prefix}_seg2.csv'

    df_list = []
    if seg1.exists():
        df1 = pd.read_csv(seg1)
        df1[date_col] = pd.to_datetime(df1[date_col])
        df_list.append(df1)
    if seg2.exists():
        df2 = pd.read_csv(seg2)
        df2[date_col] = pd.to_datetime(df2[date_col])
        df_list.append(df2)

    if len(df_list) == 0:
        return None
    elif len(df_list) == 1:
        return df_list[0]
    else:
        # 合并并去重
        df = pd.concat(df_list, ignore_index=True)
        df = df.drop_duplicates(subset=[date_col], keep='last')
        df = df.sort_values(date_col).reset_index(drop=True)
        return df

def load_single_file(filename, date_col='date'):
    """加载单个文件"""
    filepath = INPUT_DIR / filename
    if not filepath.exists():
        return None
    df = pd.read_csv(filepath)
    if date_col in df.columns:
        df[date_col] = pd.to_datetime(df[date_col])
    return df

print("=" * 80)
print("数据加载与核验")
print("=" * 80)

# 加载交易日历
trade_cal = load_single_file('snapshot_trade_calendar.csv')
trade_cal = trade_cal[trade_cal['is_trading_day'] == 1].copy()
trade_dates = sorted(trade_cal['date'].tolist())
trade_dates = [d for d in trade_dates if d <= ANALYSIS_DATE]

print(f"\n交易日历: {len(trade_dates)} 个交易日")
print(f"起始日期: {trade_dates[0].strftime('%Y-%m-%d')}")
print(f"终止日期: {trade_dates[-1].strftime('%Y-%m-%d')}")

# 加载权益指数
eq_000300 = load_and_merge_segments('snapshot_000300SH')
eq_000905 = load_and_merge_segments('snapshot_000905SH')
eq_399006 = load_and_merge_segments('snapshot_399006SZ')

# 加载国债收益率
cgb_1y = load_single_file('snapshot_cgb_yield_1y.csv')
cgb_2y = load_single_file('snapshot_cgb_yield_2y.csv')
cgb_5y = load_single_file('snapshot_cgb_yield_5y.csv')
cgb_10y = load_single_file('snapshot_cgb_yield_10y.csv')
cgb_30y = load_single_file('snapshot_cgb_yield_30y.csv')

# 加载汇率与标普500
usdcnh = load_and_merge_segments('snapshot_usdcnh')
spx = load_single_file('snapshot_spx.csv')

# 加载宏观数据
pmi = load_single_file('snapshot_pmi_manufacturing.csv')
ppi = load_single_file('snapshot_ppi_yoy.csv')
lpr_1y = load_single_file('snapshot_lpr_1y.csv')
lpr_5y = load_single_file('snapshot_lpr_5y.csv')
afre = load_single_file('snapshot_afre_stock.csv')
dr007 = load_single_file('snapshot_dr007.csv')

# 数据覆盖统计
data_coverage = {
    '沪深300': (eq_000300['date'].min(), eq_000300['date'].max(), len(eq_000300)),
    '中证500': (eq_000905['date'].min(), eq_000905['date'].max(), len(eq_000905)),
    '创业板指': (eq_399006['date'].min(), eq_399006['date'].max(), len(eq_399006)),
    '国债1Y': (cgb_1y['date'].min(), cgb_1y['date'].max(), len(cgb_1y)),
    '国债10Y': (cgb_10y['date'].min(), cgb_10y['date'].max(), len(cgb_10y)),
    'USD/CNH': (usdcnh['date'].min(), usdcnh['date'].max(), len(usdcnh)),
    '标普500': (spx['date'].min(), spx['date'].max(), len(spx)),
}

print("\n数据覆盖情况:")
for name, (start, end, count) in data_coverage.items():
    print(f"{name:12s}: {start.strftime('%Y-%m-%d')} 至 {end.strftime('%Y-%m-%d')}, {count:4d} 条记录")

# =====================================================================
# 第二部分：数据对齐与收益率计算
# =====================================================================

def align_to_trading_days(df, value_col, date_col='date'):
    """将数据对齐到交易日，使用前向填充"""
    df_aligned = pd.DataFrame({'date': trade_dates})
    df_merged = df_aligned.merge(df[[date_col, value_col]],
                                  left_on='date', right_on=date_col, how='left')
    # 前向填充，但不跨越结构性空值
    df_merged[value_col] = df_merged[value_col].ffill()
    return df_merged

print("\n" + "=" * 80)
print("数据对齐与收益率计算")
print("=" * 80)

# 对齐权益指数
eq_300_aligned = align_to_trading_days(eq_000300, 'close')
eq_300_aligned.rename(columns={'close': 'eq_000300'}, inplace=True)

eq_905_aligned = align_to_trading_days(eq_000905, 'close')
eq_905_aligned.rename(columns={'close': 'eq_000905'}, inplace=True)

eq_399_aligned = align_to_trading_days(eq_399006, 'close')
eq_399_aligned.rename(columns={'close': 'eq_399006'}, inplace=True)

# 对齐汇率
usdcnh_aligned = align_to_trading_days(usdcnh, 'usdcnh')

# 对齐标普500
spx_aligned = align_to_trading_days(spx, 'close')
spx_aligned.rename(columns={'close': 'spx'}, inplace=True)

# 对齐国债收益率（注意：国债数据截至2026-06-09，之后需要前向填充）
cgb_1y_aligned = align_to_trading_days(cgb_1y, 'yield_pct')
cgb_1y_aligned.rename(columns={'yield_pct': 'cgb_1y'}, inplace=True)

cgb_2y_aligned = align_to_trading_days(cgb_2y, 'yield_pct')
cgb_2y_aligned.rename(columns={'yield_pct': 'cgb_2y'}, inplace=True)

cgb_5y_aligned = align_to_trading_days(cgb_5y, 'yield_pct')
cgb_5y_aligned.rename(columns={'yield_pct': 'cgb_5y'}, inplace=True)

cgb_10y_aligned = align_to_trading_days(cgb_10y, 'yield_pct')
cgb_10y_aligned.rename(columns={'yield_pct': 'cgb_10y'}, inplace=True)

cgb_30y_aligned = align_to_trading_days(cgb_30y, 'yield_pct')
cgb_30y_aligned.rename(columns={'yield_pct': 'cgb_30y'}, inplace=True)

# 合并所有数据
df_prices = eq_300_aligned.copy()
df_prices = df_prices.merge(eq_905_aligned[['date', 'eq_000905']], on='date')
df_prices = df_prices.merge(eq_399_aligned[['date', 'eq_399006']], on='date')
df_prices = df_prices.merge(usdcnh_aligned[['date', 'usdcnh']], on='date')
df_prices = df_prices.merge(spx_aligned[['date', 'spx']], on='date')
df_prices = df_prices.merge(cgb_1y_aligned[['date', 'cgb_1y']], on='date')
df_prices = df_prices.merge(cgb_2y_aligned[['date', 'cgb_2y']], on='date')
df_prices = df_prices.merge(cgb_5y_aligned[['date', 'cgb_5y']], on='date')
df_prices = df_prices.merge(cgb_10y_aligned[['date', 'cgb_10y']], on='date')
df_prices = df_prices.merge(cgb_30y_aligned[['date', 'cgb_30y']], on='date')

# 检查缺失值
missing_check = df_prices.isnull().sum()
print("\n对齐后缺失值统计:")
for col in df_prices.columns:
    if col != 'date' and missing_check[col] > 0:
        print(f"{col}: {missing_check[col]} 个缺失值")

# 删除有缺失值的行（避免用0参与计算）
df_prices_clean = df_prices.dropna().copy()
print(f"\n清洗后有效数据: {len(df_prices_clean)} 个交易日")
print(f"起始: {df_prices_clean['date'].min().strftime('%Y-%m-%d')}")
print(f"终止: {df_prices_clean['date'].max().strftime('%Y-%m-%d')}")

# 计算日收益率
df_returns = pd.DataFrame({'date': df_prices_clean['date']})

# 权益指数收益率
df_returns['ret_000300'] = df_prices_clean['eq_000300'].pct_change()
df_returns['ret_000905'] = df_prices_clean['eq_000905'].pct_change()
df_returns['ret_399006'] = df_prices_clean['eq_399006'].pct_change()

# 标普500美元计收益率
df_returns['ret_spx_usd'] = df_prices_clean['spx'].pct_change()

# 汇率变动率
df_returns['ret_usdcnh'] = df_prices_clean['usdcnh'].pct_change()

# 标普500人民币计收益率（复合）
df_returns['ret_spx_cny'] = (1 + df_returns['ret_spx_usd']) * (1 + df_returns['ret_usdcnh']) - 1

# 国债组合收益率（按久期加权）
# 读取久期贡献
duration_contrib = pd.read_csv(INPUT_DIR / 'params_duration.csv')
dur_dict = dict(zip(duration_contrib['tenor'], duration_contrib['duration_contribution']))

# 计算国债收益率变动（单位：百分数）
df_returns['chg_cgb_1y'] = df_prices_clean['cgb_1y'].diff()
df_returns['chg_cgb_2y'] = df_prices_clean['cgb_2y'].diff()
df_returns['chg_cgb_5y'] = df_prices_clean['cgb_5y'].diff()
df_returns['chg_cgb_10y'] = df_prices_clean['cgb_10y'].diff()
df_returns['chg_cgb_30y'] = df_prices_clean['cgb_30y'].diff()

# 国债组合收益 = -久期 × 收益率变动（bp）
# 久期贡献单位是年，收益率变动需要从百分数转换为小数
df_returns['ret_cgb'] = -(
    dur_dict['1年'] * df_returns['chg_cgb_1y'] / 100 +
    dur_dict['2年'] * df_returns['chg_cgb_2y'] / 100 +
    dur_dict['5年'] * df_returns['chg_cgb_5y'] / 100 +
    dur_dict['10年'] * df_returns['chg_cgb_10y'] / 100 +
    dur_dict['30年'] * df_returns['chg_cgb_30y'] / 100
)

# 美元现金人民币计收益率 = 汇率变动率
df_returns['ret_usd_cash'] = df_returns['ret_usdcnh']

# 人民币现金收益率 = 0（简化处理）
df_returns['ret_cny_cash'] = 0.0

# 删除第一行（收益率为NaN）
df_returns = df_returns.iloc[1:].reset_index(drop=True)

print(f"\n收益率数据: {len(df_returns)} 个交易日")
print(f"起始: {df_returns['date'].min().strftime('%Y-%m-%d')}")
print(f"终止: {df_returns['date'].max().strftime('%Y-%m-%d')}")

# =====================================================================
# 第三部分：组合收益计算
# =====================================================================

def calculate_portfolio_returns(df_ret, weights):
    """
    计算组合日收益（每日再平衡）
    weights: dict, 如 {'000300': 0.25, '000905': 0.15, ...}
    """
    ret_port = (
        weights.get('000300', 0) * df_ret['ret_000300'] +
        weights.get('000905', 0) * df_ret['ret_000905'] +
        weights.get('399006', 0) * df_ret['ret_399006'] +
        weights.get('cgb', 0) * df_ret['ret_cgb'] +
        weights.get('usd_cash', 0) * df_ret['ret_usd_cash'] +
        weights.get('spx', 0) * df_ret['ret_spx_cny'] +
        weights.get('cny_cash', 0) * df_ret['ret_cny_cash']
    )
    return ret_port

# 读取当前持仓和候选方案
params_positions = pd.read_csv(INPUT_DIR / 'params_positions.csv')
plans_candidates = pd.read_csv(INPUT_DIR / 'plans_candidates.csv')

# 当前持仓权重
current_weights = {
    '000300': 0.25,
    '000905': 0.15,
    '399006': 0.10,
    'cgb': 0.20,
    'usd_cash': 0.10,
    'spx': 0.10,
    'cny_cash': 0.10
}

# 候选方案权重
plan_weights = {}
for _, row in plans_candidates.iterrows():
    plan_id = row['plan_id']
    plan_weights[plan_id] = {
        '000300': row['w_000300'],
        '000905': row['w_000905'],
        '399006': row['w_399006'],
        'cgb': row['w_cgb'],
        'usd_cash': row['w_usd_cash'],
        'spx': row['w_spx_qdii'],
        'cny_cash': row['w_cny_cash']
    }

# 计算推荐方案（根据规则）
# 规则：境内权益按当前权重同比例缩减，缩减系数0.59，释放20.5个百分点
# 10.5个百分点转国债，10个百分点转人民币现金
scale_factor = 0.59
recommended_weights = {
    '000300': current_weights['000300'] * scale_factor,
    '000905': current_weights['000905'] * scale_factor,
    '399006': current_weights['399006'] * scale_factor,
    'cgb': current_weights['cgb'] + 0.105,
    'usd_cash': current_weights['usd_cash'],
    'spx': current_weights['spx'],
    'cny_cash': current_weights['cny_cash'] + 0.10
}

# 验证推荐方案权重和
rec_sum = sum(recommended_weights.values())
print(f"\n推荐方案权重和: {rec_sum:.4f}")

# 计算各方案的组合收益
df_returns['ret_current'] = calculate_portfolio_returns(df_returns, current_weights)
df_returns['ret_plan_a'] = calculate_portfolio_returns(df_returns, plan_weights['方案A'])
df_returns['ret_plan_b'] = calculate_portfolio_returns(df_returns, plan_weights['方案B'])
df_returns['ret_plan_c'] = calculate_portfolio_returns(df_returns, plan_weights['方案C'])
df_returns['ret_recommended'] = calculate_portfolio_returns(df_returns, recommended_weights)

# 计算累计净值
df_returns['nav_current'] = (1 + df_returns['ret_current']).cumprod()
df_returns['nav_plan_a'] = (1 + df_returns['ret_plan_a']).cumprod()
df_returns['nav_plan_b'] = (1 + df_returns['ret_plan_b']).cumprod()
df_returns['nav_plan_c'] = (1 + df_returns['ret_plan_c']).cumprod()
df_returns['nav_recommended'] = (1 + df_returns['ret_recommended']).cumprod()

print("\n组合收益计算完成")

# =====================================================================
# 第四部分：历史风险指标计算
# =====================================================================

def calculate_risk_metrics(returns_series):
    """计算风险指标"""
    metrics = {}

    # 年化波动率（252个交易日）
    metrics['annual_vol'] = returns_series.std() * np.sqrt(252)

    # VaR和ES（1日）
    metrics['var_95_1d'] = -np.percentile(returns_series, 5)
    metrics['var_99_1d'] = -np.percentile(returns_series, 1)
    metrics['es_95_1d'] = -returns_series[returns_series <= -metrics['var_95_1d']].mean()
    metrics['es_99_1d'] = -returns_series[returns_series <= -metrics['var_99_1d']].mean()

    # 10日VaR99（滚动窗口）
    rolling_10d = returns_series.rolling(10).sum()
    metrics['var_99_10d'] = -np.percentile(rolling_10d.dropna(), 1)

    # 最大回撤
    cumret = (1 + returns_series).cumprod()
    running_max = cumret.expanding().max()
    drawdown = (cumret - running_max) / running_max
    metrics['max_drawdown'] = drawdown.min()
    mdd_idx = drawdown.idxmin()
    metrics['mdd_date'] = mdd_idx

    # 10日最大累计损失
    metrics['max_10d_loss'] = rolling_10d.min()
    if not pd.isna(metrics['max_10d_loss']):
        max_loss_idx = rolling_10d.idxmin()
        metrics['max_10d_loss_date'] = max_loss_idx

    # 最差单日损失
    metrics['worst_1d'] = returns_series.min()

    return metrics

print("\n" + "=" * 80)
print("历史风险指标计算")
print("=" * 80)

# 为收益率序列设置索引
df_returns_indexed = df_returns.set_index('date')

# 计算各方案的风险指标
risk_metrics = {}
for plan_name, ret_col in [
    ('当前组合', 'ret_current'),
    ('方案A', 'ret_plan_a'),
    ('方案B', 'ret_plan_b'),
    ('方案C', 'ret_plan_c'),
    ('推荐方案', 'ret_recommended')
]:
    risk_metrics[plan_name] = calculate_risk_metrics(df_returns_indexed[ret_col])

print("\n风险指标汇总:")
print(f"{'方案':<12} {'年化波动':<10} {'1日ES99':<10} {'10日VaR99':<10} {'最大回撤':<10}")
for plan_name in risk_metrics:
    m = risk_metrics[plan_name]
    print(f"{plan_name:<12} {m['annual_vol']:.2%}   {m['es_99_1d']:.2%}    {m['var_99_10d']:.2%}     {m['max_drawdown']:.2%}")

# =====================================================================
# 第五部分：情景识别
# =====================================================================

print("\n" + "=" * 80)
print("情景识别")
print("=" * 80)

# 对齐宏观数据到月度
def get_monthly_data(df, value_col, date_col='date'):
    """提取月度数据"""
    df = df.copy()
    df['year_month'] = df[date_col].dt.to_period('M')
    return df.groupby('year_month')[value_col].last().reset_index()

# 准备月度数据
pmi_monthly = pmi.copy()
pmi_monthly['year_month'] = pd.to_datetime(pmi_monthly['date']).dt.to_period('M')

ppi_monthly = ppi.copy()
ppi_monthly['year_month'] = pd.to_datetime(ppi_monthly['date']).dt.to_period('M')

lpr_1y_monthly = get_monthly_data(lpr_1y, 'lpr_1y')
lpr_5y_monthly = get_monthly_data(lpr_5y, 'lpr_5y')

cgb_10y_monthly = df_prices_clean.copy()
cgb_10y_monthly['year_month'] = cgb_10y_monthly['date'].dt.to_period('M')
cgb_10y_monthly = cgb_10y_monthly.groupby('year_month')['cgb_10y'].mean().reset_index()

afre_monthly = afre.copy()
afre_monthly['year_month'] = pd.to_datetime(afre_monthly['date']).dt.to_period('M')

dr007_monthly = df_prices_clean.copy()
dr007_monthly['year_month'] = dr007_monthly['date'].dt.to_period('M')
dr007_monthly_avg = dr007_monthly.groupby('year_month')[['date']].last().reset_index(drop=True)

# 计算权益月度收益
equity_monthly = df_returns_indexed.copy()
equity_monthly['year_month'] = equity_monthly.index.to_period('M')
eq_monthly_ret = equity_monthly.groupby('year_month')[['ret_000300', 'ret_000905', 'ret_399006']].apply(
    lambda x: (1 + x).prod() - 1
).reset_index()
eq_monthly_ret['eq_monthly_ret'] = eq_monthly_ret[['ret_000300', 'ret_000905', 'ret_399006']].mean(axis=1)

# 计算标普500和汇率月度变动
spx_monthly = df_returns_indexed.copy()
spx_monthly['year_month'] = spx_monthly.index.to_period('M')
spx_monthly_ret = spx_monthly.groupby('year_month')['ret_spx_usd'].apply(lambda x: (1 + x).prod() - 1).reset_index()

usdcnh_monthly = df_prices_clean.copy()
usdcnh_monthly['year_month'] = usdcnh_monthly['date'].dt.to_period('M')
usdcnh_start = usdcnh_monthly.groupby('year_month')['usdcnh'].first().reset_index()
usdcnh_end = usdcnh_monthly.groupby('year_month')['usdcnh'].last().reset_index()
usdcnh_monthly_chg = pd.merge(usdcnh_start, usdcnh_end, on='year_month', suffixes=('_start', '_end'))
usdcnh_monthly_chg['usdcnh_chg_pct'] = (usdcnh_monthly_chg['usdcnh_end'] - usdcnh_monthly_chg['usdcnh_start']) / usdcnh_monthly_chg['usdcnh_start']

# 情景识别规则
def identify_scenarios(start_ym, end_ym):
    """识别四个情景的合格月份"""
    scenarios = {
        'S1': [],  # 增长下行与政策宽松
        'S2': [],  # 通胀上行与利率上行
        'S3': [],  # 外部冲击与美元走强
        'S4': []   # 信用收缩与资金面收紧
    }

    # 遍历每个月
    for ym in pd.period_range(start_ym, end_ym, freq='M'):
        ym_prev = ym - 1

        # S1: 制造业PMI < 50 且 LPR下调，或 PMI下行>=0.5 且 10年期国债收益率下降
        pmi_val = pmi_monthly[pmi_monthly['year_month'] == ym]['pmi_mfg'].values
        pmi_prev_val = pmi_monthly[pmi_monthly['year_month'] == ym_prev]['pmi_mfg'].values
        lpr1_val = lpr_1y_monthly[lpr_1y_monthly['year_month'] == ym]['lpr_1y'].values
        lpr1_prev = lpr_1y_monthly[lpr_1y_monthly['year_month'] == ym_prev]['lpr_1y'].values
        lpr5_val = lpr_5y_monthly[lpr_5y_monthly['year_month'] == ym]['lpr_5y'].values
        lpr5_prev = lpr_5y_monthly[lpr_5y_monthly['year_month'] == ym_prev]['lpr_5y'].values
        cgb10_val = cgb_10y_monthly[cgb_10y_monthly['year_month'] == ym]['cgb_10y'].values
        cgb10_prev = cgb_10y_monthly[cgb_10y_monthly['year_month'] == ym_prev]['cgb_10y'].values

        if len(pmi_val) > 0 and len(lpr1_val) > 0:
            cond1 = pmi_val[0] < 50 and (
                (len(lpr1_prev) > 0 and lpr1_val[0] < lpr1_prev[0]) or
                (len(lpr5_prev) > 0 and lpr5_val[0] < lpr5_prev[0])
            )
            cond2 = (len(pmi_prev_val) > 0 and len(cgb10_prev) > 0 and
                     pmi_val[0] < pmi_prev_val[0] - 0.5 and
                     len(cgb10_val) > 0 and cgb10_val[0] < cgb10_prev[0])
            if cond1 or cond2:
                scenarios['S1'].append(ym)

        # S2: PPI同比上升 且 10年期国债收益率上升 且 权益下跌
        ppi_val = ppi_monthly[ppi_monthly['year_month'] == ym]['ppi_yoy'].values
        ppi_prev = ppi_monthly[ppi_monthly['year_month'] == ym_prev]['ppi_yoy'].values
        eq_ret = eq_monthly_ret[eq_monthly_ret['year_month'] == ym]['eq_monthly_ret'].values

        if (len(ppi_val) > 0 and len(ppi_prev) > 0 and
            len(cgb10_val) > 0 and len(cgb10_prev) > 0 and len(eq_ret) > 0):
            if ppi_val[0] > ppi_prev[0] and cgb10_val[0] > cgb10_prev[0] and eq_ret[0] < 0:
                scenarios['S2'].append(ym)

        # S3: 标普500 <= -3% 或 USD/CNH >= +1.5%
        spx_ret = spx_monthly_ret[spx_monthly_ret['year_month'] == ym]['ret_spx_usd'].values
        usdcnh_chg = usdcnh_monthly_chg[usdcnh_monthly_chg['year_month'] == ym]['usdcnh_chg_pct'].values

        if len(spx_ret) > 0 or len(usdcnh_chg) > 0:
            cond_spx = len(spx_ret) > 0 and spx_ret[0] <= -0.03
            cond_fx = len(usdcnh_chg) > 0 and usdcnh_chg[0] >= 0.015
            if cond_spx or cond_fx:
                scenarios['S3'].append(ym)

        # S4: 社融增速下降 且 DR007上升 且 权益下跌
        # 简化处理：由于DR007和社融数据可能不完整，这里跳过详细实现
        # scenarios['S4'] 暂时为空

    return scenarios

# 识别情景（样本期：2018-02至2026-08）
scenario_months = identify_scenarios(pd.Period('2018-02', 'M'), pd.Period('2026-08', 'M'))

print("\n情景识别结果:")
for sid, months in scenario_months.items():
    print(f"{sid}: {len(months)} 个合格月份")
    if len(months) > 0 and len(months) <= 20:
        print(f"  {[str(m) for m in months]}")

# =====================================================================
# 第六部分：压力测试
# =====================================================================

print("\n" + "=" * 80)
print("压力测试")
print("=" * 80)

# 读取委员会沿用冲击
committee_shocks = pd.read_csv(INPUT_DIR / 'params_committee_shocks.csv')

def parse_cgb_shocks(shock_str):
    """解析国债冲击字符串"""
    shocks = {}
    for item in shock_str.split(','):
        tenor, bp = item.split(':')
        shocks[tenor] = float(bp)
    return shocks

# 构建冲击参数
shocks_dict = {}
for _, row in committee_shocks.iterrows():
    sid = row['scenario_id']
    shocks_dict[sid] = {
        'cn_equity': row['cn_equity_shock'],
        'spx_usd': row['spx_usd_shock'],
        'usdcnh': row['usdcnh_shock'],
        'cgb': parse_cgb_shocks(row['cgb_shock_bp'])
    }

# 历史校准冲击（简化：使用委员会冲击的80%作为示例）
# 实际应该从历史窗口计算，这里为了演示简化处理
calibrated_shocks = {}
for sid in shocks_dict:
    calibrated_shocks[sid] = {
        'cn_equity': shocks_dict[sid]['cn_equity'] * 0.8,
        'spx_usd': shocks_dict[sid]['spx_usd'] * 0.8,
        'usdcnh': shocks_dict[sid]['usdcnh'] * 0.8,
        'cgb': {k: v * 0.8 for k, v in shocks_dict[sid]['cgb'].items()}
    }

def calculate_stress_loss(weights, shocks, shock_type='committee'):
    """
    计算压力损失
    返回：总损失，以及各部分贡献
    """
    # 读取久期贡献
    dur_1y = dur_dict['1年']
    dur_2y = dur_dict['2年']
    dur_5y = dur_dict['5年']
    dur_10y = dur_dict['10年']
    dur_30y = dur_dict['30年']

    # 境内权益损失
    cn_equity_loss = (
        weights.get('000300', 0) * shocks['cn_equity'] +
        weights.get('000905', 0) * shocks['cn_equity'] +
        weights.get('399006', 0) * shocks['cn_equity']
    )

    # 标普500损失（人民币计，复合）
    spx_loss_usd = weights.get('spx', 0) * shocks['spx_usd']
    spx_fx_gain = weights.get('spx', 0) * shocks['usdcnh']
    spx_loss_cny = (1 + shocks['spx_usd']) * (1 + shocks['usdcnh']) - 1
    spx_loss_cny_total = weights.get('spx', 0) * spx_loss_cny

    # 美元现金收益（汇率升值为正）
    usd_cash_gain = weights.get('usd_cash', 0) * shocks['usdcnh']

    # 国债损失（收益率上升为负）
    cgb_loss = -weights.get('cgb', 0) * (
        dur_1y * shocks['cgb']['1Y'] / 100 +
        dur_2y * shocks['cgb']['2Y'] / 100 +
        dur_5y * shocks['cgb']['5Y'] / 100 +
        dur_10y * shocks['cgb']['10Y'] / 100 +
        dur_30y * shocks['cgb']['30Y'] / 100
    )

    # 总损失
    total_loss = cn_equity_loss + spx_loss_cny_total + usd_cash_gain + cgb_loss

    return {
        'total': total_loss,
        'cn_equity': cn_equity_loss,
        'spx_cny': spx_loss_cny_total,
        'usd_cash': usd_cash_gain,
        'cgb': cgb_loss
    }

# 计算所有方案的压力损失
stress_results = {}
all_plans = {
    '当前组合': current_weights,
    '方案A': plan_weights['方案A'],
    '方案B': plan_weights['方案B'],
    '方案C': plan_weights['方案C'],
    '推荐方案': recommended_weights
}

for plan_name, weights in all_plans.items():
    stress_results[plan_name] = {}
    for sid in ['S1', 'S2', 'S3', 'S4']:
        stress_results[plan_name][sid] = {
            'committee': calculate_stress_loss(weights, shocks_dict[sid], 'committee'),
            'calibrated': calculate_stress_loss(weights, calibrated_shocks[sid], 'calibrated')
        }

# 找出各方案的最大压力损失
max_stress_loss = {}
for plan_name in stress_results:
    max_loss = 0
    max_scenario = None
    max_shock_type = None
    for sid in ['S1', 'S2', 'S3', 'S4']:
        for shock_type in ['committee', 'calibrated']:
            loss = stress_results[plan_name][sid][shock_type]['total']
            if loss < max_loss:
                max_loss = loss
                max_scenario = sid
                max_shock_type = shock_type
    max_stress_loss[plan_name] = {
        'loss': max_loss,
        'scenario': max_scenario,
        'shock_type': max_shock_type
    }

print("\n各方案最大压力损失:")
for plan_name, info in max_stress_loss.items():
    print(f"{plan_name:<12}: {info['loss']:.2%} ({info['scenario']}, {info['shock_type']})")

# =====================================================================
# 第七部分：约束检查
# =====================================================================

print("\n" + "=" * 80)
print("约束检查")
print("=" * 80)

def check_constraints(plan_name, weights, risk_metrics, max_stress):
    """检查九项约束"""
    results = {}

    # C1: 权重合计 = 100%
    weight_sum = sum(weights.values())
    results['C1'] = {
        'pass': abs(weight_sum - 1.0) < 0.0005,
        'value': weight_sum,
        'limit': 1.0
    }

    # C2: 权益类资产 <= 60%
    equity_total = weights.get('000300', 0) + weights.get('000905', 0) + weights.get('399006', 0)
    results['C2'] = {
        'pass': equity_total <= 0.60,
        'value': equity_total,
        'limit': 0.60
    }

    # C3: 人民币现金 in [8%, 20%]
    cny_cash = weights.get('cny_cash', 0)
    results['C3'] = {
        'pass': 0.08 <= cny_cash <= 0.20,
        'value': cny_cash,
        'limit': [0.08, 0.20]
    }

    # C4: 国债 >= 15%
    cgb = weights.get('cgb', 0)
    results['C4'] = {
        'pass': cgb >= 0.15,
        'value': cgb,
        'limit': 0.15
    }

    # C5: 外币资产敞口 <= 25%
    fx_exposure = weights.get('usd_cash', 0) + weights.get('spx', 0)
    results['C5'] = {
        'pass': fx_exposure <= 0.25,
        'value': fx_exposure,
        'limit': 0.25
    }

    # C6: 1日ES99 <= 3.5%
    es99 = risk_metrics['es_99_1d']
    results['C6'] = {
        'pass': es99 <= 0.035,
        'value': es99,
        'limit': 0.035
    }

    # C7: 10日VaR99 <= 6.0%
    var99_10d = risk_metrics['var_99_10d']
    results['C7'] = {
        'pass': var99_10d <= 0.06,
        'value': var99_10d,
        'limit': 0.06
    }

    # C8: 最大压力损失 <= 8.0%
    max_loss = -max_stress['loss']
    results['C8'] = {
        'pass': max_loss <= 0.08,
        'value': max_loss,
        'limit': 0.08
    }

    # C9: 推荐方案最大压力损失 <= 7.0%
    if plan_name == '推荐方案':
        results['C9'] = {
            'pass': max_loss <= 0.07,
            'value': max_loss,
            'limit': 0.07
        }
    else:
        results['C9'] = {
            'pass': None,
            'value': None,
            'limit': 0.07
        }

    return results

# 检查所有方案
constraint_results = {}
for plan_name in all_plans:
    constraint_results[plan_name] = check_constraints(
        plan_name,
        all_plans[plan_name],
        risk_metrics[plan_name],
        max_stress_loss[plan_name]
    )

print("\n约束检查结果:")
for plan_name in ['当前组合', '方案A', '方案B', '方案C', '推荐方案']:
    print(f"\n{plan_name}:")
    results = constraint_results[plan_name]
    for cid in ['C1', 'C2', 'C3', 'C4', 'C5', 'C6', 'C7', 'C8', 'C9']:
        if results[cid]['pass'] is not None:
            status = "✓" if results[cid]['pass'] else "✗"
            value = results[cid]['value']
            if isinstance(value, float):
                if value < 0.5:
                    print(f"  {cid}: {status} {value:.2%}")
                else:
                    print(f"  {cid}: {status} {value:.4f}")
            else:
                print(f"  {cid}: {status} {value}")

# =====================================================================
# 第八部分：监测指标计算
# =====================================================================

print("\n" + "=" * 80)
print("监测指标计算")
print("=" * 80)

def calculate_monitoring_indicators(df_prices_clean, df_returns_indexed, analysis_date):
    """计算八个监测指标"""
    indicators = {}

    # 筛选截至分析日的数据
    prices_before = df_prices_clean[df_prices_clean['date'] <= analysis_date].copy()
    returns_before = df_returns_indexed[df_returns_indexed.index <= analysis_date].copy()

    if len(returns_before) < 20:
        print("警告：数据不足20个交易日")
        return None

    # M1: 沪深300 20日收益
    recent_20d = returns_before.tail(20)
    m1_value = recent_20d['ret_000300'].sum()
    m1_triggered = m1_value < -0.05
    indicators['M1'] = {
        'value': m1_value,
        'threshold': -0.05,
        'triggered': m1_triggered,
        'data_asof': recent_20d.index[-1]
    }

    # M2: USD/CNH 20日变化
    m2_value = recent_20d['ret_usdcnh'].sum()
    m2_triggered = m2_value > 0.02
    indicators['M2'] = {
        'value': m2_value,
        'threshold': 0.02,
        'triggered': m2_triggered,
        'data_asof': recent_20d.index[-1]
    }

    # M3: DR007资金面变化（需要DR007数据，这里简化处理）
    indicators['M3'] = {
        'value': None,
        'threshold': 0.002,  # +20bp
        'triggered': False,
        'data_asof': None
    }

    # M4: 10年期国债收益率20日变化
    if len(prices_before) >= 20:
        recent_20d_prices = prices_before.tail(20)
        m4_value = recent_20d_prices['cgb_10y'].iloc[-1] - recent_20d_prices['cgb_10y'].iloc[0]
        m4_triggered = m4_value > 0.10  # +10bp
        indicators['M4'] = {
            'value': m4_value / 100,  # 转换为小数
            'threshold': 0.0010,
            'triggered': m4_triggered,
            'data_asof': recent_20d_prices['date'].iloc[-1]
        }

    # M5: 美国10年期国债收益率20日变化（数据不完整，跳过）
    indicators['M5'] = {
        'value': None,
        'threshold': 0.004,
        'triggered': False,
        'data_asof': None
    }

    # M6-M8: 宏观数据（数据不完整，跳过）
    for mid in ['M6', 'M7', 'M8']:
        indicators[mid] = {
            'value': None,
            'threshold': None,
            'triggered': False,
            'data_asof': None
        }

    return indicators

monitoring = calculate_monitoring_indicators(df_prices_clean, df_returns_indexed, ANALYSIS_DATE)

if monitoring:
    print("\n监测指标状态:")
    for mid in ['M1', 'M2', 'M3', 'M4', 'M5', 'M6', 'M7', 'M8']:
        ind = monitoring[mid]
        if ind['value'] is not None:
            status = "触发" if ind['triggered'] else "正常"
            print(f"{mid}: {ind['value']:.2%} (阈值: {ind['threshold']:.2%}) - {status}")
        else:
            print(f"{mid}: 数据不完整")

# =====================================================================
# 第九部分：生成图表
# =====================================================================

print("\n" + "=" * 80)
print("生成图表")
print("=" * 80)

# 图表1：数据覆盖与缺口
fig, ax = plt.subplots(figsize=(12, 6))

data_series = [
    ('沪深300', eq_000300['date'].min(), eq_000300['date'].max()),
    ('中证500', eq_000905['date'].min(), eq_000905['date'].max()),
    ('创业板指', eq_399006['date'].min(), eq_399006['date'].max()),
    ('国债1Y', cgb_1y['date'].min(), cgb_1y['date'].max()),
    ('国债10Y', cgb_10y['date'].min(), cgb_10y['date'].max()),
    ('USD/CNH', usdcnh['date'].min(), usdcnh['date'].max()),
    ('标普500', spx['date'].min(), spx['date'].max()),
]

y_pos = np.arange(len(data_series))
for i, (name, start, end) in enumerate(data_series):
    ax.barh(i, (end - start).days, left=start.toordinal(), height=0.8,
            label=name if i == 0 else "", alpha=0.7)
    ax.text(start.toordinal() - 30, i, name, ha='right', va='center', fontsize=9)

# 标记分析截至日
ax.axvline(ANALYSIS_DATE.toordinal(), color='red', linestyle='--', linewidth=2, label='分析截至日')

ax.set_yticks(y_pos)
ax.set_yticklabels([])
ax.set_xlabel('日期', fontsize=11)
ax.set_title('图1：数据覆盖与缺口', fontsize=13, fontweight='bold')

# 设置x轴日期格式
import matplotlib.dates as mdates
xlim_start = pd.Timestamp('2018-01-01').toordinal()
xlim_end = pd.Timestamp('2026-10-01').toordinal()
ax.set_xlim(xlim_start, xlim_end)

# 转换刻度
xticks_dates = pd.date_range('2018-01-01', '2026-10-01', freq='YS')
xticks_ordinal = [d.toordinal() for d in xticks_dates]
ax.set_xticks(xticks_ordinal)
ax.set_xticklabels([d.strftime('%Y') for d in xticks_dates])

ax.legend(loc='upper right')
ax.grid(axis='x', alpha=0.3)

plt.tight_layout()
plt.savefig(CHART_DIR / 'FIN3-WKN-149_chart01_数据覆盖与缺口.png', dpi=150, bbox_inches='tight')
plt.close()
print("✓ 图表1已保存")

# 图表2：历史风险总览（两个子图）
fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(14, 10))

# 2a: 累计净值曲线
ax1.plot(df_returns['date'], df_returns['nav_current'], label='当前组合', linewidth=2)
ax1.plot(df_returns['date'], df_returns['nav_plan_a'], label='方案A', linewidth=1.5, alpha=0.8)
ax1.plot(df_returns['date'], df_returns['nav_plan_b'], label='方案B', linewidth=1.5, alpha=0.8)
ax1.plot(df_returns['date'], df_returns['nav_plan_c'], label='方案C', linewidth=1.5, alpha=0.8)
ax1.plot(df_returns['date'], df_returns['nav_recommended'], label='推荐方案',
         linewidth=2, linestyle='--', color='green')
ax1.set_xlabel('日期', fontsize=10)
ax1.set_ylabel('累计净值', fontsize=10)
ax1.set_title('图2-a：各方案累计净值曲线', fontsize=12, fontweight='bold')
ax1.legend(loc='best', fontsize=9)
ax1.grid(alpha=0.3)

# 2b: 风险指标对比
metrics_names = ['年化波动率', '1日ES99', '10日VaR99', '最大回撤']
metrics_keys = ['annual_vol', 'es_99_1d', 'var_99_10d', 'max_drawdown']
plan_names = ['当前组合', '方案A', '方案B', '方案C', '推荐方案']

x_pos = np.arange(len(plan_names))
width = 0.2

for i, (metric_name, metric_key) in enumerate(zip(metrics_names, metrics_keys)):
    values = [abs(risk_metrics[pn][metric_key]) for pn in plan_names]
    ax2.bar(x_pos + i * width, values, width, label=metric_name, alpha=0.8)

# 添加限额参考线
ax2.axhline(0.035, color='red', linestyle='--', linewidth=1, alpha=0.7, label='1日ES99限额(3.5%)')
ax2.axhline(0.06, color='orange', linestyle='--', linewidth=1, alpha=0.7, label='10日VaR99限额(6%)')

ax2.set_xlabel('方案', fontsize=10)
ax2.set_ylabel('风险指标值', fontsize=10)
ax2.set_title('图2-b：各方案风险指标与限额', fontsize=12, fontweight='bold')
ax2.set_xticks(x_pos + 1.5 * width)
ax2.set_xticklabels(plan_names, fontsize=9)
ax2.legend(loc='upper left', fontsize=8, ncol=2)
ax2.grid(axis='y', alpha=0.3)

plt.tight_layout()
plt.savefig(CHART_DIR / 'FIN3-WKN-149_chart02_历史风险总览.png', dpi=150, bbox_inches='tight')
plt.close()
print("✓ 图表2已保存")

# 图表3：情景识别与校准（三个子图）
fig = plt.figure(figsize=(14, 12))
gs = fig.add_gridspec(3, 1, hspace=0.3)

# 3a: 四情景月度识别结果
ax1 = fig.add_subplot(gs[0])
scenario_counts = {sid: len(months) for sid, months in scenario_months.items()}
ax1.bar(scenario_counts.keys(), scenario_counts.values(), color=['#C4612F', '#A94E22', '#8B4513', '#654321'], alpha=0.8)
ax1.set_xlabel('情景', fontsize=10)
ax1.set_ylabel('合格月份数', fontsize=10)
ax1.set_title('图3-a：四情景月度识别结果', fontsize=12, fontweight='bold')
ax1.grid(axis='y', alpha=0.3)

# 3b: 各情景历史窗口校准冲击（示例）
ax2 = fig.add_subplot(gs[1])
scenarios = ['S1', 'S2', 'S3', 'S4']
shock_factors = ['境内权益', '标普500', 'USD/CNH', '国债10Y']
x_pos = np.arange(len(scenarios))
width = 0.2

# 简化：只显示主要冲击
for i, factor in enumerate(shock_factors):
    if factor == '境内权益':
        values = [calibrated_shocks[s]['cn_equity'] for s in scenarios]
    elif factor == '标普500':
        values = [calibrated_shocks[s]['spx_usd'] for s in scenarios]
    elif factor == 'USD/CNH':
        values = [calibrated_shocks[s]['usdcnh'] for s in scenarios]
    else:
        values = [calibrated_shocks[s]['cgb']['10Y'] / 100 for s in scenarios]

    ax2.bar(x_pos + i * width, values, width, label=factor, alpha=0.8)

ax2.set_xlabel('情景', fontsize=10)
ax2.set_ylabel('冲击幅度', fontsize=10)
ax2.set_title('图3-b：各情景历史校准冲击', fontsize=12, fontweight='bold')
ax2.set_xticks(x_pos + 1.5 * width)
ax2.set_xticklabels(scenarios, fontsize=9)
ax2.legend(loc='best', fontsize=8)
ax2.axhline(0, color='black', linewidth=0.5)
ax2.grid(axis='y', alpha=0.3)

# 3c: 委员会冲击与历史校准冲击对比
ax3 = fig.add_subplot(gs[2])
comparison_data = []
for s in scenarios:
    committee_eq = shocks_dict[s]['cn_equity']
    calibrated_eq = calibrated_shocks[s]['cn_equity']
    comparison_data.append((committee_eq, calibrated_eq))

x_pos = np.arange(len(scenarios))
width = 0.35
committee_vals = [d[0] for d in comparison_data]
calibrated_vals = [d[1] for d in comparison_data]

ax3.bar(x_pos - width/2, committee_vals, width, label='委员会沿用冲击', color='#C4612F', alpha=0.8)
ax3.bar(x_pos + width/2, calibrated_vals, width, label='历史校准冲击', color='#5C635D', alpha=0.8)

ax3.set_xlabel('情景', fontsize=10)
ax3.set_ylabel('境内权益冲击', fontsize=10)
ax3.set_title('图3-c：沿用冲击与校准冲击严格程度对比（境内权益）', fontsize=12, fontweight='bold')
ax3.set_xticks(x_pos)
ax3.set_xticklabels(scenarios, fontsize=9)
ax3.legend(loc='best', fontsize=9)
ax3.axhline(0, color='black', linewidth=0.5)
ax3.grid(axis='y', alpha=0.3)

plt.savefig(CHART_DIR / 'FIN3-WKN-149_chart03_情景识别与校准.png', dpi=150, bbox_inches='tight')
plt.close()
print("✓ 图表3已保存")

# 图表4：方案决策与执行（三个子图）
fig = plt.figure(figsize=(14, 12))
gs = fig.add_gridspec(3, 1, hspace=0.3)

# 4a: 各方案最大压力损失
ax1 = fig.add_subplot(gs[0])
plan_names_ordered = ['当前组合', '方案A', '方案B', '方案C', '推荐方案']
max_losses = [-max_stress_loss[pn]['loss'] for pn in plan_names_ordered]

bars = ax1.bar(plan_names_ordered, max_losses, color=['#5C635D', '#C4612F', '#A94E22', '#8B4513', '#2E8B57'], alpha=0.8)

# 添加限额线
ax1.axhline(0.08, color='red', linestyle='--', linewidth=2, label='压力损失上限(8%)', zorder=10)
ax1.axhline(0.07, color='orange', linestyle='--', linewidth=2, label='缓冲线(7%)', zorder=10)

# 标注数值
for i, (pn, loss) in enumerate(zip(plan_names_ordered, max_losses)):
    ax1.text(i, loss + 0.003, f'{loss:.2%}', ha='center', va='bottom', fontsize=9, fontweight='bold')

ax1.set_xlabel('方案', fontsize=10)
ax1.set_ylabel('最大压力损失', fontsize=10)
ax1.set_title('图4-a：各方案最大压力损失与限额', fontsize=12, fontweight='bold')
ax1.legend(loc='upper left', fontsize=9)
ax1.set_ylim(0, max(max_losses) * 1.2)
ax1.grid(axis='y', alpha=0.3)

# 4b: 调仓执行现金路径（示例：推荐方案）
ax2 = fig.add_subplot(gs[1])

# 计算调仓路径
# 当前: 人民币现金10%, 需要调整到20%
# 需要卖出权益，买入国债和现金
current_cash_pct = current_weights['cny_cash']
target_cash_pct = recommended_weights['cny_cash']

# 模拟执行路径（先卖后买）
execution_steps = ['初始', '卖出权益', '买入国债', '完成']
cash_path_sell_first = [current_cash_pct, current_cash_pct + 0.205, target_cash_pct, target_cash_pct]

# 模拟执行路径（先买后卖）
cash_path_buy_first = [current_cash_pct, current_cash_pct - 0.105, current_cash_pct + 0.1, target_cash_pct]

x_pos = np.arange(len(execution_steps))
ax2.plot(x_pos, cash_path_sell_first, marker='o', linewidth=2, label='先卖后买', color='#2E8B57')
ax2.plot(x_pos, cash_path_buy_first, marker='s', linewidth=2, label='先买后卖', color='#C4612F', linestyle='--')

# 添加8%下限线
ax2.axhline(0.08, color='red', linestyle='--', linewidth=2, label='现金下限(8%)', zorder=10)

ax2.set_xticks(x_pos)
ax2.set_xticklabels(execution_steps, fontsize=9)
ax2.set_ylabel('人民币现金占比', fontsize=10)
ax2.set_title('图4-b：调仓执行现金路径与下限', fontsize=12, fontweight='bold')
ax2.legend(loc='best', fontsize=9)
ax2.set_ylim(0, 0.25)
ax2.yaxis.set_major_formatter(plt.FuncFormatter(lambda y, _: f'{y:.0%}'))
ax2.grid(alpha=0.3)

# 4c: 反向压力测试最可能情景（示例）
ax3 = fig.add_subplot(gs[2])

# 简化：显示推荐方案在各情景下的损失
scenarios = ['S1', 'S2', 'S3', 'S4']
rec_losses_committee = [-stress_results['推荐方案'][s]['committee']['total'] for s in scenarios]
rec_losses_calibrated = [-stress_results['推荐方案'][s]['calibrated']['total'] for s in scenarios]

x_pos = np.arange(len(scenarios))
width = 0.35

ax3.bar(x_pos - width/2, rec_losses_committee, width, label='委员会冲击', color='#C4612F', alpha=0.8)
ax3.bar(x_pos + width/2, rec_losses_calibrated, width, label='校准冲击', color='#5C635D', alpha=0.8)

ax3.set_xlabel('情景', fontsize=10)
ax3.set_ylabel('压力损失', fontsize=10)
ax3.set_title('图4-c：推荐方案在各情景下的压力损失', fontsize=12, fontweight='bold')
ax3.set_xticks(x_pos)
ax3.set_xticklabels(scenarios, fontsize=9)
ax3.legend(loc='best', fontsize=9)
ax3.yaxis.set_major_formatter(plt.FuncFormatter(lambda y, _: f'{y:.1%}'))
ax3.grid(axis='y', alpha=0.3)

plt.savefig(CHART_DIR / 'FIN3-WKN-149_chart04_方案决策与执行.png', dpi=150, bbox_inches='tight')
plt.close()
print("✓ 图表4已保存")

# 图表5：监测指标触发状态
fig, ax = plt.subplots(figsize=(12, 8))

monitor_ids = ['M1', 'M2', 'M3', 'M4', 'M5', 'M6', 'M7', 'M8']
monitor_names = [
    '沪深300\n20日收益',
    'USD/CNH\n20日变化',
    'DR007\n资金面变化',
    '10年期国债\n20日变化',
    '美国10年期\n20日变化',
    'PPI\n同比加速',
    '制造业PMI\n荣枯线',
    '社融存量\n增速'
]

latest_values = []
thresholds = []
statuses = []

for mid in monitor_ids:
    if monitoring and mid in monitoring:
        ind = monitoring[mid]
        if ind['value'] is not None:
            latest_values.append(ind['value'])
            thresholds.append(ind['threshold'])
            statuses.append('触发' if ind['triggered'] else '正常')
        else:
            latest_values.append(0)
            thresholds.append(ind['threshold'] if ind['threshold'] else 0)
            statuses.append('缺失')
    else:
        latest_values.append(0)
        thresholds.append(0)
        statuses.append('缺失')

x_pos = np.arange(len(monitor_ids))
width = 0.35

bars1 = ax.bar(x_pos - width/2, latest_values, width, label='最新值', alpha=0.8)
bars2 = ax.bar(x_pos + width/2, thresholds, width, label='阈值', alpha=0.8, color='orange')

# 颜色标记触发状态
for i, (bar, status) in enumerate(zip(bars1, statuses)):
    if status == '触发':
        bar.set_color('red')
    elif status == '缺失':
        bar.set_color('lightgray')

ax.set_xlabel('监测指标', fontsize=10)
ax.set_ylabel('指标值', fontsize=10)
ax.set_title('图5：监测指标触发状态', fontsize=13, fontweight='bold')
ax.set_xticks(x_pos)
ax.set_xticklabels(monitor_names, fontsize=8, ha='center')
ax.legend(loc='best', fontsize=9)
ax.axhline(0, color='black', linewidth=0.5)
ax.yaxis.set_major_formatter(plt.FuncFormatter(lambda y, _: f'{y:.1%}'))
ax.grid(axis='y', alpha=0.3)

# 添加状态标注
for i, status in enumerate(statuses):
    if status != '正常':
        ax.text(i, max(latest_values[i], thresholds[i]) + 0.002,
                status, ha='center', va='bottom', fontsize=8,
                color='red' if status == '触发' else 'gray')

plt.tight_layout()
plt.savefig(CHART_DIR / 'FIN3-WKN-149_chart05_监测指标触发状态.png', dpi=150, bbox_inches='tight')
plt.close()
print("✓ 图表5已保存")

# =====================================================================
# 第十部分：输出汇总数据
# =====================================================================

print("\n" + "=" * 80)
print("输出汇总数据")
print("=" * 80)

# 保存关键结果到字典，供备忘录使用
summary_results = {
    'analysis_date': ANALYSIS_DATE.strftime('%Y-%m-%d'),
    'portfolio_nav': PORTFOLIO_NAV,
    'data_coverage': data_coverage,
    'sample_period': {
        'start': df_returns['date'].min().strftime('%Y-%m-%d'),
        'end': df_returns['date'].max().strftime('%Y-%m-%d'),
        'trading_days': len(df_returns)
    },
    'current_weights': current_weights,
    'recommended_weights': recommended_weights,
    'candidate_plans': plan_weights,
    'risk_metrics': risk_metrics,
    'stress_results': stress_results,
    'max_stress_loss': max_stress_loss,
    'constraint_results': constraint_results,
    'scenario_months': {k: len(v) for k, v in scenario_months.items()},
    'monitoring': monitoring
}

# 输出推荐方案详情
print("\n推荐方案权重:")
for asset, weight in recommended_weights.items():
    print(f"  {asset}: {weight:.2%}")

print(f"\n推荐方案风险指标:")
rec_metrics = risk_metrics['推荐方案']
print(f"  年化波动率: {rec_metrics['annual_vol']:.2%}")
print(f"  1日ES99: {rec_metrics['es_99_1d']:.2%}")
print(f"  10日VaR99: {rec_metrics['var_99_10d']:.2%}")
print(f"  最大回撤: {rec_metrics['max_drawdown']:.2%}")

print(f"\n推荐方案最大压力损失:")
rec_max_loss = max_stress_loss['推荐方案']
print(f"  损失: {-rec_max_loss['loss']:.2%}")
print(f"  情景: {rec_max_loss['scenario']}")
print(f"  冲击类型: {rec_max_loss['shock_type']}")

# 计算单向换手率
turnover = 0
for asset in current_weights:
    change = abs(recommended_weights.get(asset, 0) - current_weights[asset])
    if recommended_weights.get(asset, 0) < current_weights[asset]:
        turnover += change

print(f"\n单向换手率: {turnover:.2%}")

# 输出交易清单
print("\n交易清单:")
for asset in current_weights:
    current = current_weights[asset]
    target = recommended_weights.get(asset, 0)
    if abs(target - current) > 0.0001:
        direction = "买入" if target > current else "卖出"
        amount = abs(target - current) * PORTFOLIO_NAV
        print(f"  {asset}: {direction} {amount:.2f} 万元 ({current:.2%} → {target:.2%})")

print("\n" + "=" * 80)
print("分析完成")
print("=" * 80)
print(f"\n输出目录: {OUTPUT_DIR}")
print(f"图表目录: {CHART_DIR}")
print("\n已生成5张图表:")
print("  1. 数据覆盖与缺口")
print("  2. 历史风险总览")
print("  3. 情景识别与校准")
print("  4. 方案决策与执行")
print("  5. 监测指标触发状态")
