from pathlib import Path
import re
import warnings
warnings.filterwarnings('ignore')
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib import font_manager

BASE = Path('/app/input_files')
OUT = Path('/app/output')
CHART = OUT / 'FIN3-WKN-149_charts'
OUT.mkdir(exist_ok=True)
CHART.mkdir(exist_ok=True)
CUTOFF = pd.Timestamp('2026-09-15')
NAV = 10000.0

# Use an installed Chinese font when available.
fonts = [f.name for f in font_manager.fontManager.ttflist]
for candidate in ['Noto Sans CJK SC', 'WenQuanYi Zen Hei', 'SimHei', 'Arial Unicode MS']:
    if candidate in fonts:
        plt.rcParams['font.sans-serif'] = [candidate, 'DejaVu Sans']
        break
plt.rcParams['axes.unicode_minus'] = False
plt.rcParams['figure.dpi'] = 130


def read_csv(name):
    d = pd.read_csv(BASE / name)
    if 'date' in d.columns:
        d['date'] = pd.to_datetime(d['date'])
        d = d.sort_values('date')
    return d


def fmt_pct(x):
    return 'N/A' if pd.isna(x) else f'{x * 100:.2f}%'


def fmt_bp(x):
    return 'N/A' if pd.isna(x) else f'{x:.2f}bp'


def fmt_num(x):
    return 'N/A' if pd.isna(x) else f'{x:.2f}'


def md_table(df):
    if df.empty:
        return '（无记录）'
    x = df.copy().fillna('N/A').astype(str)
    cols = list(x.columns)
    lines = ['| ' + ' | '.join(cols) + ' |', '| ' + ' | '.join(['---'] * len(cols)) + ' |']
    for row in x.itertuples(index=False, name=None):
        lines.append('| ' + ' | '.join(str(v).replace('|', '/') for v in row) + ' |')
    return '\n'.join(lines)


# ---------- Inputs and data validation ----------
calendar = read_csv('snapshot_trade_calendar.csv')
calendar = calendar[(calendar['exchange'].astype(str).str.upper() == 'SSE') & (calendar['is_trading_day'] == 1)]
calendar = calendar[calendar['date'] <= CUTOFF]
trade_dates = pd.DatetimeIndex(calendar['date'].drop_duplicates().sort_values())
trade_set = set(trade_dates)

raw_files = sorted(BASE.glob('snapshot_*.csv'))
manifest = read_csv('snapshot_data_manifest.csv') if (BASE / 'snapshot_data_manifest.csv').exists() else pd.DataFrame()
manifest_map = manifest.set_index('file').to_dict('index') if not manifest.empty else {}

def load_segments(prefix):
    files = sorted(BASE.glob(prefix + '_seg*.csv'))
    frames = [read_csv(f.name) for f in files]
    d = pd.concat(frames, ignore_index=True).sort_values('date')
    duplicate_dates = int(d['date'].duplicated().sum())
    d = d.drop_duplicates('date', keep='last')
    return d, [f.name for f in files], duplicate_dates


def load_single(name):
    return read_csv(name), [name], 0

# Segmented market series are stitched first, then non-SSE records are removed.
series_specs = {
    '沪深300收盘': ('eq300', lambda: load_segments('snapshot_000300SH')),
    '中证500收盘': ('eq500', lambda: load_segments('snapshot_000905SH')),
    '创业板收盘': ('gem', lambda: load_segments('snapshot_399006SZ')),
    'USD/CNH': ('fx', lambda: load_segments('snapshot_usdcnh')),
    '标普500美元收盘': ('spx', lambda: load_single('snapshot_spx.csv')),
    '中债1年': ('cgb1', lambda: load_single('snapshot_cgb_yield_1y.csv')),
    '中债2年': ('cgb2', lambda: load_single('snapshot_cgb_yield_2y.csv')),
    '中债5年': ('cgb5', lambda: load_single('snapshot_cgb_yield_5y.csv')),
    '中债10年': ('cgb10', lambda: load_single('snapshot_cgb_yield_10y.csv')),
    '中债30年': ('cgb30', lambda: load_single('snapshot_cgb_yield_30y.csv')),
    'Shibor': ('shibor', lambda: load_segments('snapshot_shibor')),
    '1年期LPR': ('lpr1', lambda: load_single('snapshot_lpr_1y.csv')),
    '5年期LPR': ('lpr5', lambda: load_single('snapshot_lpr_5y.csv')),
    'DR007': ('dr007', lambda: load_single('snapshot_dr007.csv')),
    '制造业PMI': ('pmi', lambda: load_single('snapshot_pmi_manufacturing.csv')),
    '社融存量': ('afre', lambda: load_single('snapshot_afre_stock.csv')),
    'PPI同比': ('ppi', lambda: load_single('snapshot_ppi_yoy.csv')),
    '美国10年国债': ('ust10', lambda: load_single('snapshot_ust_10y.csv')),
    '美国M2期限': ('ustm2', lambda: load_single('snapshot_ust_m2.csv')),
    '美国M4期限': ('ustm4', lambda: load_single('snapshot_ust_m4.csv')),
}
raw = {}
audit = []
for label, (key, loader) in series_specs.items():
    d, files, dup = loader()
    d = d[d['date'] <= CUTOFF].copy()
    off_sse = []
    if key in {'eq300', 'eq500', 'gem'}:
        off_sse = sorted(set(d.loc[~d['date'].isin(trade_set), 'date']))
        d = d[d['date'].isin(trade_set)].copy()
    raw[key] = d
    date_col = d['date']
    missing_dates = []
    if key in {'eq300','eq500','gem','fx','spx','cgb1','cgb2','cgb5','cgb10','cgb30','shibor','dr007','ust10','ustm2','ustm4'}:
        if len(date_col):
            expected = trade_dates[(trade_dates >= date_col.min()) & (trade_dates <= date_col.max())]
            missing_dates = expected[~expected.isin(set(date_col))]
    nulls = int(d.drop(columns=['date']).isna().sum().sum())
    m = manifest_map.get(files[0], {}) if files else {}
    audit.append({
        '序列': label,
        '覆盖起始': date_col.min().strftime('%Y-%m-%d') if len(date_col) else 'N/A',
        '覆盖终止': date_col.max().strftime('%Y-%m-%d') if len(date_col) else 'N/A',
        '记录数': len(d),
        '上游截断标记': str(m.get('possible_truncation', '')) if m else '',
        '交易日缺口': len(missing_dates),
        '缺口示例': ','.join(pd.Series(missing_dates).dt.strftime('%Y-%m-%d').head(3).tolist()) if len(missing_dates) else '无',
        '结构性空值/字段空值': nulls,
        '剔除休市记录': ','.join(pd.Series(off_sse).dt.strftime('%Y-%m-%d').tolist()) if off_sse else '无',
    })
audit_df = pd.DataFrame(audit)

# Structural missing values are not converted to zero or forward-filled before first observation.
def align(key, column):
    s = raw[key].set_index('date')[column].sort_index()
    out = s.reindex(trade_dates).ffill()
    # Do not manufacture observations after the source actually ends.
    out.loc[out.index > s.index.max()] = np.nan
    return out

prices = pd.DataFrame(index=trade_dates)
prices['eq300'] = align('eq300', 'close')
prices['eq500'] = align('eq500', 'close')
prices['gem'] = align('gem', 'close')
prices['fx'] = align('fx', 'usdcnh')
prices['spx'] = align('spx', 'close')
for k in ['cgb1','cgb2','cgb5','cgb10','cgb30']:
    prices[k] = align(k, 'yield_pct')

# Parameters, plans, limits, and rules are read from the supplied files.
holdings = read_csv('params_holdings.csv')
positions = read_csv('params_positions.csv')
plans = read_csv('plans_candidates.csv')
limits = read_csv('params_limits.csv')
duration = read_csv('params_duration.csv')
shocks = read_csv('params_committee_shocks.csv')
monitor_template = read_csv('template_monitor.csv')
window_rules = read_csv('rules_windows.csv')
scenario_rules = read_csv('rules_scenarios.csv')
rebalance_rules = read_csv('rules_rebalance.csv')

dur = dict(zip(duration['tenor'].astype(str), duration['duration_contribution']))
dur_vec = np.array([dur['1年'], dur['2年'], dur['5年'], dur['10年'], dur['30年']], dtype=float)
asset_cols = ['eq300','eq500','gem','cgb','usd_cash','spx','cny_cash']
asset_names = ['沪深300指数基金','中证500指数基金','创业板指数基金','中长期国债组合','美元现金及存款','标普500 QDII基金','人民币现金及货基']
class_map = dict(zip(holdings['asset_class'], holdings['asset']))
current_w = holdings.set_index('asset_class')['weight_current'].astype(float).to_dict()
recommended_w = holdings.set_index('asset_class')['weight_recommended'].astype(float).to_dict()
plan_cols = ['w_000300','w_000905','w_399006','w_cgb','w_usd_cash','w_spx_qdii','w_cny_cash']

def plan_vector(row):
    return np.array([row['w_000300'], row['w_000905'], row['w_399006'], row['w_cgb'], row['w_usd_cash'], row['w_spx_qdii'], row['w_cny_cash']], dtype=float)

weights_current = np.array([current_w['EQ_000300'], current_w['EQ_000905'], current_w['EQ_399006'], current_w['CGB'], current_w['USD_CASH'], current_w['SPX'], current_w['CNY_CASH']])
weights_recommended = np.array([recommended_w['EQ_000300'], recommended_w['EQ_000905'], recommended_w['EQ_399006'], recommended_w['CGB'], recommended_w['USD_CASH'], recommended_w['SPX'], recommended_w['CNY_CASH']])
plan_weights = {'当前组合': weights_current, '推荐方案': weights_recommended}
for _, row in plans.iterrows():
    plan_weights[row['plan_id']] = plan_vector(row)

# Return construction. All multi-market prices are first aligned to SSE valuation dates.
ret = pd.DataFrame(index=trade_dates)
for col in ['eq300','eq500','gem']:
    ret[col] = prices[col].pct_change()
ret['usd_cash'] = prices['fx'].pct_change()
ret['spx'] = (1 + prices['spx'].pct_change()) * (1 + prices['fx'].pct_change()) - 1
yield_delta = prices[['cgb1','cgb2','cgb5','cgb10','cgb30']].diff()
ret['cgb'] = -(yield_delta.div(100).mul(dur_vec, axis=1).sum(axis=1, min_count=5))
ret['cny_cash'] = 0.0
ret = ret[asset_cols]
common_ret = ret.dropna().copy()
common_dates = common_ret.index
prices_common = prices.loc[common_dates]


def portfolio_return(weights, returns=common_ret):
    return returns.mul(weights, axis=1).sum(axis=1)


def risk_metrics(weights):
    r = portfolio_return(weights)
    r1 = r.dropna()
    q95, q99 = r1.quantile([0.01, 0.05])
    loss = -r1
    es95 = -r1[r1 <= q95].mean()
    es99 = -r1[r1 <= q99].mean()
    roll10 = (1 + r1).rolling(10).apply(np.prod, raw=True) - 1
    q10 = roll10.dropna().quantile(0.01)
    min10 = roll10.dropna().min()
    min10_end = roll10.dropna().idxmin()
    min10_start = r1.index[r1.index.get_loc(min10_end) - 9]
    wealth = (1 + r1).cumprod()
    drawdown = wealth / wealth.cummax() - 1
    mdd = drawdown.min()
    mdd_end = drawdown.idxmin()
    prior_peak = wealth.loc[:mdd_end].cummax().idxmax()
    recovery = wealth.loc[mdd_end:][wealth.loc[mdd_end:] >= wealth.loc[:mdd_end].cummax().loc[mdd_end]]
    recovery_date = recovery.index[0] if len(recovery) else pd.NaT
    cov = common_ret.cov()
    sigma = np.sqrt(weights @ cov.values @ weights) if np.all(np.isfinite(cov.values)) else np.nan
    marginal = cov.values @ weights
    rc = weights * marginal / (sigma**2) if sigma else np.full(len(weights), np.nan)
    return {
        'annual_vol': sigma * np.sqrt(252),
        'var95_1d': -q95, 'var99_1d': -q99,
        'es95_1d': es95, 'es99_1d': es99,
        'var99_10d': -q10, 'max10_loss': -min10,
        'max10_start': min10_start, 'max10_end': min10_end,
        'mdd': -mdd, 'mdd_peak': prior_peak, 'mdd_end': mdd_end, 'mdd_recovery': recovery_date,
        'worst_day': r1.idxmin(), 'worst_day_loss': -r1.min(), 'rc': rc,
        'returns': r1, 'roll10': roll10,
    }

risk = {name: risk_metrics(w) for name, w in plan_weights.items()}

# ---------- Monthly scenario identification and ten-day windows ----------
# Monthly series use last observation or monthly mean; no structural values are filled.
def monthly_last(key, col):
    return raw[key].set_index('date')[col].resample('ME').last()

def monthly_mean_aligned(series):
    return series.resample('ME').mean()

eq_norm = weights_current[:3] / weights_current[:3].sum()
monthly_eq = (prices[['eq300','eq500','gem']].mul(eq_norm, axis=1).sum(axis=1)).resample('ME').last().pct_change()
monthly_spx = prices['spx'].resample('ME').last().pct_change()
monthly_fx = prices['fx'].resample('ME').last().pct_change()
monthly_y10_mean = prices['cgb10'].resample('ME').mean()
monthly_pmi = monthly_last('pmi', 'pmi_mfg')
monthly_ppi = monthly_last('ppi', 'ppi_yoy')
monthly_lpr1 = monthly_last('lpr1', 'lpr_1y')
monthly_lpr5 = monthly_last('lpr5', 'lpr_5y')
monthly_afre = monthly_last('afre', 'afre_stock')
monthly_dr007 = prices['fx'].copy() * np.nan
raw_dr = raw['dr007'].set_index('date')['dr007']
monthly_dr007 = raw_dr.resample('ME').mean()
monthly_afre_growth = monthly_afre.pct_change(12) * 100

months = pd.date_range('2018-01-31', CUTOFF, freq='ME')
month_index = pd.DatetimeIndex(sorted(set(months) | set(monthly_pmi.dropna().index) | set(monthly_ppi.dropna().index)))
# Build boolean rules explicitly, preserving missing-data uncertainty as False.
pmi_prev = monthly_pmi.shift(1)
lpr_down = ((monthly_lpr1 < monthly_lpr1.shift(1)) & monthly_lpr1.notna() & monthly_lpr1.shift(1).notna()) | ((monthly_lpr5 < monthly_lpr5.shift(1)) & monthly_lpr5.notna() & monthly_lpr5.shift(1).notna())
s1 = ((monthly_pmi < 50) & lpr_down) | ((monthly_pmi.diff() <= -0.5) & (monthly_y10_mean < monthly_y10_mean.shift(1)))
s2 = (monthly_ppi > monthly_ppi.shift(1)) & (monthly_y10_mean > monthly_y10_mean.shift(1)) & (monthly_eq < 0)
s3 = (monthly_spx <= -0.03) | (monthly_fx >= 0.015)
s4 = (monthly_afre_growth < monthly_afre_growth.shift(1)) & (monthly_dr007 > monthly_dr007.shift(1)) & (monthly_eq < 0)
scenario_flags = pd.DataFrame({'S1': s1, 'S2': s2, 'S3': s3, 'S4': s4}).fillna(False).astype(bool)
scenario_flags = scenario_flags[(scenario_flags.index >= common_dates.min().to_period('M').to_timestamp('M')) & (scenario_flags.index <= CUTOFF)]

committee = {}
for _, row in shocks.iterrows():
    vals = {}
    for k in ['1Y','2Y','5Y','10Y','30Y']:
        m = re.search(rf'{k}:([+-]?[0-9.]+)', str(row['cgb_shock_bp']))
        vals[k] = float(m.group(1)) if m else np.nan
    committee[row['scenario_id']] = {
        'cn_eq': float(row['cn_equity_shock']), 'spx_usd': float(row['spx_usd_shock']), 'fx': float(row['usdcnh_shock']),
        'cgb_bp': np.array([vals['1Y'], vals['2Y'], vals['5Y'], vals['10Y'], vals['30Y']]),
    }

# One candidate window per qualifying month: next SSE day, ten observations, all portfolio returns negative.
def next_trade_after(date):
    x = trade_dates[trade_dates > pd.Timestamp(date)]
    return x[0] if len(x) else pd.NaT

window_records = []
selected_windows = {}
window_audit = {}
for sid in ['S1','S2','S3','S4']:
    qmonths = scenario_flags.index[scenario_flags[sid]]
    all_candidates = []
    strict_candidates = []
    for month in qmonths:
        start = next_trade_after(month)
        if pd.isna(start) or start not in common_ret.index:
            continue
        loc = common_ret.index.get_loc(start)
        if loc + 10 > len(common_ret):
            continue
        dates = common_ret.index[loc:loc+10]
        pr = portfolio_return(weights_current).loc[dates]
        if len(pr) == 10:
            cumulative = float((1 + pr).prod() - 1)
            item = {'scenario': sid, 'month': month, 'start': dates[0], 'end': dates[-1], 'cum': cumulative, 'dates': dates}
            all_candidates.append(item)
            if (pr < 0).all():
                strict_candidates.append(item)
    strict_candidates = sorted(strict_candidates, key=lambda x: x['cum'])
    all_candidates = sorted(all_candidates, key=lambda x: x['cum'])
    # The supplied rule can produce no windows at all on this dataset. Preserve
    # that fact in the audit and use the worst available next-month windows only
    # as a separately disclosed calibration sensitivity, never as missing data.
    fallback = len(strict_candidates) == 0 and len(all_candidates) > 0
    selected = strict_candidates[:min(20, len(strict_candidates))] if strict_candidates else all_candidates[:min(20, len(all_candidates))]
    selected_windows[sid] = selected
    window_audit[sid] = {'all': len(all_candidates), 'strict': len(strict_candidates), 'fallback': fallback}
    for x in selected:
        window_records.append({k: x[k] for k in ['scenario','month','start','end','cum']})

# Factor vectors: CN equity sleeve, SPX USD, USD/CNH, then five yield changes in bp.
def factor_vector(dates):
    # Use the directly compounded current domestic-equity sleeve returns.
    cnr = (common_ret.loc[dates, ['eq300','eq500','gem']].mul(eq_norm, axis=1).sum(axis=1) + 1).prod() - 1
    spx = float(prices['spx'].loc[dates[-1]] / prices['spx'].loc[dates[0]] - 1)
    fx = float(prices['fx'].loc[dates[-1]] / prices['fx'].loc[dates[0]] - 1)
    yields = (prices.loc[dates[-1], ['cgb1','cgb2','cgb5','cgb10','cgb30']].values - prices.loc[dates[0], ['cgb1','cgb2','cgb5','cgb10','cgb30']].values) * 100
    return np.r_[cnr, spx, fx, yields]

calibration = {}
for sid, ws in selected_windows.items():
    vecs = np.array([factor_vector(x['dates']) for x in ws]) if ws else np.empty((0,8))
    med = np.nanmedian(vecs, axis=0) if len(vecs) else np.full(8, np.nan)
    calibration[sid] = {'vectors': vecs, 'median': med, 'n': len(ws)}


def stress_result(weights, f):
    domestic = weights[:3].sum() * f['cn_eq']
    spx_rmb = weights[5] * ((1 + f['spx_usd']) * (1 + f['fx']) - 1)
    usd = weights[4] * f['fx']
    bond = weights[3] * (-np.sum(dur_vec * f['cgb_bp'] / 10000.0))
    return {'境内权益': domestic, '标普500（人民币计）': spx_rmb, '美元现金': usd, '国债': bond, '组合损益': domestic + spx_rmb + usd + bond}

stress_rows = []
for pname, w in plan_weights.items():
    if pname == '当前组合':
        continue
    for sid in ['S1','S2','S3','S4']:
        for shock_name, f in [('委员会沿用', committee[sid]), ('历史校准', {'cn_eq': calibration[sid]['median'][0], 'spx_usd': calibration[sid]['median'][1], 'fx': calibration[sid]['median'][2], 'cgb_bp': calibration[sid]['median'][3:]})]:
            if np.any(pd.isna(f['cgb_bp'])):
                res = {k: np.nan for k in ['境内权益','标普500（人民币计）','美元现金','国债','组合损益']}
            else:
                res = stress_result(w, f)
            stress_rows.append({'方案': pname, '情景': sid, '冲击': shock_name, **res, '压力损失': -res['组合损益'] if pd.notna(res['组合损益']) else np.nan})
stress_df = pd.DataFrame(stress_rows)

# ---------- Limits and monitoring ----------
limit_map = limits.set_index('id').to_dict('index')

def max_pressure(plan):
    x = stress_df[stress_df['方案'] == plan]['压力损失'].dropna()
    return x.max() if len(x) else np.nan

def check_row(plan, lid, value, passed, note=''):
    lim = limit_map[lid]
    return {'方案': plan, '限额': lid, '指标': lim['constraint'], '实际值': value, '结果': '通过' if passed else '未通过', '超限幅度': note}

checks = []
for pname, w in plan_weights.items():
    if pname == '当前组合':
        continue
    rm = risk[pname]
    checks += [
        check_row(pname, 'L1', w.sum(), abs(w.sum()-1) <= 0.0005, fmt_pct(abs(w.sum()-1))),
        check_row(pname, 'L2', w[:3].sum(), w[:3].sum() <= 0.6, fmt_pct(max(0,w[:3].sum()-0.6))),
        check_row(pname, 'L3', w[6], 0.08 <= w[6] <= 0.20, fmt_pct(max(0,0.08-w[6])+max(0,w[6]-0.20))),
        check_row(pname, 'L4', w[3], w[3] >= 0.15, fmt_pct(max(0,0.15-w[3]))),
        check_row(pname, 'L5', w[4]+w[5], w[4]+w[5] <= 0.25, fmt_pct(max(0,w[4]+w[5]-0.25))),
        check_row(pname, 'L6', rm['es99_1d'], rm['es99_1d'] <= 0.035, fmt_pct(max(0,rm['es99_1d']-0.035))),
        check_row(pname, 'L7', rm['var99_10d'], rm['var99_10d'] <= 0.06, fmt_pct(max(0,rm['var99_10d']-0.06))),
        check_row(pname, 'L8', max_pressure(pname), max_pressure(pname) <= 0.08, fmt_pct(max(0,max_pressure(pname)-0.08))),
    ]
    if pname != '推荐方案':
        checks.append({'方案':pname,'限额':'L9','指标':limit_map['L9']['constraint'],'实际值':'不适用','结果':'不适用','超限幅度':'不适用'})
checks += [check_row('推荐方案', 'L9', max_pressure('推荐方案'), max_pressure('推荐方案') <= 0.07, fmt_pct(max(0,max_pressure('推荐方案')-0.07)))]
checks_df = pd.DataFrame(checks)

# Monitor metrics use the latest available non-structural observation and disclose stale data.
def latest_window_change(series, n=20):
    s = series.dropna()
    if len(s) <= n: return np.nan, pd.NaT
    return float(s.iloc[-1] / s.iloc[-(n+1)] - 1), s.index[-1]

def latest_diff(series, n=20):
    s = series.dropna()
    if len(s) <= n: return np.nan, pd.NaT
    return float(s.iloc[-1] - s.iloc[-(n+1)]), s.index[-1]

def monitor_calc():
    vals = {}
    v, d = latest_window_change(prices['eq300']); vals['M1']=(v, d, '比例')
    v, d = latest_window_change(prices['fx']); vals['M2']=(v, d, '比例')
    dr = raw['dr007'].set_index('date')['dr007'].reindex(trade_dates).ffill().dropna()
    v = float(dr.iloc[-20:].mean() - dr.iloc[-80:-20].mean()); vals['M3']=(v*100, dr.index[-1], 'bp')
    v, d = latest_diff(prices['cgb10']); vals['M4']=(v*100, d, 'bp')
    u = raw['ust10'].set_index('date')['yield_pct'].reindex(trade_dates).ffill()
    v, d = latest_diff(u); vals['M5']=(v*100, d, 'bp')
    p = raw['ppi'].set_index('date')['ppi_yoy']; v = float(p.dropna().iloc[-1] - p.dropna().iloc[-4]); vals['M6']=(v, p.dropna().index[-1], '百分点')
    pm = raw['pmi'].set_index('date')['pmi_mfg'].dropna(); vals['M7']=(float(pm.iloc[-1]), pm.index[-1], '指数')
    ag = monthly_afre_growth.dropna(); vals['M8']=(float(ag.iloc[-1]), raw['afre']['date'].max(), '百分数')
    return vals
monitor_values = monitor_calc()
monitor_rows=[]
threshold_num={'M1':-0.05,'M2':0.02,'M3':20.0,'M4':10.0,'M5':40.0,'M6':1.5,'M7':49.0,'M8':8.0}
for _, row in monitor_template.iterrows():
    mid=row['monitor_id']; val, asof, unit=monitor_values[mid]
    trig = (val < threshold_num[mid]) if row['direction']=='低于阈值触发' else (val > threshold_num[mid])
    stale = asof < CUTOFF
    status = ('触发' if trig else '未触发') + ('；数据滞后' if stale else '')
    monitor_rows.append({'monitor_id':mid,'indicator':row['indicator'],'definition':row['definition'],'threshold':row['threshold'],'direction':row['direction'],'latest_value':val,'data_asof':asof.strftime('%Y-%m-%d'),'status':status,'triggered':bool(trig),'unit':unit})
monitor_df=pd.DataFrame(monitor_rows)

# ---------- Mahalanobis reverse stress ----------
all_vectors = np.vstack([x['vectors'] for x in calibration.values() if len(x['vectors'])]) if any(len(x['vectors']) for x in calibration.values()) else np.empty((0,8))
if len(all_vectors) >= 3:
    mu = np.nanmedian(all_vectors, axis=0)
    cov = np.cov(all_vectors, rowvar=False)
    cov = np.nan_to_num(cov, nan=0.0) + np.eye(8) * max(np.nanmedian(np.diag(cov))*1e-4, 1e-8)
    invcov = np.linalg.pinv(cov)
    def md(v):
        z=np.asarray(v,float)-mu
        return float(np.sqrt(z @ invcov @ z))
else:
    mu=np.zeros(8); invcov=np.eye(8)
    md=lambda v: np.nan
md_committee={sid:md(np.r_[f['cn_eq'],f['spx_usd'],f['fx'],f['cgb_bp']]) for sid,f in committee.items()}
md_calibration={sid:md(calibration[sid]['median']) if not np.any(pd.isna(calibration[sid]['median'])) else np.nan for sid in calibration}
reverse_sid=min(md_committee, key=lambda k: md_committee[k] if pd.notna(md_committee[k]) else np.inf)

# Same-turnover uniqueness comparison: keep FX weights and proportional domestic-equity reduction,
# then move 0.50 percentage point from CNY cash to CGB relative to recommendation.
alt_w=weights_recommended.copy(); alt_w[3]+=0.005; alt_w[6]-=0.005
alt_name='同换手率次优候选（CGB+0.50个百分点、人民币现金-0.50个百分点）'
plan_weights[alt_name]=alt_w
risk[alt_name]=risk_metrics(alt_w)
alt_stress=[]
for sid in ['S1','S2','S3','S4']:
    for shock_name,f in [('委员会沿用',committee[sid]),('历史校准',{'cn_eq':calibration[sid]['median'][0],'spx_usd':calibration[sid]['median'][1],'fx':calibration[sid]['median'][2],'cgb_bp':calibration[sid]['median'][3:]})]:
        if not np.any(pd.isna(f['cgb_bp'])): alt_stress.append(-stress_result(alt_w,f)['组合损益'])
alt_max=max(alt_stress) if alt_stress else np.nan

# ---------- Charts ----------
def savefig(fig, name):
    fig.tight_layout()
    fig.savefig(CHART/name, dpi=180, bbox_inches='tight')
    plt.close(fig)

# Chart 1: coverage and gaps
fig, ax = plt.subplots(figsize=(11,9))
plot_audit=audit_df.copy(); plot_audit['start']=pd.to_datetime(plot_audit['覆盖起始'], errors='coerce'); plot_audit['end']=pd.to_datetime(plot_audit['覆盖终止'], errors='coerce')
plot_audit=plot_audit.sort_values('start')
y=np.arange(len(plot_audit)); ax.barh(y, (plot_audit['end']-plot_audit['start']).dt.days, left=plot_audit['start'].map(mdates.date2num), color='#4c78a8')
ax.axvline(mdates.date2num(CUTOFF), color='red', ls='--', label='分析截至日 2026-09-15')
ax.set_yticks(y); ax.set_yticklabels(plot_audit['序列']); ax.xaxis_date(); ax.xaxis.set_major_locator(mdates.YearLocator()); ax.xaxis.set_major_formatter(mdates.DateFormatter('%Y'))
ax.set_title('图1-a 数据序列实际覆盖区间与分析截至日'); ax.legend(loc='lower right')
for yi, (_, r) in enumerate(plot_audit.iterrows()):
    if r['交易日缺口'] or r['结构性空值/字段空值'] or r['剔除休市记录']!='无':
        ax.text(mdates.date2num(CUTOFF)+20, yi, f"缺口{int(r['交易日缺口'])}/空值{int(r['结构性空值/字段空值'])}", va='center', fontsize=7)
ax.set_xlim(mdates.date2num(pd.Timestamp('2017-10-01')), mdates.date2num(CUTOFF+pd.Timedelta(days=160)))
savefig(fig,'FIN3-WKN-149_chart01_数据覆盖与缺口.png')

# Chart 2: historical risk overview
fig, (ax1, ax2)=plt.subplots(2,1,figsize=(14,11),gridspec_kw={'height_ratios':[1.3,1]})
for name,color in [('当前组合','#444444'),('方案A','#1f77b4'),('方案B','#2ca02c'),('方案C','#d62728'),('推荐方案','#9467bd')]:
    if name in risk:
        ax1.plot((1+risk[name]['returns']).cumprod(), label=name, lw=1.1, color=color)
ax1.set_title('图2-a 各方案历史累计净值曲线（每日再平衡）'); ax1.legend(ncol=5); ax1.grid(alpha=.2); ax1.set_ylabel('累计净值（起点=1）')
labels=['年化波动率','1日ES99','10日VaR99','最大回撤']
plotnames=['方案A','方案B','方案C','推荐方案']; x=np.arange(len(plotnames)); width=.18
metrics=np.array([[risk[n]['annual_vol'],risk[n]['es99_1d'],risk[n]['var99_10d'],risk[n]['mdd']] for n in plotnames])
for j,l in enumerate(labels): ax2.bar(x+(j-1.5)*width, metrics[:,j]*100, width, label=l)
ax2.axhline(float(limit_map['L6']['upper'])*100,color='orange',ls='--',lw=1,label=f"ES99限额 {float(limit_map['L6']['upper'])*100:.2f}%"); ax2.axhline(float(limit_map['L7']['upper'])*100,color='red',ls='--',lw=1,label=f"10日VaR99限额 {float(limit_map['L7']['upper'])*100:.2f}%")
ax2.set_xticks(x); ax2.set_xticklabels(plotnames); ax2.set_ylabel('%'); ax2.set_title('图2-b 历史风险指标与限额参考线'); ax2.legend(ncol=3,fontsize=8); ax2.grid(axis='y',alpha=.2)
savefig(fig,'FIN3-WKN-149_chart02_历史风险总览.png')

# Chart 3: scenario identification and calibration
fig=plt.figure(figsize=(15,13)); gs=fig.add_gridspec(3,1,height_ratios=[1.2,1,1.2])
ax=fig.add_subplot(gs[0]); flag= scenario_flags.astype(int).T; ax.imshow(flag,aspect='auto',interpolation='nearest',cmap='Blues',vmin=0,vmax=1); ax.set_yticks(range(4)); ax.set_yticklabels(['S1增长下行','S2通胀上行','S3外部冲击','S4信用收缩']);
xt=np.linspace(0,len(flag.columns)-1,min(12,len(flag.columns))).astype(int); ax.set_xticks(xt); ax.set_xticklabels([flag.columns[i].strftime('%Y-%m') for i in xt],rotation=45,ha='right'); ax.set_title('图3-a 四情景月度识别结果（深色=合格）')
ax=fig.add_subplot(gs[1]); calmat=np.array([calibration[s]['median'] for s in ['S1','S2','S3','S4']]); names=['CN权益%','SPX美元%','USD/CNH%','1Y bp','2Y bp','5Y bp','10Y bp','30Y bp']; im=ax.imshow(calmat,aspect='auto',cmap='RdBu_r'); ax.set_yticks(range(4)); ax.set_yticklabels(['S1','S2','S3','S4']); ax.set_xticks(range(8)); ax.set_xticklabels(names,rotation=35,ha='right'); ax.set_title('图3-b 历史窗口校准冲击中位数'); fig.colorbar(im,ax=ax,shrink=.7)
ax=fig.add_subplot(gs[2]); ratios=[]
for sid in ['S1','S2','S3','S4']:
    cm=np.r_[committee[sid]['cn_eq'],committee[sid]['spx_usd'],committee[sid]['fx'],committee[sid]['cgb_bp']]; cal=calibration[sid]['median']; ratios.append(np.divide(np.abs(cm),np.abs(cal),out=np.full(8,np.nan),where=np.abs(cal)>1e-12))
rr=np.array(ratios); x=np.arange(8); w=.2
for i,sid in enumerate(['S1','S2','S3','S4']): ax.bar(x+(i-1.5)*w,rr[i],w,label=sid)
ax.axhline(1,color='black',ls='--'); ax.set_xticks(x); ax.set_xticklabels(names,rotation=35,ha='right'); ax.set_ylabel('|委员会|/|校准|'); ax.set_title('图3-c 沿用冲击相对历史校准的严格程度（>1 更严格）'); ax.legend(); ax.grid(axis='y',alpha=.2)
savefig(fig,'FIN3-WKN-149_chart03_情景识别与校准.png')

# Chart 4: decisions and execution
fig=plt.figure(figsize=(14,12)); gs=fig.add_gridspec(3,1)
ax=fig.add_subplot(gs[0]); pnames=['方案A','方案B','方案C','推荐方案']; vals=[max_pressure(n)*100 for n in pnames]; ax.bar(pnames,vals,color=['#1f77b4','#2ca02c','#d62728','#9467bd']); ax.axhline(float(limit_map['L8']['upper'])*100,color='red',ls='--',label=f"{float(limit_map['L8']['upper'])*100:.0f}%压力损失上限"); ax.axhline(float(limit_map['L9']['upper'])*100,color='orange',ls='--',label=f"{float(limit_map['L9']['upper'])*100:.0f}%缓冲线/推荐上限"); ax.set_ylabel('最大压力损失（%）'); ax.set_title('图4-a 各方案最大压力损失'); ax.legend(); ax.grid(axis='y',alpha=.2)
ax=fig.add_subplot(gs[1]); cash0=weights_current[6]*100; proceeds=np.maximum(weights_current-weights_recommended,0).sum()*100; cgb_buy=max(weights_recommended[3]-weights_current[3],0)*100; sell_first=[cash0,cash0+proceeds,cash0+proceeds-cgb_buy]; buy_first=[cash0,cash0-cgb_buy,cash0-cgb_buy+proceeds]; ax.plot(range(len(sell_first)),sell_first,marker='o',label='先卖后买'); ax.plot(range(len(buy_first)),buy_first,marker='o',label='先买后卖'); ax.axhline(float(limit_map['L3']['lower'])*100,color='red',ls='--',label='人民币现金下限 8%'); ax.set_xticks(range(3)); ax.set_xticklabels(['初始','第一步后','完成后']); ax.set_ylabel('人民币现金占比（%）'); ax.set_title('图4-b 调仓执行现金路径'); ax.legend(); ax.grid(alpha=.2)
ax=fig.add_subplot(gs[2]); ds=[md_committee[s] for s in ['S1','S2','S3','S4']]; ax.bar(['S1','S2','S3','S4'],ds,color=['#4c78a8','#f58518','#54a24b','#e45756']); ax.set_ylabel('马氏距离'); ax.set_title(f'图4-c 反向压力测试：最可能情景 {reverse_sid}'); ax.grid(axis='y',alpha=.2)
savefig(fig,'FIN3-WKN-149_chart04_方案决策与执行.png')

# Chart 5: monitoring
fig, axes=plt.subplots(2,4,figsize=(15,7));
for ax,(_,r) in zip(axes.flat,monitor_df.iterrows()):
    mid=r['monitor_id']; val=float(r['latest_value']); thr=threshold_num[mid]; ax.bar([0],[val],color='#d62728' if r['triggered'] else '#4c78a8'); ax.axhline(thr,color='black',ls='--'); ax.set_title(mid+' '+r['indicator'],fontsize=9); ax.set_xticks([]); ax.set_ylabel(r['unit']); ax.text(0, val, f'{val:.2f}',ha='center',va='bottom',fontsize=8); ax.text(.02,.05,r['status'],transform=ax.transAxes,fontsize=8); ax.grid(axis='y',alpha=.2)
fig.suptitle('图5 八个监测指标最新值、阈值与触发状态'); savefig(fig,'FIN3-WKN-149_chart05_监测指标触发状态.png')

# ---------- Memo ----------
# Tables for memo
pos_tbl=positions.copy(); pos_tbl['权重']=pos_tbl['weight_current'].map(fmt_pct); pos_tbl['金额（万元）']=pos_tbl['market_value_10k_cny'].map(lambda x:f'{x:.2f}'); pos_tbl=pos_tbl[['asset','权重','金额（万元）']].rename(columns={'asset':'资产'})
stat_rows=[]
for col,name in zip(asset_cols,asset_names):
    s=common_ret[col]
    stat_rows.append({'资产':name,'均值（日）':fmt_pct(s.mean()),'波动率（日）':fmt_pct(s.std()),'最差日':fmt_pct(s.min()),'累计收益':fmt_pct((1+s).prod()-1)})
stat_tbl=pd.DataFrame(stat_rows)
corr=common_ret.corr(); corr.index=asset_names; corr.columns=asset_names
risk_rows=[]
for pname in ['当前组合','方案A','方案B','方案C','推荐方案']:
    q=risk[pname]; risk_rows.append({'方案':pname,'年化波动率':fmt_pct(q['annual_vol']),'1日VaR95':fmt_pct(q['var95_1d']),'1日VaR99':fmt_pct(q['var99_1d']),'1日ES95':fmt_pct(q['es95_1d']),'1日ES99':fmt_pct(q['es99_1d']),'10日VaR99':fmt_pct(q['var99_10d']),'10日最大损失':fmt_pct(q['max10_loss']),'最大回撤':fmt_pct(q['mdd']),'最差单日':fmt_pct(q['worst_day_loss'])})
risk_tbl=pd.DataFrame(risk_rows)
rc_tbl=pd.DataFrame({'资产':asset_names,'风险贡献占比':risk['当前组合']['rc']}).assign(**{'风险贡献占比':lambda x:x['风险贡献占比'].map(fmt_pct)})

# Scenario tables
qmonth_tbl=[]
for sid in ['S1','S2','S3','S4']:
    qmonths=scenario_flags.index[scenario_flags[sid]]
    qmonth_tbl.append({'情景':sid,'月度规则':scenario_rules.loc[scenario_rules['scenario_id']==sid,'rule'].iloc[0],'全部合格月份':', '.join(qmonths.strftime('%Y-%m')) if len(qmonths) else '无','可构造窗口数':window_audit[sid]['all'],'严格全负窗口数':window_audit[sid]['strict'],'选定窗口数':calibration[sid]['n'],'是否使用敏感性回退': '是' if window_audit[sid]['fallback'] else '否'})
qmonth_df=pd.DataFrame(qmonth_tbl)
cal_tbl=[]
for sid in ['S1','S2','S3','S4']:
    m=calibration[sid]['median']; cal_tbl.append({'情景':sid,'CN权益':fmt_pct(m[0]),'SPX美元':fmt_pct(m[1]),'USD/CNH':fmt_pct(m[2]),'1Y':fmt_bp(m[3]),'2Y':fmt_bp(m[4]),'5Y':fmt_bp(m[5]),'10Y':fmt_bp(m[6]),'30Y':fmt_bp(m[7]),'窗口数':calibration[sid]['n']})
cal_df=pd.DataFrame(cal_tbl)

stress_display=stress_df.copy()
for c in ['境内权益','标普500（人民币计）','美元现金','国债','组合损益','压力损失']:
    stress_display[c]=stress_display[c].map(fmt_pct)
stress_display=stress_display[['方案','情景','冲击','境内权益','标普500（人民币计）','美元现金','国债','组合损益','压力损失']]
checks_display=checks_df.copy()
def format_check_value(x):
    if isinstance(x, str): return x
    return fmt_pct(x) if abs(x) < 2 else fmt_num(x)
checks_display['实际值']=checks_display['实际值'].map(format_check_value); checks_display=checks_display[['方案','限额','指标','实际值','结果','超限幅度']]
monitor_display=monitor_df.copy()
def format_monitor_value(r):
    v=float(r['latest_value'])
    if r['unit']=='比例': return fmt_pct(v)
    if r['unit']=='bp': return fmt_bp(v)
    if r['unit']=='百分点': return f'{v:.2f}个百分点'
    if r['unit']=='百分数': return f'{v:.2f}%'
    return f'{v:.2f}'
monitor_display['latest_value']=monitor_display.apply(format_monitor_value, axis=1)
monitor_display=monitor_display[['monitor_id','indicator','threshold','latest_value','data_asof','status','triggered']]

# Coverage summary and memo prose
coverage_tbl=audit_df[['序列','覆盖起始','覆盖终止','记录数','交易日缺口','缺口示例','结构性空值/字段空值','剔除休市记录']]
qmax=max_pressure('推荐方案'); qrisk=risk['推荐方案']; current_max=max_pressure('当前组合') if '当前组合' in stress_df['方案'].unique() else np.nan
# Current portfolio stress is separately computed for memo.
current_stress=[]
for sid in ['S1','S2','S3','S4']:
    for sn,f in [('委员会沿用',committee[sid]),('历史校准',{'cn_eq':calibration[sid]['median'][0],'spx_usd':calibration[sid]['median'][1],'fx':calibration[sid]['median'][2],'cgb_bp':calibration[sid]['median'][3:]})]:
        if not np.any(pd.isna(f['cgb_bp'])): current_stress.append(-stress_result(weights_current,f)['组合损益'])
current_max=max(current_stress) if current_stress else np.nan
q10=risk['推荐方案']['max10_loss']
turnover=float(np.abs(weights_recommended-weights_current).sum()/2)
trade_rows=[]
for asset,w0,w1 in zip(asset_names,weights_current,weights_recommended):
    delta=(w1-w0)*NAV
    if abs(delta)>1e-8: trade_rows.append({'证券':asset,'方向':'买入' if delta>0 else '卖出','金额（万元）':f'{abs(delta):.2f}'})
trade_tbl=pd.DataFrame(trade_rows)

memo=f'''# 多资产稳健配置专户 三季度宏观压力测试与调仓建议
## 风险委员会决策备忘录

分析截至日：**2026-09-15**；金额单位：**万元**；收益与损失均按比例表示，收益率变动注明 bp。

### 一、结论与建议

建议维持美元现金及未对冲标普500 QDII 各 10%，将境内权益按当前权重同比例缩减至推荐方案，将 1,050.00 万元转入中长期国债组合、1,000.00 万元转入人民币现金及货币基金；当前组合及三个候选方案按压力测试和九项约束分别处置，最终执行推荐方案。推荐方案最大压力损失为 **{fmt_pct(qmax)}**，1 日 ES99 为 **{fmt_pct(qrisk['es99_1d'])}**，10 日 VaR99 为 **{fmt_pct(qrisk['var99_10d'])}**，单向换手率为 **{fmt_pct(turnover)}**。由于国债曲线和社融数据截至日明显滞后，且四个情景严格全负历史窗口均为 0、只能提供回退敏感性校准，建议**提请临时风险会议**确认数据补齐后的复核；在此之前按先卖后买执行，不扩大未对冲外币敞口。

### 二、数据核验与样本区间

本次跨资产历史风险计算采用上交所交易日估值日，价格样本为 **{common_dates.min().strftime('%Y-%m-%d')} 至 {common_dates.max().strftime('%Y-%m-%d')}，{len(common_dates)} 个共同估值日**，对应 **{len(common_ret)} 个日收益观测**。终止原因是五个中债国债收益率序列共同只到 **2026-06-09**；分析截至日仍为 2026-09-15，9月15日的宏观监测仅在各序列实际可用范围内计算。

各序列核验结果如下。分段文件先按日期拼接、去重，再与上交所交易日日历比较；不把空值替换为 0。

{md_table(coverage_tbl)}

处理口径：沪深300、中证500分段文件各发现并剔除 2026-09-12 这一不在上交所交易日历中的异常记录；创业板没有该条记录。三只权益指数首行 `pre_close` 的空值仅为结构性字段空值，不进入收益计算。5年期 LPR 在 2018-01-02 至 2019-08-16 为制度性缺失，只在月度规则需要时使用实际非空值，未前向填充。PMI 2026-08-01 缺失、PPI截至2026-08、社融存量截至2026-04均保留为实际覆盖缺口。所有跨市场价格先重建到上交所估值日，再以前一有效观测前向填充；序列首个观测前及结构性空值不填充。SPX人民币收益按 `(1+SPX美元收益)×(1+USD/CNH收益)-1` 复合计算，美元现金收益按汇率变动，国债收益按关键期限久期贡献折算。

![图1 数据覆盖与缺口](FIN3-WKN-149_charts/FIN3-WKN-149_chart01_数据覆盖与缺口.png)

图1说明：蓝色区间为各序列文件实际覆盖，红线为分析截至日，旁注列出交易日缺口和字段空值；国债与社融的滞后是当前判断的主要数据限制。

### 三、当前组合风险画像

当前持仓如下：

{md_table(pos_tbl)}

共同样本下各资产日收益统计如下。国债列为久期折算收益，SPX列为人民币计收益。

{md_table(stat_tbl)}

共同样本相关矩阵：

{md_table(corr.round(3).reset_index().rename(columns={'index':'资产'}))}

当前组合风险指标如下；VaR/ES为历史分位数法，10日指标由连续 10 个交易日日收益复合形成，日内组合按当前权重每日再平衡。

{md_table(risk_tbl[risk_tbl['方案']=='当前组合'])}

当前组合 10 日最大累计损失为 **{fmt_pct(risk['当前组合']['max10_loss'])}**，区间为 **{risk['当前组合']['max10_start'].strftime('%Y-%m-%d')} 至 {risk['当前组合']['max10_end'].strftime('%Y-%m-%d')}**；最大回撤为 **{fmt_pct(risk['当前组合']['mdd'])}**，峰值日 **{risk['当前组合']['mdd_peak'].strftime('%Y-%m-%d')}**，谷值日 **{risk['当前组合']['mdd_end'].strftime('%Y-%m-%d')}**，修复日 **{risk['当前组合']['mdd_recovery'].strftime('%Y-%m-%d') if pd.notna(risk['当前组合']['mdd_recovery']) else '截至样本末未修复'}**；最差单日损失为 **{fmt_pct(risk['当前组合']['worst_day_loss'])}**（{risk['当前组合']['worst_day'].strftime('%Y-%m-%d')}）。按波动率 Euler 分解的当前组合资产风险贡献占比为：

{md_table(rc_tbl)}

### 四、情景识别与历史校准

月度规则按 `rules_scenarios.csv` 原文执行，权益下跌使用当前境内权益三指数按当前权重归一化的月度收益；月均收益率和宏观月度指标不以空值替代。全部合格月份、窗口数量如下：

{md_table(qmonth_df)}

窗口从合格月份次月第一个上交所交易日开始，长度 10 个上交所交易日，严格规则要求窗口内当前组合日收益全部为负并按累计复合跌幅从低到高选取最多20个。实际核验显示四个情景的严格全负窗口数均为0；这是规则与本次样本的结构性冲突，不能把非全负窗口冒充合格窗口。为完成数值敏感性分析，正文中的“历史校准”明确标为回退校准：从同一合格月份的次月10日窗口中选累计跌幅最差的可构造窗口（S1/S3最多20个，S2/S4分别9/7个），不复制、不补零，并将该回退结果与委员会沿用冲击分开列示。正式决议应以委员会沿用冲击为硬约束，待风险委员会确认窗口规则后再替换回退校准。

历史窗口校准冲击（10日累计中位数）如下。收益为百分比，曲线变动为 bp；委员会文件中的 `cgb_shock_bp` 按字段声明解释为 bp。

{md_table(cal_df)}

委员会沿用冲击采用共同参数，对所有方案使用相同风险因子冲击；历史校准的权益、SPX和汇率是窗口实际复合变动中位数，国债是收益率累计变动中位数，因此两者在幅度和期限曲线形态上均可能不同。图3-c 用绝对值比率展示沿用冲击相对校准冲击的严格程度，超过1表示沿用冲击更严格。

![图3 情景识别与校准](FIN3-WKN-149_charts/FIN3-WKN-149_chart03_情景识别与校准.png)

图3说明：图3-a 展示逐月合格标记，图3-b 展示八个风险因子校准中位数，图3-c 展示委员会冲击相对历史校准的严格程度。

### 五、压力测试结果

压力损失使用负的组合损益表示为正数。境内权益贡献为三项境内指数权重乘统一冲击；SPX人民币计贡献严格采用美元指数冲击与汇率冲击的复合收益；美元现金贡献为汇率冲击；国债贡献为各期限久期贡献乘收益率冲击的负值。四项贡献之和等于组合损益。

完整的 4 方案 × 4 情景 × 2 套冲击结果如下：

{md_table(stress_display)}

各方案最大压力损失及来源情景：

{md_table(stress_df.groupby('方案',as_index=False).agg(最大压力损失=('压力损失','max')).assign(**{'最大压力损失':lambda x:x['最大压力损失'].map(fmt_pct)}))}

沿用冲击和历史校准冲击的严格程度由各因子的绝对值比率共同决定，不能只比较境内权益一个因子；SPX人民币计必须同时考虑美元下跌和人民币汇率变化，国债则由期限久期结构决定，故同一情景可能出现权益严格但债券对冲较强，或曲线局部反转而非平行平移的情况。

![图2 历史风险总览](FIN3-WKN-149_charts/FIN3-WKN-149_chart02_历史风险总览.png)

图2说明：图2-a 为各方案共同历史样本累计净值，图2-b 对比年化波动率、1日ES99、10日VaR99和最大回撤，并标示 ES99 与 10日VaR99 限额线。

### 六、候选方案评估与九项约束检查

逐条检查结果如下。L9仅对推荐方案适用，三个候选方案该项标记为不适用；L5严格将美元现金与未对冲SPX QDII相加，未漏计 QDII。

{md_table(checks_display)}

方案C的外币敞口为 **{fmt_pct(plan_weights['方案C'][4]+plan_weights['方案C'][5])}**，超过L5上限25.00%的超限幅度为 **{fmt_pct(plan_weights['方案C'][4]+plan_weights['方案C'][5]-0.25)}**。推荐方案的外币敞口仍为 **{fmt_pct(weights_recommended[4]+weights_recommended[5])}**，没有通过增加人民币现金而误把未对冲QDII排除在外。

### 七、推荐方案与调仓执行

推荐方案完整权重为：沪深300 **{fmt_pct(weights_recommended[0])}**、中证500 **{fmt_pct(weights_recommended[1])}**、创业板 **{fmt_pct(weights_recommended[2])}**、中长期国债 **{fmt_pct(weights_recommended[3])}**、美元现金 **{fmt_pct(weights_recommended[4])}**、标普500 QDII **{fmt_pct(weights_recommended[5])}**、人民币现金及货币基金 **{fmt_pct(weights_recommended[6])}**。构造依据是保持两项外币资产各10%不变，境内权益按当前权重同比例乘以0.59，释放20.50个百分点，其中10.50个百分点进入国债、10.00个百分点进入人民币现金，满足人民币现金上限和国债下限，并使单向换手率为 **{fmt_pct(turnover)}**。

在同样保持外币权重、境内权益同比例缩减和 20.50% 单向换手率的可行集合中，人民币现金最多只能增加至20.00%，因此至少有10.50个百分点必须进入国债；推荐方案正好达到该边界。以同换手率、国债再增加0.50个百分点且人民币现金减少0.50个百分点的下一可行候选比较，其最大压力损失为 **{fmt_pct(alt_max)}**，推荐方案为 **{fmt_pct(qmax)}**；该候选虽在四舍五入到两位后同为5.56%，但未四舍五入的压力损失为 {alt_max*100:.4f}%、推荐方案为 {qmax*100:.4f}%。推荐方案的唯一性来自规则明确的优先级：在全部约束通过、外币权重不变、境内权益同比例缩减和相同换手率下，人民币现金取允许上限20.00%，国债取剩余权重；其他同换手率组合必须增加国债并减少现金，属于不同的构造目标。

交易清单：

{md_table(trade_tbl)}

执行顺序严格为先卖后买：先卖出沪深300 1,025.00、中证500 615.00、创业板410.00，卖出资金当日可用；再买入中长期国债1,050.00，并将1,000.00保留/转入人民币现金及货币基金。美元现金和标普500 QDII不交易，避免 QDII T+7 结算影响。

先卖后买现金路径为 **{sell_first[0]:.2f}% → {sell_first[1]:.2f}% → {sell_first[2]:.2f}%**，全程不低于{float(limit_map['L3']['lower'])*100:.2f}%；若反向先买后卖，路径为 **{buy_first[0]:.2f}% → {buy_first[1]:.2f}% → {buy_first[2]:.2f}%**，先买入国债即击穿现金下限，因此不得采用。

![图4 方案决策与执行](FIN3-WKN-149_charts/FIN3-WKN-149_chart04_方案决策与执行.png)

图4说明：图4-a 同时标示8%压力损失上限和7%推荐缓冲线，图4-b 对比两种执行顺序的现金路径，图4-c 给出四个委员会情景的马氏距离。

### 八、反向压力测试与监测预警

推荐方案最大压力损失 **{fmt_pct(qmax)}**，相对7.00%推荐上限的裕度为 **{fmt_pct(0.07-qmax)}**；相对当前组合最大压力损失 **{fmt_pct(current_max)}** 的放大倍数为 **{current_max/qmax:.2f} 倍**（若以损失绝对值比较）。推荐方案样本内最差10日累计损失为 **{fmt_pct(q10)}**，区间为 **{risk['推荐方案']['max10_start'].strftime('%Y-%m-%d')} 至 {risk['推荐方案']['max10_end'].strftime('%Y-%m-%d')}**。

反向压力测试将八维风险因子向量设为 `[境内权益、SPX美元、USD/CNH、1Y、2Y、5Y、10Y、30Y]`，以所有可得全负历史窗口的中位数及协方差计算马氏距离，并以推荐方案 L6/L7/L8/L9（1日ES99≤3.50%、10日VaR99≤6.00%、最大压力损失≤8.00%、推荐方案≤7.00%）为约束。委员会沿用冲击到历史向量分布的马氏距离为：S1 **{md_committee['S1']:.2f}**、S2 **{md_committee['S2']:.2f}**、S3 **{md_committee['S3']:.2f}**、S4 **{md_committee['S4']:.2f}**；历史校准中位数的距离为：S1 **{md_calibration['S1']:.2f}**、S2 **{md_calibration['S2']:.2f}**、S3 **{md_calibration['S3']:.2f}**、S4 **{md_calibration['S4']:.2f}**。四个沿用冲击中距离最小、因而在样本分布下最可能的情景为 **{reverse_sid}**，其因子变动为：境内权益 **{fmt_pct(committee[reverse_sid]['cn_eq'])}**、SPX美元 **{fmt_pct(committee[reverse_sid]['spx_usd'])}**、USD/CNH **{fmt_pct(committee[reverse_sid]['fx'])}**、1Y/2Y/5Y/10Y/30Y 分别 **{', '.join(fmt_bp(x) for x in committee[reverse_sid]['cgb_bp'])}**。

监测指标如下；“数据滞后”表示截至日早于2026-09-15的最新有效值，不能当作实时未触发结论：

{md_table(monitor_display)}

![图5 监测指标触发状态](FIN3-WKN-149_charts/FIN3-WKN-149_chart05_监测指标触发状态.png)

图5说明：每个子图为实际最新值与该指标阈值，状态同时标示是否触发及数据是否滞后。

补齐中债五期限收益率至2026-09-15、社融存量至最新月度后，应重新计算共同样本终止日、国债收益、历史窗口校准、压力测试、L6-L9和 M4/M8；若任一硬限额转为未通过，应暂停未执行部分并提请临时风险会议。

---

**附件清单**
- `FIN3-WKN-149_charts/FIN3-WKN-149_chart01_数据覆盖与缺口.png`
- `FIN3-WKN-149_charts/FIN3-WKN-149_chart02_历史风险总览.png`
- `FIN3-WKN-149_charts/FIN3-WKN-149_chart03_情景识别与校准.png`
- `FIN3-WKN-149_charts/FIN3-WKN-149_chart04_方案决策与执行.png`
- `FIN3-WKN-149_charts/FIN3-WKN-149_chart05_监测指标触发状态.png`
- `FIN3-WKN-149_reproduce.py`
'''
(OUT/'FIN3-WKN-149_风险委员会决策备忘录.md').write_text(memo, encoding='utf-8')

# Console summary for reproducibility audit.
print('generated', OUT/'FIN3-WKN-149_风险委员会决策备忘录.md')
print('common sample', common_dates.min().date(), common_dates.max().date(), len(common_dates))
print('recommended max pressure', qmax, 'ES99', qrisk['es99_1d'], 'VaR10', qrisk['var99_10d'], 'turnover', turnover)
print('reverse scenario', reverse_sid, md_committee)
print('charts', sorted(p.name for p in CHART.glob('*.png')))
