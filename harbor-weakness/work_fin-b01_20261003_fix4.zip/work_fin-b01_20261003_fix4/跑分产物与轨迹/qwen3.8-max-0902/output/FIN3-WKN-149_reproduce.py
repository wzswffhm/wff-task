#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FIN3-WKN-149 多资产稳健配置专户 三季度宏观压力测试与调仓建议 —— 可复算代码
=============================================================================
运行方式:  python3 FIN3-WKN-149_reproduce.py
输入:      /app/input_files/  (只读, 原始快照)
输出:      stdout 全部计算结果表格 (对应备忘录八个章节的全部数字)
           /app/output/FIN3-WKN-149_charts/ 下 5 张 PNG 复合图

方法论口径 (全部为方法设定, 不含任何结论数值; 结论均由本脚本从原始快照计算):
  M0  分析截至日 = 2026-09-15 (数据快照 wind_snapshot_20260915 的截止日)。
  M1  估值日历 = 上交所交易日历 (snapshot_trade_calendar.csv, is_trading_day=1)。
      所有跨市场序列先对齐到上交所估值日; 境外市场休市造成的缺失按前向填充;
      结构性空值 (序列起点之前 / 上游截断之后 / 上游缺月) 一律不填充、不参与计算,
      空值绝不按 0 处理。
  M2  行情文件中不在上交所交易日历内的记录 (如 2026-09-12 周六的沪深300/中证500
      "休市日异常记录") 在数据核验阶段识别并剔除, 依据: (i) 日期不在交易日历;
      (ii) open=high=low=close=pre_close (零振幅); (iii) 成交额仅为近20日均值的
      约 1%~3%。中债/Shibor/DR007/LPR 等银行间序列在调休上班日的发布记录属于
      正常跨市场日历差异, 对齐时自然落选, 不视为异常。
  M3  国债组合收益按关键期限久期折算: r_cgb = -Σ_k duration_contribution_k × Δy_k
      (Δy 为小数)。标普500 人民币计收益按复合折算: (1+r_SPX,USD)×(1+r_USDCNH)-1。
  M4  组合日收益按方案权重每日再平衡: r_p,t = Σ_i w_i × r_i,t (权重恒定)。
  M5  params_committee_shocks.csv 的 cgb_shock_bp 字段数值按"百分数"解读
      (+0.20 即 +20bp)。若按字面 bp 解读, 冲击量级 <1bp, 与历史校准窗口
      (10 个交易日累计变动中位数, 通常为若干至数十 bp) 相差 2~3 个数量级,
      无经济意义且无法进行严格程度对比。备忘录第二章、第五章对此有显式说明。
  M6  年化因子 = 244 (上交所年均交易日)。1 日 ES99 = 历史模拟法, 收益 ≤ 1%
      分位的条件均值取负; 10 日 VaR99 = 滚动 (重叠) 10 交易日累计收益的 1% 分位
      取负。L6/L7 的"历史窗口" = 全部共同覆盖样本 (2018-01-03 ~ 2026-06-09,
      受中债收益率截断限制)。
  M7  情景识别中"权益指数当月下跌"以沪深300当月收益率 < 0 判定; 标普500当月
      收益率、USD/CNH 当月变化按各自市场日历的月末环比计算; 月度指标以自然月
      聚合。当月 (2026-09, 不完整月) 不参与情景识别。识别所需任一输入为结构性
      缺失时, 该情景-月份标记为"无法识别(数据缺口)", 不按"不合格"处理。
  M8  历史窗口: 合格月份次月第一个上交所交易日起 10 个交易日; 窗口 10 日的因子
      数据必须完整 (受中债截断限制, 合格月份最晚为 2026-03)。样本中不存在
      "10 日组合日收益全部为负"的窗口 (rules_windows.csv 的严格条件), 故按规则
      "同类窗口按累计跌幅排序取前若干(不少于 20 个)"执行: 按当前组合 10 日累计
      跌幅升序排序, 每情景取前 20 个窗口; 候选不足 20 个的情景取全部候选。
      校准冲击 = 选入窗口内各风险因子 10 个交易日累计变动的中位数。
  M9  现金腿: 人民币现金及货基日收益按 0 计 (快照未提供货基收益率序列);
      美元现金及存款的人民币计收益 = USD/CNH 日变动率 (不承担利率风险)。
  M10 反向压力测试: 风险因子向量 x = [沪深300, 中证500, 创业板, 标普500(USD),
      USD/CNH 的 10 日累计收益, 中债 1/2/5/10/30Y 的 10 日累计变动(bp)]。
      μ、Σ 取自共同覆盖样本上全部滚动 10 日窗口。在损失约束 (推荐方案损失达到
      L9 缓冲线 7%) 下最小化马氏距离: 拉格朗日解方向 v = Σb (b 为线性敏感度),
      沿 -v 用二分法求解精确复合损失 = 目标值的步长 s, 距离 = sqrt((x*-μ)'Σ⁺(x*-μ)),
      Σ⁺ 为伪逆 (收益率因子高度共线)。
  M11 金额单位万元 (两位小数); 百分比两位小数; 收益率变动注明 bp 或 %。
"""

import os
import re
import sys
import numpy as np
import pandas as pd

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
from matplotlib.colors import ListedColormap

plt.rcParams["font.sans-serif"] = ["Noto Sans CJK SC", "Noto Sans CJK JP", "DejaVu Sans"]
plt.rcParams["axes.unicode_minus"] = False

IN_DIR = os.environ.get("FIN3_INPUT", "/app/input_files")
OUT_DIR = os.environ.get("FIN3_OUTPUT", "/app/output")
CHART_DIR = os.path.join(OUT_DIR, "FIN3-WKN-149_charts")
os.makedirs(CHART_DIR, exist_ok=True)

AS_OF = pd.Timestamp("2026-09-15")          # 分析截至日 (M0)
ANN = 244                                   # 年化因子 (M6)
NAV_TOTAL = 10000.0                         # 组合净值 (万元), 来自 params_positions
TENORS = ["1y", "2y", "5y", "10y", "30y"]
TENOR_CN = {"1y": "1Y", "2y": "2Y", "5y": "5Y", "10y": "10Y", "30y": "30Y"}
TENOR_LABEL = {"1年": "1y", "2年": "2y", "5年": "5y", "10年": "10y", "30年": "30y"}

PLAN_COLORS = {"当前组合": "#7f7f7f", "方案A": "#1f77b4", "方案B": "#ff7f0e",
               "方案C": "#2ca02c", "推荐方案": "#d62728"}


def hdr(t):
    print("\n" + "=" * 100)
    print(t)
    print("=" * 100)


def sub(t):
    print("\n--- " + t + " " + "-" * max(0, 90 - len(t)))


# =============================================================================
# S0. 参数与规则文件读入
# =============================================================================
hdr("[S0] 参数、方案与规则文件读入")

holdings = pd.read_csv(os.path.join(IN_DIR, "params_holdings.csv"))
positions = pd.read_csv(os.path.join(IN_DIR, "params_positions.csv"))
limits = pd.read_csv(os.path.join(IN_DIR, "params_limits.csv")).set_index("id")
duration = pd.read_csv(os.path.join(IN_DIR, "params_duration.csv"))
committee = pd.read_csv(os.path.join(IN_DIR, "params_committee_shocks.csv"))
plans_df = pd.read_csv(os.path.join(IN_DIR, "plans_candidates.csv"))
rules_scen = pd.read_csv(os.path.join(IN_DIR, "rules_scenarios.csv"))
rules_win = pd.read_csv(os.path.join(IN_DIR, "rules_windows.csv")).set_index("key")["value"]
rules_checks = pd.read_csv(os.path.join(IN_DIR, "rules_checks.csv"))
rules_reb = pd.read_csv(os.path.join(IN_DIR, "rules_rebalance.csv")).set_index("key")["value"]

# 久期贡献 (关键期限久期折算, M3)
dur_map = {TENOR_LABEL[r.tenor]: float(r.duration_contribution)
           for r in duration.itertuples()}
DUR_TOTAL = sum(dur_map.values())
print("关键期限久期贡献:", {TENOR_CN[k]: v for k, v in dur_map.items()},
      " 合计久期 =", round(DUR_TOTAL, 2))

# 限额 (从 params_limits.csv 解析, 不硬编码)
LIM = {}
for lid, row in limits.iterrows():
    LIM[lid] = dict(op=row["op"],
                    lower=np.nan if pd.isna(row["lower"]) else float(row["lower"]),
                    upper=np.nan if pd.isna(row["upper"]) else float(row["upper"]),
                    note=row["note"])
def lim_thr(lid):
    """按 op 语义取有效阈值列: params_limits.csv 中部分行 (如 L4 '>=' 型下限)
    阈值记录于 upper 列而 lower 列为空, 解析时取非空的一列, 不硬编码数值。"""
    lo, up = LIM[lid]["lower"], LIM[lid]["upper"]
    return lo if not pd.isna(lo) else up


L6_ES99 = LIM["L6"]["upper"]        # 1日 ES99 上限
L7_VA10 = LIM["L7"]["upper"]        # 10日 VaR99 上限
L8_MAX = LIM["L8"]["upper"]         # 最大压力损失上限
L9_BUF = LIM["L9"]["upper"]         # 推荐方案缓冲线
L4_MIN = lim_thr("L4")              # 国债组合下限 (CSV 中记录于 upper 列)
C1_TOL = 0.0005                     # C1 权重合计容差 0.05pp (rules_checks.csv)
CASH_FLOOR = float(re.search(r"(\d+(?:\.\d+)?)%", rules_reb["cash_floor"]).group(1)) / 100
WIN_LEN = int(re.search(r"(\d+)", rules_win["window_length"]).group(1))      # 10
WIN_MIN_N = int(re.search(r"不少于\s*(\d+)", rules_win["window_rule"]).group(1))  # 20
print(f"限额: L4(国债下限)>={L4_MIN:.2f}  L6(1日ES99)<={L6_ES99:.3f}  "
      f"L7(10日VaR99)<={L7_VA10:.3f}  L8(最大压力损失)<={L8_MAX:.3f}  "
      f"L9(推荐方案缓冲)<={L9_BUF:.3f}")
print("注: L4 为 '>=' 型下限, 其阈值在 params_limits.csv 中记录于 upper 列 (lower 列为空), "
      "解析时按 op 语义取非空阈值列。")
print(f"现金下限 = {CASH_FLOOR:.2%}   窗口长度 = {WIN_LEN} 个交易日   校准窗口目标数 >= {WIN_MIN_N}")

# 方案权重 (当前 / A / B / C / 推荐)
ASSET_ORDER = ["EQ_000300", "EQ_000905", "EQ_399006", "CGB", "USD_CASH", "SPX", "CNY_CASH"]
PLANS = {}
w_cur = holdings.set_index("asset_class")["weight_current"]
w_rec = holdings.set_index("asset_class")["weight_recommended"]
PLANS["当前组合"] = {a: float(w_cur[a]) for a in ASSET_ORDER}
for r in plans_df.itertuples():
    PLANS[r.plan_id] = {"EQ_000300": r.w_000300, "EQ_000905": r.w_000905,
                        "EQ_399006": r.w_399006, "CGB": r.w_cgb,
                        "USD_CASH": r.w_usd_cash, "SPX": r.w_spx_qdii,
                        "CNY_CASH": r.w_cny_cash}
PLANS["推荐方案"] = {a: float(w_rec[a]) for a in ASSET_ORDER}
PLAN_NAMES = ["当前组合", "方案A", "方案B", "方案C", "推荐方案"]
print("\n方案权重:")
print(pd.DataFrame(PLANS).T[ASSET_ORDER].round(4).to_string())

# =============================================================================
# S1. 数据核验 (先于一切计算)
# =============================================================================
hdr("[S1] 数据核验: 覆盖区间、记录数、休市日异常记录、结构性空值")

calendar = pd.read_csv(os.path.join(IN_DIR, "snapshot_trade_calendar.csv"),
                       parse_dates=["date"])
TD = pd.DatetimeIndex(calendar.loc[calendar.is_trading_day == 1, "date"].sort_values())
TD_SET = set(TD)
print(f"上交所交易日历: {TD.min().date()} ~ {TD.max().date()}, 共 {len(TD)} 个交易日")
print(f"日历内周末记录数 = {sum(d.dayofweek >= 5 for d in TD)} (应为 0), "
      f"重复日期数 = {calendar.date.duplicated().sum()}")

manifest = pd.read_csv(os.path.join(IN_DIR, "snapshot_data_manifest.csv"))


def read_seg(prefix, value_col=None):
    """读取分段快照 (seg1+seg2), 返回 (原始表, 表内日期是否在上交所日历)。"""
    frames = []
    for seg in ["seg1", "seg2"]:
        p = os.path.join(IN_DIR, f"snapshot_{prefix}_{seg}.csv")
        if os.path.exists(p):
            frames.append(pd.read_csv(p, parse_dates=["date"]))
    df = pd.concat(frames, ignore_index=True)
    if value_col:
        df = df[["date", value_col]]
    return df


validation_rows = []      # 数据核验汇总表
excluded_rows = []        # 被剔除的异常记录


def validate_series(name, df, value_cols, kind, structural_note=""):
    """通用核验: 记录数/起止/日历外记录/重复/空值/内部缺口。"""
    df = df.sort_values("date").reset_index(drop=True)
    n = len(df)
    dup = int(df.date.duplicated().sum())
    off = df.loc[~df.date.isin(TD_SET), "date"]
    nan_cnt = {c: int(df[c].isna().sum()) for c in value_cols if df[c].isna().any()}
    row = dict(series=name, kind=kind, records=n,
               start=str(df.date.min().date()), end=str(df.date.max().date()),
               dup=dup, off_calendar=len(off), off_dates="",
               nan=nan_cnt if nan_cnt else "", note=structural_note)
    # 内部缺口: 覆盖区间内上交所交易日缺失数 (仅对日频、以上交所日历为准的序列)
    if kind == "日频" and n > 50:
        span = TD[(TD >= df.date.min()) & (TD <= df.date.max())]
        miss = sorted(set(span) - set(df.date.loc[df.date.isin(TD_SET)]))
        row["miss_sse"] = len(miss)
    else:
        row["miss_sse"] = "-"
    if len(off) and len(off) <= 3:
        row["off_dates"] = ",".join(str(d.date()) for d in off)
    validation_rows.append(row)
    return df, off


# --- 权益指数 (含休市日异常记录识别, M2) ---
equity_close = {}
for prefix, cname in [("000300SH", "沪深300"), ("000905SH", "中证500"),
                      ("399006SZ", "创业板指")]:
    raw = read_seg(prefix)
    raw, off = validate_series(cname, raw, ["close"], "日频",
                               "seg1+seg2 拼接, 无重叠")
    # 休市日异常记录: 日期不在上交所日历
    bad = raw.loc[~raw.date.isin(TD_SET)]
    for r in bad.itertuples():
        recent = raw.loc[(raw.date < r.date) & raw.date.isin(TD_SET), "amount"].tail(20)
        ratio = r.amount / recent.mean()
        zero_range = (r.open == r.high == r.low == r.close == r.pre_close)
        excluded_rows.append(dict(
            file=f"snapshot_{prefix}_seg2.csv", date=str(r.date.date()),
            weekday=r.date.day_name(), close=r.close, amount=r.amount,
            amount_ratio=round(float(ratio), 4), zero_range=bool(zero_range),
            reason="日期为周六且不在上交所交易日历; O=H=L=C=pre_close 零振幅; "
                   f"成交额仅为近20个交易日均值的 {ratio:.2%}"))
    keep = raw.loc[raw.date.isin(TD_SET)].set_index("date")
    equity_close[cname] = keep["close"].sort_index()

# --- 中债国债收益率 (结构性截断: 上游止于 2026-06-09, 不填充) ---
yields_raw = {}
for t in TENORS:
    df = pd.read_csv(os.path.join(IN_DIR, f"snapshot_cgb_yield_{t}.csv"),
                     parse_dates=["date"])
    df, _ = validate_series(f"中债国债{TENOR_CN[t]}", df, ["yield_pct"], "日频",
                            "含银行间调休日记录; 上游截断于 2026-06-09(结构性, 不填充)")
    yields_raw[t] = df.set_index("date")["yield_pct"].sort_index()

# --- USD/CNH ---
fx_raw = read_seg("usdcnh", "usdcnh")
fx_raw, _ = validate_series("USD/CNH", fx_raw, ["usdcnh"], "日频",
                            "seg1+seg2 拼接; 离岸日历, 含非上交所交易日")
fx_raw = fx_raw.set_index("date")["usdcnh"].sort_index()

# --- 标普500 ---
spx_raw = pd.read_csv(os.path.join(IN_DIR, "snapshot_spx.csv"), parse_dates=["date"])
spx_raw, _ = validate_series("标普500", spx_raw, ["close"], "日频", "美国日历")
spx_raw = spx_raw.set_index("date")["close"].sort_index()

# --- Shibor / DR007 ---
shibor_raw = read_seg("shibor")
shibor_raw, _ = validate_series("Shibor", shibor_raw, ["shibor_on", "shibor_1w"],
                                "日频", "seg1+seg2 拼接; 含调休上班日记录; 未参与计算(背景指标)")
dr_raw = pd.read_csv(os.path.join(IN_DIR, "snapshot_dr007.csv"), parse_dates=["date"])
dr_raw, _ = validate_series("DR007", dr_raw, ["dr007"], "日频", "含调休上班日记录")
dr_raw = dr_raw.set_index("date")["dr007"].sort_index()

# --- LPR ---
lpr1_raw = pd.read_csv(os.path.join(IN_DIR, "snapshot_lpr_1y.csv"), parse_dates=["date"])
lpr1_raw, _ = validate_series("LPR_1Y", lpr1_raw, ["lpr_1y"], "发布日频",
                              "上游截断于 2026-07-20(结构性)")
lpr1 = lpr1_raw.set_index("date")["lpr_1y"].sort_index()
lpr5_raw = pd.read_csv(os.path.join(IN_DIR, "snapshot_lpr_5y.csv"), parse_dates=["date"])
lpr5_raw, _ = validate_series("LPR_5Y", lpr5_raw, ["lpr_5y"], "发布日频",
                              "2019-08-20 前为结构性空值(该期限未发布), 不填充; "
                              "上游截断于 2026-08-20")
lpr5 = lpr5_raw.set_index("date")["lpr_5y"].sort_index()

# --- 月度宏观 ---
pmi_raw = pd.read_csv(os.path.join(IN_DIR, "snapshot_pmi_manufacturing.csv"),
                      parse_dates=["date"])
pmi_raw, _ = validate_series("制造业PMI", pmi_raw, ["pmi_mfg"], "月频",
                             "2026-08 缺月(结构性空值, 不插补)")
pmi = pmi_raw.set_index("date")["pmi_mfg"].sort_index()
afre_raw = pd.read_csv(os.path.join(IN_DIR, "snapshot_afre_stock.csv"),
                       parse_dates=["date"])
afre_raw, _ = validate_series("社融存量", afre_raw, ["afre_stock"], "月频",
                              "上游截断于 2026-04(结构性)")
afre = afre_raw.set_index("date")["afre_stock"].sort_index()
ppi_raw = pd.read_csv(os.path.join(IN_DIR, "snapshot_ppi_yoy.csv"), parse_dates=["date"])
ppi_raw, _ = validate_series("PPI同比", ppi_raw, ["ppi_yoy"], "月频", "止于 2026-08")
ppi = ppi_raw.set_index("date")["ppi_yoy"].sort_index()

# --- 美债 ---
ust10_raw = pd.read_csv(os.path.join(IN_DIR, "snapshot_ust_10y.csv"), parse_dates=["date"])
ust10_raw, _ = validate_series("美债10Y", ust10_raw, ["yield_pct"], "日频", "美国日历")
ust10 = ust10_raw.set_index("date")["yield_pct"].sort_index()
ust2_raw = pd.read_csv(os.path.join(IN_DIR, "snapshot_ust_m2.csv"), parse_dates=["date"])
ust2_raw, _ = validate_series("美债2Y", ust2_raw, ["yield_pct"], "日频",
                              "2018-10-16 起(此前为结构性空值)")
ust4_raw = pd.read_csv(os.path.join(IN_DIR, "snapshot_ust_m4.csv"), parse_dates=["date"])
ust4_raw, _ = validate_series("美债4Y", ust4_raw, ["yield_pct"], "日频",
                              "严重截断: 仅 2026-09-08~09-15 共 6 条, 无法用于计算, 仅核验")

V = pd.DataFrame(validation_rows)
sub("数据核验汇总表 (以文件实际内容为准; manifest 的 possible_truncation 字段未采信)")
print(V.to_string(index=False))

sub("manifest 记录数 vs 实际记录数核对")
for r in manifest.itertuples():
    p = os.path.join(IN_DIR, r.file)
    actual = len(pd.read_csv(p, parse_dates=["date"]))
    flag = "OK" if actual == r.records else f"不一致(manifest={r.records}, 实际={actual})"
    if actual != r.records:
        print(f"  {r.file}: {flag}")
print("  (未打印的文件 manifest 记录数与实际一致)")

sub("被剔除的休市日异常记录")
for e in excluded_rows:
    print(" ", e)

sub("覆盖区间结论")
cov_end_equity = min(equity_close[c].index.max() for c in equity_close)
cov_end_cgb = min(yields_raw[t].loc[yields_raw[t].index.isin(TD_SET)].index.max()
                  for t in TENORS)
n_days_full = len(TD)
n_days_common = int((TD <= cov_end_cgb).sum())
print(f"全样本(上交所日历): {TD.min().date()} ~ {TD.max().date()}, {n_days_full} 个交易日")
print(f"共同覆盖样本(组合收益可算): {TD.min().date()} ~ {cov_end_cgb.date()}, "
      f"{n_days_common} 个交易日 (受中债收益率截断限制)")
print(f"中债缺口: {cov_end_cgb.date()} 之后至分析截至日缺 "
      f"{n_days_full - n_days_common} 个交易日 (结构性, 不填充)")

# chart01 用数据
chart01_series = V.copy()

# =============================================================================
# S2. 对齐与收益构造
# =============================================================================
hdr("[S2] 价格对齐 (上交所估值日) 与收益构造")

# 权益: 剔除日历外记录后即为上交所日频
px = {c: equity_close[c] for c in ["沪深300", "中证500", "创业板指"]}
# 境外序列: reindex 到上交所日历后前向填充 (跨市场日历差异, M1)
spx_al = spx_raw.reindex(TD).ffill()
fx_al = fx_raw.reindex(TD).ffill()
ust10_al = ust10.reindex(TD).ffill()
# 中债: 仅取上交所日历内记录, 截断后为结构性 NaN, 不填充
yld_al = {t: yields_raw[t].reindex(TD) for t in TENORS}
dr_al = dr_raw.reindex(TD)

n_ffill_spx = int(spx_raw.reindex(TD).isna().sum())
n_ffill_fx = int(fx_raw.reindex(TD).isna().sum())
n_ffill_ust = int(ust10.reindex(TD).isna().sum())
print(f"前向填充的估值日数量(境外休市): 标普500 {n_ffill_spx} 天, USD/CNH {n_ffill_fx} 天, "
      f"美债10Y {n_ffill_ust} 天 (均为跨市场日历差异, 非结构性空值)")

R = pd.DataFrame(index=TD)
R["r300"] = px["沪深300"].pct_change()
R["r905"] = px["中证500"].pct_change()
R["r399"] = px["创业板指"].pct_change()
R["rspx"] = spx_al.pct_change()
R["rfx"] = fx_al.pct_change()
R["rspx_cny"] = (1 + R["rspx"]) * (1 + R["rfx"]) - 1          # 复合折算 (M3)
for t in TENORS:
    R["dy_" + t] = yld_al[t].diff()                            # 单位: 百分点
# 国债组合收益按关键期限久期折算 (M3): dy_* 为百分点 → /100 化为小数
R["rcgb"] = 0.0
for t in TENORS:
    R["rcgb"] = R["rcgb"] - dur_map[t] * R["dy_" + t] / 100.0

# 共同覆盖样本 (中债截断日之前), 首日无前收盘 → 丢弃首行
COMMON = TD[TD <= cov_end_cgb]
Rc = R.loc[COMMON].iloc[1:].dropna()
print(f"组合收益样本: {Rc.index.min().date()} ~ {Rc.index.max().date()}, {len(Rc)} 个日收益")
print("样本内 NaN 数量(逐列):", Rc.isna().sum().sum(), "(空值未按 0 参与计算, 直接确认无空值)")

LEGS = {"EQ_000300": "r300", "EQ_000905": "r905", "EQ_399006": "r399",
        "CGB": "rcgb", "USD_CASH": "rfx", "SPX": "rspx_cny"}
LEG_CN = {"EQ_000300": "沪深300指数基金", "EQ_000905": "中证500指数基金",
          "EQ_399006": "创业板指数基金", "CGB": "中长期国债组合",
          "USD_CASH": "美元现金及存款(FX腿)", "SPX": "标普500QDII(人民币计)",
          "CNY_CASH": "人民币现金及货基"}


def port_ret(w, frame=Rc):
    r = pd.Series(0.0, index=frame.index)
    for a, col in LEGS.items():
        r = r + w[a] * frame[col]
    return r  # CNY_CASH 收益按 0 (M9)


# =============================================================================
# S3. 历史风险指标 (第三章)
# =============================================================================
hdr("[S3] 当前组合风险画像与各方案历史风险指标")


def hist_metrics(w):
    r = port_ret(w)
    nav = (1 + r).cumprod()
    n = len(r)
    out = {}
    out["n_days"] = n
    out["ann_ret"] = float(nav.iloc[-1] ** (ANN / n) - 1)
    out["ann_vol"] = float(r.std(ddof=1) * np.sqrt(ANN))
    q95, q99 = r.quantile(0.05), r.quantile(0.01)
    out["var95_1d"] = float(-q95)
    out["var99_1d"] = float(-q99)
    out["es95_1d"] = float(-r[r <= q95].mean())
    out["es99_1d"] = float(-r[r <= q99].mean())
    roll10 = (nav / nav.shift(WIN_LEN) - 1).dropna()
    out["var99_10d"] = float(-roll10.quantile(0.01))
    i10 = roll10.idxmin()
    pos10 = list(nav.index).index(i10)
    out["worst10"] = float(roll10.min())
    out["worst10_start"] = str(nav.index[pos10 - WIN_LEN].date())
    out["worst10_end"] = str(i10.date())
    dd = nav / nav.cummax() - 1
    out["mdd"] = float(dd.min())
    trough = dd.idxmin()
    peak_nav = nav.cummax()[trough]
    peak = nav[nav >= peak_nav - 1e-12].index[0]
    after = nav.loc[trough:]
    rec = after[after >= peak_nav]
    out["mdd_peak"] = str(peak.date())
    out["mdd_trough"] = str(trough.date())
    out["mdd_recov"] = str(rec.index[0].date()) if len(rec) else "未修复(截至样本末)"
    iw = r.idxmin()
    out["worst_day"] = float(r.min())
    out["worst_day_date"] = str(iw.date())
    out["_r"] = r
    out["_nav"] = nav
    return out


METRICS = {nm: hist_metrics(PLANS[nm]) for nm in PLAN_NAMES}

sub("各方案历史风险指标 (共同覆盖样本, 每日再平衡)")
rows = []
for nm in PLAN_NAMES:
    m = METRICS[nm]
    rows.append(dict(方案=nm, 年化收益=m["ann_ret"], 年化波动=m["ann_vol"],
                     VaR95_1d=m["var95_1d"], VaR99_1d=m["var99_1d"],
                     ES95_1d=m["es95_1d"], ES99_1d=m["es99_1d"],
                     VaR99_10d=m["var99_10d"], 最大回撤=m["mdd"],
                     最差单日=m["worst_day"]))
M = pd.DataFrame(rows).set_index("方案")
print((M * 100).round(2).to_string(), "\n(单位: %)")
for nm in PLAN_NAMES:
    m = METRICS[nm]
    print(f"{nm}: 最差10日累计 {m['worst10']*100:.2f}% "
          f"({m['worst10_start']}~{m['worst10_end']}) | 最大回撤 {m['mdd']*100:.2f}% "
          f"(峰 {m['mdd_peak']} → 谷 {m['mdd_trough']} → 修复 {m['mdd_recov']}) | "
          f"最差单日 {m['worst_day']*100:.2f}% ({m['worst_day_date']})")

sub("各资产腿日收益统计 (共同覆盖样本)")
leg_cols = list(LEGS.values())
stats = pd.DataFrame({
    "年化收益_pct": Rc[leg_cols].mean() * ANN * 100,
    "年化波动_pct": Rc[leg_cols].std(ddof=1) * np.sqrt(ANN) * 100,
    "偏度": Rc[leg_cols].skew(),
    "超额峰度": Rc[leg_cols].kurt(),
    "最差单日_pct": Rc[leg_cols].min() * 100,
    "最好单日_pct": Rc[leg_cols].max() * 100,
})
stats.index = [LEG_CN[a] for a in LEGS]
print(stats.round(2).to_string(),
      "\n(收益/波动/极值单位: %, 偏度/峰度为倍数; 人民币现金日收益恒为0不参与)")

sub("资产腿相关矩阵 (人民币现金零波动, 不参与)")
corr = Rc[leg_cols].corr()
corr.index = [LEG_CN[a] for a in LEGS]
corr.columns = [LEG_CN[a] for a in LEGS]
print(corr.round(3).to_string())

sub("当前组合各资产风险贡献 (协方差分解)")
w_vec = np.array([PLANS["当前组合"][a] for a in LEGS])
cov = Rc[leg_cols].cov().values
port_var = w_vec @ cov @ w_vec
rc = w_vec * (cov @ w_vec) / port_var
RC = pd.DataFrame({"资产": [LEG_CN[a] for a in LEGS],
                   "权重": w_vec, "风险贡献占比": rc})
RC["风险贡献占比(含现金腿归一)"] = RC["风险贡献占比"] / RC["风险贡献占比"].sum()
print(RC.round(4).to_string(index=False))
print("人民币现金及货基: 权重 0.10, 日收益恒为 0, 风险贡献 0")

# =============================================================================
# S4. 情景识别与历史校准 (第四章)
# =============================================================================
hdr("[S4] 情景月度识别、历史窗口与校准冲击")

# ---- 月度指标 (M7) ----
m300_ret = px["沪深300"].resample("ME").last().pct_change()
mspx_ret = spx_raw.resample("ME").last().pct_change()
mfx_chg = fx_raw.resample("ME").last().pct_change()
my10 = yld_al["10y"].dropna().resample("ME").mean()
mdr = dr_al.dropna().resample("ME").mean()
mpmi = pmi.resample("ME").last()
mppi = ppi.resample("ME").last()
maf = afre.resample("ME").last()
afre_yoy = maf.pct_change(12) * 100

# 中债月度完整性: 当月每个上交所交易日都有记录才算完整月
sse_by_m = pd.Series(1, index=TD).groupby(TD.to_period("M")).size()
y10_sse = yld_al["10y"].dropna()
cgb_by_m = y10_sse.groupby(y10_sse.index.to_period("M")).size()
cgb_comp = (cgb_by_m / sse_by_m.reindex(cgb_by_m.index)).fillna(0)


def lpr_cut_months(s):
    s = s.dropna()
    return set(s[s.diff().fillna(0) < 0].index.to_period("M"))


CUT1, CUT5 = lpr_cut_months(lpr1), lpr_cut_months(lpr5)
LPR1_END = lpr1.index.max().to_period("M")
lpr5_nn = lpr5.dropna()
LPR5_START, LPR5_END = lpr5_nn.index.min().to_period("M"), lpr5_nn.index.max().to_period("M")
print("LPR 下调月份(1Y):", sorted(str(m) for m in CUT1))
print("LPR 下调月份(5Y):", sorted(str(m) for m in CUT5))
print(f"LPR_5Y 结构性空值区间: {lpr5.index.min().date()} ~ "
      f"{(lpr5_nn.index.min() - pd.Timedelta(days=1)).date()} (该期限尚未发布, 不填充)")

EVAL_MONTHS = pd.period_range("2018-02", "2026-08", freq="M")  # 2026-09 为不完整当月, 不参与


def getm(s, m, shift=0):
    ss = s.shift(shift) if shift else s
    return ss.get(m.to_timestamp("M"), np.nan)


def lpr_cut_status(m):
    """返回 (当月是否存在可确认的下调, 两期限下调状态是否均可观测)。"""
    obs1 = m <= LPR1_END                       # 1Y: 文件截断后不可观测
    obs5 = (m < LPR5_START) or (m <= LPR5_END)  # 5Y: 发布前无该期限, 不阻碍判定
    cut1 = (m in CUT1) if obs1 else False
    cut5 = (m in CUT5) if obs5 else False
    return (cut1 or cut5), (obs1 and obs5)


ident = {sc: {} for sc in ["S1", "S2", "S3", "S4"]}   # 2=合格 1=不合格 0=无法识别
detail_rows = []
for m in EVAL_MONTHS:
    p, gp = getm(mpmi, m), getm(mpmi, m, 1)
    ym, ymp = getm(my10, m), getm(my10, m, 1)
    cok = cgb_comp.get(m, 0) >= 0.9999
    cokp = cgb_comp.get(m - 1, 0) >= 0.9999
    e_m = getm(m300_ret, m)
    cut, cut_full_obs = lpr_cut_status(m)
    # S1 分支a: PMI<50 且 LPR 当月下调
    if pd.isna(p):
        a_val = None
    elif p >= 50:
        a_val = False                       # PMI 条件已不满足, 与 LPR 无关
    else:
        a_val = True if cut else (False if cut_full_obs else None)
    # S1 分支b: PMI 环比下行>=0.5 且 10Y 月均低于上月
    b_eval = (not pd.isna(p)) and (not pd.isna(gp)) and cok and cokp \
        and (not pd.isna(ym)) and (not pd.isna(ymp))
    b_val = (bool(p <= gp - 0.5) and bool(ym < ymp)) if b_eval else None
    if a_val is True or b_val is True:
        ident["S1"][m] = 2
    elif a_val is False and b_val is False:
        ident["S1"][m] = 1
    else:
        ident["S1"][m] = 0

    pv, pgp = getm(mppi, m), getm(mppi, m, 1)
    s2_ok = (not pd.isna(pv)) and (not pd.isna(pgp)) and cok and cokp \
        and (not pd.isna(ym)) and (not pd.isna(ymp)) and (not pd.isna(e_m))
    if s2_ok:
        ident["S2"][m] = 2 if (pv > pgp and ym > ymp and e_m < 0) else 1
    else:
        ident["S2"][m] = 0

    sp, fxm = getm(mspx_ret, m), getm(mfx_chg, m)
    if (not pd.isna(sp)) and (not pd.isna(fxm)):
        ident["S3"][m] = 2 if (sp <= -0.03 or fxm >= 0.015) else 1
    else:
        ident["S3"][m] = 0

    ay, ayp = getm(afre_yoy, m), getm(afre_yoy, m, 1)
    dm, dmp = getm(mdr, m), getm(mdr, m, 1)
    s4_ok = (not pd.isna(ay)) and (not pd.isna(ayp)) and (not pd.isna(dm)) \
        and (not pd.isna(dmp)) and (not pd.isna(e_m))
    if s4_ok:
        ident["S4"][m] = 2 if (ay < ayp and dm > dmp and e_m < 0) else 1
    else:
        ident["S4"][m] = 0
    detail_rows.append(dict(month=str(m), pmi=p, pmi_prev=gp, y10_m=ym, y10_pm=ymp,
                            lpr_cut=cut, spx_m=sp, fx_m=fxm, eq300_m=e_m,
                            dr_m=dm, dr_pm=dmp, ppi=pv, ppi_prev=pgp,
                            afre_yoy=ay, afre_yoy_prev=ayp,
                            S1=ident["S1"][m], S2=ident["S2"][m],
                            S3=ident["S3"][m], S4=ident["S4"][m]))
DET = pd.DataFrame(detail_rows).set_index("month")
DET.to_csv("/tmp/_fin3_monthly_detail.csv")

QUAL = {sc: [m for m in EVAL_MONTHS if ident[sc].get(m) == 2] for sc in ident}
UNID = {sc: [str(m) for m in EVAL_MONTHS if ident[sc].get(m) == 0] for sc in ident}
for sc in ["S1", "S2", "S3", "S4"]:
    nm = rules_scen.set_index("scenario_id").loc[sc, "scenario"]
    print(f"\n{sc} {nm}: 合格 {len(QUAL[sc])} 个月: {[str(x) for x in QUAL[sc]]}")
    print(f"   无法识别(数据缺口) {len(UNID[sc])} 个月: {UNID[sc]}")

# ---- 历史窗口与校准冲击 (M8) ----
r_cur = port_ret(PLANS["当前组合"])
tdl = list(TD)
FACTOR_FUN = {"r300": ("prod", Rc.r300), "r905": ("prod", Rc.r905),
              "r399": ("prod", Rc.r399), "rspx": ("prod", Rc.rspx),
              "rfx": ("prod", Rc.rfx)}
for t in TENORS:
    FACTOR_FUN["dybp_" + t] = ("sum_bp", Rc["dy_" + t])

SEL_WINDOWS = {}
CALIB = {}
for sc in ["S1", "S2", "S3", "S4"]:
    cands = []
    for m in QUAL[sc]:
        nxt = (m + 1).to_timestamp()
        pos = [i for i, d in enumerate(tdl) if d >= nxt]
        if not pos or pos[0] + WIN_LEN > len(tdl):
            continue
        days = pd.DatetimeIndex(tdl[pos[0]:pos[0] + WIN_LEN])
        if not days.isin(Rc.index).all():
            continue  # 因子数据不完整 (中债截断) → 窗口不可用
        rr = r_cur.reindex(days).values
        if np.any(pd.isna(rr)):
            continue
        cands.append(dict(month=str(m), start=days[0], end=days[-1],
                          cum=float(np.prod(1 + rr) - 1),
                          allneg=bool(np.all(rr < 0))))
    cands.sort(key=lambda x: x["cum"])
    n_strict = sum(c["allneg"] for c in cands)
    sel = [c for c in cands if c["allneg"]]
    for c in cands:
        if len(sel) >= WIN_MIN_N:
            break
        if not c["allneg"]:
            sel.append(c)
    sel = sel[:max(WIN_MIN_N, n_strict)]
    SEL_WINDOWS[sc] = (cands, sel, n_strict)
    meds = {}
    for fk, (mode, fv) in FACTOR_FUN.items():
        vals = []
        for c in sel:
            seg = fv.loc[c["start"]:c["end"]]   # 窗口内 10 个交易日
            if mode == "prod":
                vals.append(float((1 + seg).prod() - 1))
            else:
                vals.append(float(seg.sum() * 100))  # 百分点→bp
        meds[fk] = float(np.median(vals))
    CALIB[sc] = meds
    print(f"\n{sc}: 候选窗口 {len(cands)} 个, 其中10日全负 {n_strict} 个, "
          f"选入 {len(sel)} 个; 最差窗口 {sel[0]['start'].date()}~{sel[0]['end'].date()} "
          f"累计 {sel[0]['cum']*100:.2f}%")
    print("   校准冲击(中位数): " + ", ".join(
        f"{k}={v*100:.2f}%" if k.startswith("r") else f"{k.replace('dybp_','')}={v:+.2f}bp"
        for k, v in meds.items()))

# 委员会沿用冲击解析 (M5: cgb_shock_bp 数值按百分数解读)
COMM = {}
for r in committee.itertuples():
    bp = {}
    for kv in r.cgb_shock_bp.split(","):
        k, v = kv.split(":")
        bp[k.strip().lower().replace("y", "")] = float(v)  # 百分数
    COMM[r.scenario_id] = dict(name=r.scenario, eq=r.cn_equity_shock,
                               spx=r.spx_usd_shock, fx=r.usdcnh_shock,
                               dy_pct={("dy_" + {"1": "1y", "2": "2y", "5": "5y",
                                                  "10": "10y", "30": "30y"}[k]): v
                                       for k, v in bp.items()},
                               dy_bp={("dy_" + {"1": "1y", "2": "2y", "5": "5y",
                                                 "10": "10y", "30": "30y"}[k]): v * 100
                                      for k, v in bp.items()})
print("\n委员会沿用冲击 (国债按 % 解读, 括号为 bp):")
for sc, c in COMM.items():
    print(f"  {sc} {c['name']}: 权益 {c['eq']:+.2%}, 标普 {c['spx']:+.2%}, "
          f"汇率 {c['fx']:+.2%}, 国债 " +
          ", ".join(f"{TENOR_CN[t]}:{c['dy_pct']['dy_'+t]*100:+.0f}bp" for t in TENORS))
# =============================================================================
# S5. 压力测试: 5 方案 × 4 情景 × 2 套冲击, 四腿贡献分解
# =============================================================================
hdr("[S5] 压力测试 (四部分贡献分解, 四部分之和 = 组合损益)")

EQ_ASSETS = ["EQ_000300", "EQ_000905", "EQ_399006"]


def cgb_price_impact(dy_bp):
    """国债组合价格冲击 = -Σ 久期贡献 × Δy (小数); dy_bp 单位 bp。"""
    return -sum(dur_map[t] * dy_bp["dy_" + t] / 10000.0 for t in TENORS)


def stress_plan(w, eq_shocks, spx, fx, dy_bp):
    if np.isscalar(eq_shocks):
        eq_shocks = {k: float(eq_shocks) for k in EQ_ASSETS}
    leg_eq = sum(w[k] * eq_shocks[k] for k in EQ_ASSETS)
    leg_spx = w["SPX"] * ((1 + spx) * (1 + fx) - 1)      # 复合折算 (M3)
    leg_usd = w["USD_CASH"] * fx
    cgb_pi = cgb_price_impact(dy_bp)
    leg_cgb = w["CGB"] * cgb_pi
    return dict(total=leg_eq + leg_spx + leg_usd + leg_cgb, eq=leg_eq, spx=leg_spx,
                usd=leg_usd, cgb=leg_cgb, cgb_price=cgb_pi)


def shock_sets(sc):
    c = COMM[sc]
    cal = CALIB[sc]
    return {
        "委员会沿用冲击": dict(eq=c["eq"], spx=c["spx"], fx=c["fx"], dy_bp=c["dy_bp"]),
        "历史校准冲击": dict(eq={"EQ_000300": cal["r300"], "EQ_000905": cal["r905"],
                                 "EQ_399006": cal["r399"]},
                             spx=cal["rspx"], fx=cal["rfx"],
                             dy_bp={("dy_" + t): cal["dybp_" + t] for t in TENORS}),
    }


STRESS = {}     # STRESS[plan][sc][setname] = 结果 dict
for nm in PLAN_NAMES:
    STRESS[nm] = {}
    for sc in ["S1", "S2", "S3", "S4"]:
        STRESS[nm][sc] = {}
        for setname, sh in shock_sets(sc).items():
            STRESS[nm][sc][setname] = stress_plan(PLANS[nm], sh["eq"], sh["spx"],
                                                  sh["fx"], sh["dy_bp"])

for setname in ["委员会沿用冲击", "历史校准冲击"]:
    sub(f"压力测试结果 —— {setname} (损益单位: %, 金额单位: 万元, 净值 10,000 万)")
    rows = []
    for nm in PLAN_NAMES:
        for sc in ["S1", "S2", "S3", "S4"]:
            r = STRESS[nm][sc][setname]
            rows.append(dict(方案=nm, 情景=sc,
                             境内权益=round(r["eq"] * 100, 2),
                             标普500人民币计=round(r["spx"] * 100, 2),
                             美元现金=round(r["usd"] * 100, 2),
                             国债=round(r["cgb"] * 100, 2),
                             组合损益_pct=round(r["total"] * 100, 2),
                             组合损益_万元=round(r["total"] * NAV_TOTAL, 2),
                             校验_四腿之和=round((r["eq"] + r["spx"] + r["usd"]
                                                  + r["cgb"] - r["total"]) * 1e6, 6)))
    print(pd.DataFrame(rows).to_string(index=False))

MAXLOSS = {}
for nm in PLAN_NAMES:
    worst = min(((STRESS[nm][sc][s]["total"], sc, s)
                 for sc in STRESS[nm] for s in STRESS[nm][sc]), key=lambda z: z[0])
    MAXLOSS[nm] = dict(loss=max(0.0, -worst[0]), worst_total=worst[0],
                       scenario=worst[1], set=worst[2])
sub("各方案最大压力损失 (4 情景 × 2 套冲击)")
for nm in PLAN_NAMES:
    m = MAXLOSS[nm]
    print(f"{nm}: 最大压力损失 {m['loss']*100:.2f}% ({m['loss']*NAV_TOTAL:.0f} 万元), "
          f"来源: {m['scenario']} / {m['set']} (最不利损益 {m['worst_total']*100:.2f}%)")

sub("两套冲击严格程度对比 (因子层面 + 国债久期折算价格冲击)")
rows = []
for sc in ["S1", "S2", "S3", "S4"]:
    for setname, sh in shock_sets(sc).items():
        eqs = sh["eq"]
        eq_mean = np.mean([eqs[k] for k in EQ_ASSETS]) if isinstance(eqs, dict) else eqs
        rows.append(dict(情景=sc, 冲击=setname,
                         境内权益_pct=round(eq_mean * 100, 2),
                         标普500_pct=round(sh["spx"] * 100, 2),
                         USDCNH_pct=round(sh["fx"] * 100, 2),
                         国债价格冲击_pct=round(cgb_price_impact(sh["dy_bp"]) * 100, 2),
                         **{("Δy" + TENOR_CN[t] + "_bp"): round(sh["dy_bp"]["dy_" + t], 1)
                            for t in TENORS},
                         推荐方案损益_pct=round(
                             stress_plan(PLANS["推荐方案"], sh["eq"], sh["spx"],
                                         sh["fx"], sh["dy_bp"])["total"] * 100, 2),
                         当前组合损益_pct=round(
                             stress_plan(PLANS["当前组合"], sh["eq"], sh["spx"],
                                         sh["fx"], sh["dy_bp"])["total"] * 100, 2)))
SEVERITY = pd.DataFrame(rows)
print(SEVERITY.to_string(index=False))

# =============================================================================
# S6. 九项约束逐条检查
# =============================================================================
hdr("[S6] 九项约束逐条检查 (C1~C9, 对应 L1~L9)")

CHECKS = {}
for nm in PLAN_NAMES:
    w = PLANS[nm]
    m = METRICS[nm]
    eq_sum = sum(w[k] for k in EQ_ASSETS)
    fx_exp = w["USD_CASH"] + w["SPX"]        # L5 口径: 美元现金 + 不对冲汇率的 QDII
    res = {}
    res["C1"] = dict(ok=abs(sum(w.values()) - 1) <= C1_TOL, val=sum(w.values()),
                     desc="权重合计=100%(容差0.05pp)", exceed=abs(sum(w.values()) - 1))
    res["C2"] = dict(ok=eq_sum <= LIM["L2"]["upper"] + 1e-12, val=eq_sum,
                     desc="权益合计<=60%",
                     exceed=max(0, eq_sum - LIM["L2"]["upper"]))
    cash = w["CNY_CASH"]
    res["C3"] = dict(ok=(cash >= LIM["L3"]["lower"] - 1e-12) and
                        (cash <= LIM["L3"]["upper"] + 1e-12), val=cash,
                     desc="人民币现金 in [8%,20%]",
                     exceed=max(0, LIM["L3"]["lower"] - cash, cash - LIM["L3"]["upper"]))
    res["C4"] = dict(ok=w["CGB"] >= L4_MIN - 1e-12, val=w["CGB"],
                     desc=f"国债>={L4_MIN*100:.0f}%", exceed=max(0, L4_MIN - w["CGB"]))
    res["C5"] = dict(ok=fx_exp <= LIM["L5"]["upper"] + 1e-12, val=fx_exp,
                     desc="外币敞口<=25%",
                     exceed=max(0, fx_exp - LIM["L5"]["upper"]))
    res["C6"] = dict(ok=m["es99_1d"] <= L6_ES99 + 1e-12, val=m["es99_1d"],
                     desc="1日ES99<=3.5%", exceed=max(0, m["es99_1d"] - L6_ES99))
    res["C7"] = dict(ok=m["var99_10d"] <= L7_VA10 + 1e-12, val=m["var99_10d"],
                     desc="10日VaR99<=6.0%", exceed=max(0, m["var99_10d"] - L7_VA10))
    res["C8"] = dict(ok=MAXLOSS[nm]["loss"] <= L8_MAX + 1e-12, val=MAXLOSS[nm]["loss"],
                     desc="最大压力损失<=8.0%",
                     exceed=max(0, MAXLOSS[nm]["loss"] - L8_MAX))
    if nm == "推荐方案":
        res["C9"] = dict(ok=MAXLOSS[nm]["loss"] <= L9_BUF + 1e-12,
                         val=MAXLOSS[nm]["loss"], desc="推荐方案最大压力损失<=7.0%",
                         exceed=max(0, MAXLOSS[nm]["loss"] - L9_BUF))
    else:
        res["C9"] = dict(ok=None, val=np.nan, desc="仅适用于最终推荐方案", exceed=np.nan)
    CHECKS[nm] = res

rows = []
for nm in PLAN_NAMES:
    for cid, r in CHECKS[nm].items():
        rows.append(dict(方案=nm, 检查=cid, 说明=r["desc"],
                         数值=("不适用" if r["ok"] is None else
                               (f"{r['val']*100:.2f}%" if cid not in ("C1",) else f"{r['val']:.4f}")),
                         结论=("不适用" if r["ok"] is None else ("通过" if r["ok"] else "未通过")),
                         超限幅度=("—" if (r["ok"] is None or r["ok"]) else
                                   f"{r['exceed']*100:.2f}pp")))
CHK = pd.DataFrame(rows)
print(CHK.to_string(index=False))
print("\n外币敞口构成 (L5 口径 = 美元现金及存款 + 不对冲汇率的标普500 QDII):")
for nm in PLAN_NAMES:
    w = PLANS[nm]
    print(f"  {nm}: 美元现金 {w['USD_CASH']*100:.2f}% + 标普QDII {w['SPX']*100:.2f}% "
          f"= {100*(w['USD_CASH']+w['SPX']):.2f}%")
print("  说明: 未发现任何方案存在漏计/误计——方案C 的外币敞口 30% 为把美元现金提高到 20% 所致,")
print("        若漏计 QDII 会误判为 20% (通过), 按 L5 口径计为 30% (超限 5.00pp)。")

# =============================================================================
# S7. 调仓执行与推荐方案唯一性
# =============================================================================
hdr("[S7] 推荐方案调仓执行 (rules_rebalance.csv) 与唯一性比较")

cur_mv = positions.set_index("asset_class")["market_value_10k_cny"]
tgt_mv = pd.Series({a: PLANS["推荐方案"][a] * NAV_TOTAL for a in ASSET_ORDER})
delta = (tgt_mv - cur_mv.reindex(ASSET_ORDER)).round(2)
# 人民币现金及货基是轧差项 (交易后的剩余现金), 本身不构成买卖指令, 不计入交易清单;
# 现金占比路径 = 期初现金 + 卖出回款 − 买入支付, 期末应恰好等于目标现金。
trades = [(a, delta[a]) for a in ASSET_ORDER
          if a != "CNY_CASH" and abs(delta[a]) >= 0.005]
sells = sorted([t for t in trades if t[1] < 0], key=lambda z: z[1])
buys = sorted([t for t in trades if t[1] > 0], key=lambda z: -z[1])
assert abs(sum(v for _, v in trades) + delta["CNY_CASH"]) < 0.01, "交易清单与现金轧差不平"
AMAP = {"EQ_000300": "沪深300指数基金", "EQ_000905": "中证500指数基金",
        "EQ_399006": "创业板指数基金", "CGB": "中长期国债组合",
        "USD_CASH": "美元现金及存款", "SPX": "标普500QDII基金",
        "CNY_CASH": "人民币现金及货基"}
TURNOVER = sum(-v for _, v in sells) / NAV_TOTAL
sub("交易清单 (按 2026-09-15 收盘价/估值日价格, 金额万元)")
for a, v in sells + buys:
    print(f"  {'卖出' if v < 0 else '买入'} {AMAP[a]}: {abs(v):.2f} 万元 "
          f"({cur_mv[a]:.2f} → {tgt_mv[a]:.2f})")
print(f"  [轧差] 人民币现金及货基: {cur_mv['CNY_CASH']:.2f} → {tgt_mv['CNY_CASH']:.2f} 万元 "
      f"(非交易指令, 由上述买卖净额自动形成)")
print(f"单向换手率 = 卖出合计 / 净值 = {sum(-v for _, v in sells):.2f} / {NAV_TOTAL:.0f} "
      f"= {TURNOVER*100:.2f}%")
print("标普500 QDII 与美元现金权重不变 → 无 QDII 申赎, T+7 结算规则不触发。")

sub("执行现金路径 (人民币现金及货基占比, 下限 8%)")


def cash_path(order):
    cash = cur_mv["CNY_CASH"]
    path = [("期初", cash)]
    for a, v in order:
        cash = cash - v          # v<0 卖出回款增加现金; v>0 买入扣减现金
        path.append((("卖出" if v < 0 else "买入") + AMAP[a], cash))
    return path


path_sf = cash_path(sells + buys)          # 先卖出后买入 (规则要求)
path_bf = cash_path(buys + sells)          # 先买入后卖出 (对照)
for label, path in [("先卖出后买入(合规路径)", path_sf), ("先买入后卖出(对照路径)", path_bf)]:
    seq = " → ".join(f"{s}:{c/NAV_TOTAL*100:.2f}%" for s, c in path)
    breach = min(c for _, c in path) / NAV_TOTAL < CASH_FLOOR - 1e-12
    print(f"  {label}: {seq}")
    print(f"    最低现金占比 {min(c for _, c in path)/NAV_TOTAL*100:.2f}%, "
          f"{'击穿 8% 下限' if breach else '未击穿下限'}")
assert abs(path_sf[-1][1] - tgt_mv["CNY_CASH"]) < 0.01 and \
       abs(path_bf[-1][1] - tgt_mv["CNY_CASH"]) < 0.01
print(f"    轧差校验: 两条路径期末现金均收敛至目标 "
      f"{tgt_mv['CNY_CASH']:.2f} 万元 ({tgt_mv['CNY_CASH']/NAV_TOTAL*100:.2f}%)")

sub("唯一性: 同换手率 (减配 20.50pp) 下 国债/现金 拆分变体比较")
R_FIX = 0.205
rows = []
for x in np.arange(0.0, R_FIX + 1e-9, 0.005):
    k = 1 - R_FIX / 0.5
    w = dict(EQ_000300=0.25 * k, EQ_000905=0.15 * k, EQ_399006=0.10 * k,
             CGB=0.20 + x, USD_CASH=0.10, SPX=0.10, CNY_CASH=0.10 + R_FIX - x)
    ml = max(0, -min(stress_plan(w, sh["eq"], sh["spx"], sh["fx"], sh["dy_bp"])["total"]
                     for sc in ["S1", "S2", "S3", "S4"] for sh in shock_sets(sc).values()))
    rows.append(dict(转入国债_pp=round(x * 100, 1), 转入现金_pp=round((R_FIX - x) * 100, 1),
                     现金终值_pct=round(w["CNY_CASH"] * 100, 2),
                     L3通过="是" if 0.08 - 1e-12 <= w["CNY_CASH"] <= 0.20 + 1e-12 else "否",
                     最大压力损失_pct=round(ml * 100, 2)))
SPLIT = pd.DataFrame(rows)
print(SPLIT.to_string(index=False))
feasible = SPLIT[SPLIT.L3通过 == "是"]
best_x = feasible.loc[feasible.最大压力损失_pct.idxmin()]
print(f"同换手率可行域 (现金<=20% ⇒ 转入国债>=10.5pp) 内 minimax 拆分: "
      f"国债 +{best_x.转入国债_pp}pp, 最大压力损失 {best_x.最大压力损失_pct}%")
rec_ml = MAXLOSS["推荐方案"]["loss"] * 100
print(f"规则构造点 (国债 +10.5pp / 现金 +10pp): 最大压力损失 {rec_ml:.2f}%, "
      f"与 minimax 点差 {abs(best_x.最大压力损失_pct - rec_ml):.2f}pp; "
      f"现金恰好达 L3 上限 20%, 流动性缓冲最大")

sub("唯一性: 同换手率下 权益非等比缩减 (倾斜) 变体比较")
k = 1 - R_FIX / 0.5
tilts = {
    "等比缩减(推荐, 0.59)": (0.25 * k, 0.15 * k, 0.10 * k),
    "多减创业板1pp": (0.25 * k, 0.15 * k + 0.005, 0.10 * k - 0.005),
    "多减沪深300_1pp": (0.25 * k - 0.005, 0.15 * k + 0.005, 0.10 * k),
}
for tname, (w3, w9, wc) in tilts.items():
    w = dict(EQ_000300=w3, EQ_000905=w9, EQ_399006=wc, CGB=0.305,
             USD_CASH=0.10, SPX=0.10, CNY_CASH=0.20)
    z = min(((stress_plan(w, sh["eq"], sh["spx"], sh["fx"], sh["dy_bp"])["total"], sc, sn)
             for sc in ["S1", "S2", "S3", "S4"]
             for sn, sh in shock_sets(sc).items()), key=lambda t: t[0])
    print(f"  {tname}: 权益 ({w3*100:.2f}%/{w9*100:.2f}%/{wc*100:.2f}%) "
          f"最大压力损失 {max(0, -z[0])*100:.2f}% (来源 {z[1]}/{z[2]})")

sub("构造背景: 不同减配幅度 R 的可行性与缓冲 (全部资金转入国债、现金保持 10% 的极限构造)")
rows = []
for Rr in np.arange(0.02, 0.3001, 0.01):
    kk = 1 - Rr / 0.5
    w = dict(EQ_000300=0.25 * kk, EQ_000905=0.15 * kk, EQ_399006=0.10 * kk,
             CGB=0.20 + Rr, USD_CASH=0.10, SPX=0.10, CNY_CASH=0.10)
    ml = max(0, -min(stress_plan(w, sh["eq"], sh["spx"], sh["fx"], sh["dy_bp"])["total"]
                     for sc in ["S1", "S2", "S3", "S4"] for sh in shock_sets(sc).values()))
    rows.append(dict(减配_pp=round(Rr * 100, 1), 换手率_pct=round(Rr * 100, 2),
                     最大压力损失_pct=round(ml * 100, 2),
                     通过C8_8pct="是" if ml <= L8_MAX + 1e-12 else "否",
                     通过C9_7pct="是" if ml <= L9_BUF + 1e-12 else "否"))
RGRID = pd.DataFrame(rows)
print(RGRID.to_string(index=False))
pass9 = RGRID[RGRID.通过C9_7pct == "是"]
print(f"满足 C9(<=7%) 的最小减配幅度 ≈ {pass9.减配_pp.min()}pp (换手率 {pass9.换手率_pct.min():.2f}%), "
      f"其最大压力损失 {pass9.最大压力损失_pct.max():.2f}% —— 缓冲趋近于 0, 稳健性差;")
print(f"推荐方案减配 20.5pp, 最大压力损失 {rec_ml:.2f}%, 对 7% 缓冲线留有 "
      f"{L9_BUF*100 - rec_ml:.2f}pp 裕度, 对 8% 上限留有 {L8_MAX*100 - rec_ml:.2f}pp 裕度。")
# =============================================================================
# S8. 反向压力测试与马氏距离
# =============================================================================
hdr("[S8] 反向压力测试 (推荐方案), 马氏距离与裕度/放大倍数")

FAC_NAMES = ["沪深300", "中证500", "创业板指", "标普500(USD)", "USD/CNH",
             "中债1Y(bp)", "中债2Y(bp)", "中债5Y(bp)", "中债10Y(bp)", "中债30Y(bp)"]
F = pd.DataFrame(index=Rc.index)
for col, src in [("f300", "r300"), ("f905", "r905"), ("f399", "r399"),
                 ("fspx", "rspx"), ("ffx", "rfx")]:
    nav_i = (1 + Rc[src]).cumprod()
    F[col] = nav_i / nav_i.shift(WIN_LEN) - 1          # 10 日累计收益
for t in TENORS:
    F["fy_" + t] = Rc["dy_" + t].rolling(WIN_LEN).sum() * 100   # 10 日累计变动 bp
F = F.dropna()
mu = F.mean().values
SIG = F.cov().values
SIG_P = np.linalg.pinv(SIG)
print(f"因子样本: {F.index.min().date()} ~ {F.index.max().date()}, {len(F)} 个滚动 10 日窗口")

wR = PLANS["推荐方案"]


def exact_loss(x):
    """推荐方案在 10 日因子变动 x 下的精确损益 (标普腿复合折算)。"""
    s = (wR["EQ_000300"] * x[0] + wR["EQ_000905"] * x[1] + wR["EQ_399006"] * x[2]
         + wR["SPX"] * ((1 + x[3]) * (1 + x[4]) - 1) + wR["USD_CASH"] * x[4])
    s += wR["CGB"] * (-sum(dur_map[t] * x[5 + i] / 10000.0
                           for i, t in enumerate(TENORS)))
    return s


b = np.array([wR["EQ_000300"], wR["EQ_000905"], wR["EQ_399006"],
              wR["SPX"] * (1 + mu[4]), wR["SPX"] * (1 + mu[3]) + wR["USD_CASH"]]
             + [-wR["CGB"] * dur_map[t] / 10000.0 for t in TENORS])
# 约束 b'x = c 下最小化 (x-mu)'Σ⁻¹(x-mu) 的方向为 v = Σb (拉格朗日解),
# 马氏距离按 Σ 的伪逆计算 (收益率因子高度共线)。
v = SIG @ b


def solve_scale(target):
    """沿损失方向 -v 求步长 s, 使精确复合损益 = target (<0)。"""
    lo, hi = 0.0, 1.0
    while exact_loss(mu - hi * v) > target:
        hi *= 2
        if hi > 1e6:
            raise RuntimeError("solve_scale 未收敛")
    for _ in range(200):
        mid = (lo + hi) / 2
        if exact_loss(mu - mid * v) > target:
            lo = mid
        else:
            hi = mid
    return (lo + hi) / 2


def maha(x):
    d = np.asarray(x) - mu
    return float(np.sqrt(max(d @ SIG_P @ d, 0.0)))


REV = {}
for tgt, tag in [(-L9_BUF, "L9缓冲线7%"), (-L8_MAX, "L8上限8%")]:
    s = solve_scale(tgt)
    x_star = mu - s * v
    REV[tag] = dict(x=x_star, s=s, dist=maha(x_star), loss=exact_loss(x_star))
    print(f"\n目标损失 {tag}: 精确损益 {exact_loss(x_star)*100:.2f}%, "
          f"最小马氏距离 = {REV[tag]['dist']:.2f}")
    for nm_f, val, unit in zip(FAC_NAMES, x_star,
                               ["%"] * 5 + ["bp"] * 5):
        print(f"   {nm_f}: {val*100:+.2f}%" if unit == "%" else f"   {nm_f}: {val:+.2f}bp")

sub("各冲击向量的马氏距离 (同一因子空间)")
rows = []
for sc in ["S1", "S2", "S3", "S4"]:
    c = COMM[sc]
    xc = [c["eq"], c["eq"], c["eq"], c["spx"], c["fx"]] + \
         [c["dy_bp"]["dy_" + t] for t in TENORS]
    cal = CALIB[sc]
    xk = [cal["r300"], cal["r905"], cal["r399"], cal["rspx"], cal["rfx"]] + \
         [cal["dybp_" + t] for t in TENORS]
    rows.append(dict(情景=sc,
                     沿用冲击距离=round(maha(xc), 2),
                     校准冲击距离=round(maha(xk), 2),
                     沿用_推荐方案损益_pct=round(
                         STRESS["推荐方案"][sc]["委员会沿用冲击"]["total"] * 100, 2),
                     校准_推荐方案损益_pct=round(
                         STRESS["推荐方案"][sc]["历史校准冲击"]["total"] * 100, 2)))
rows.append(dict(情景="反向测试(损失=7%)", 沿用冲击距离=round(REV["L9缓冲线7%"]["dist"], 2),
                 校准冲击距离=np.nan, 沿用_推荐方案损益_pct=-7.0,
                 校准_推荐方案损益_pct=np.nan))
rows.append(dict(情景="反向测试(损失=8%)", 沿用冲击距离=round(REV["L8上限8%"]["dist"], 2),
                 校准冲击距离=np.nan, 沿用_推荐方案损益_pct=-8.0,
                 校准_推荐方案损益_pct=np.nan))
MAHA = pd.DataFrame(rows)
print(MAHA.to_string(index=False))

ml_rec = MAXLOSS["推荐方案"]["loss"]
sub("推荐方案裕度与放大倍数")
print(f"最大压力损失 {ml_rec*100:.2f}% (来源 {MAXLOSS['推荐方案']['scenario']} / "
      f"{MAXLOSS['推荐方案']['set']})")
print(f"对 L9 缓冲线 7.00%: 裕度 = {(L9_BUF-ml_rec)*100:.2f}pp, "
      f"放大倍数 = 7.00/{ml_rec*100:.2f} = {L9_BUF/ml_rec:.2f} 倍")
print(f"对 L8 上限 8.00%: 裕度 = {(L8_MAX-ml_rec)*100:.2f}pp, "
      f"放大倍数 = 8.00/{ml_rec*100:.2f} = {L8_MAX/ml_rec:.2f} 倍")
print(f"样本内最差 10 日累计损失(推荐方案): {METRICS['推荐方案']['worst10']*100:.2f}% "
      f"({METRICS['推荐方案']['worst10_start']} ~ {METRICS['推荐方案']['worst10_end']})")
print(f"样本内最差 10 日累计损失(当前组合): {METRICS['当前组合']['worst10']*100:.2f}% "
      f"({METRICS['当前组合']['worst10_start']} ~ {METRICS['当前组合']['worst10_end']})")

# =============================================================================
# S9. 八个监测指标 (template_monitor.csv 口径, 截至 2026-09-15)
# =============================================================================
hdr("[S9] 八个监测指标: 阈值、最新值、状态与触发")


def win_stats(series, n=WIN_LEN * 1):
    s = series.dropna()
    return s.iloc[-(n + 1)], s.index[-(n + 1)], s.iloc[-1], s.index[-1]


c300_full = px["沪深300"]
MON = []
base_v, base_d, last_v, last_d = win_stats(c300_full, 20)
m1 = last_v / base_v - 1
MON.append(dict(id="M1", ind="沪深300 20日收益", thr="-5.00%", dir="低于阈值触发",
                val=m1 * 100, fmt=f"{m1*100:.2f}%", asof=str(last_d.date()),
                trig=m1 < -0.05, gap=""))
base_v, base_d, last_v, last_d = win_stats(fx_al, 20)
m2 = last_v / base_v - 1
MON.append(dict(id="M2", ind="USD/CNH 20日变化", thr="+2.00%", dir="高于阈值触发",
                val=m2 * 100, fmt=f"{m2*100:.2f}%", asof=str(last_d.date()),
                trig=m2 > 0.02, gap=""))
drs = dr_al.dropna()
m3 = (drs.iloc[-20:].mean() - drs.iloc[-80:-20].mean()) * 100
MON.append(dict(id="M3", ind="DR007 资金面变化", thr="+20.00bp", dir="高于阈值触发",
                val=m3, fmt=f"{m3:+.2f}bp", asof=str(drs.index[-1].date()),
                trig=m3 > 20, gap=""))
y10s = yld_al["10y"].dropna()
m4 = (y10s.iloc[-1] - y10s.iloc[-21]) * 100
MON.append(dict(id="M4", ind="10年期国债收益率 20日变化", thr="+10.00bp",
                dir="高于阈值触发", val=m4, fmt=f"{m4:+.2f}bp",
                asof=str(y10s.index[-1].date()), trig=m4 > 10,
                gap="数据缺口: 中债序列截断于 2026-06-09, 按最近可得 20 个交易日判定"))
u10s = ust10_al.dropna()
m5 = (u10s.iloc[-1] - u10s.iloc[-21]) * 100
MON.append(dict(id="M5", ind="美国10年期国债收益率 20日变化", thr="+40.00bp",
                dir="高于阈值触发", val=m5, fmt=f"{m5:+.2f}bp",
                asof=str(u10s.index[-1].date()), trig=m5 > 40, gap=""))
m6_last_p = mppi.dropna().index[-1].to_period("M")
m6_base_p = m6_last_p - 3
m6 = float(mppi.dropna().iloc[-1]) - float(getm(mppi, m6_base_p))
MON.append(dict(id="M6", ind="PPI 同比加速", thr="+1.50 个百分点", dir="高于阈值触发",
                val=m6, fmt=f"{m6:+.2f}pp",
                asof=str(mppi.dropna().index[-1].date()),
                trig=m6 > 1.5,
                gap=f"最新月 {m6_last_p} 对比 3 个月前 {m6_base_p}"))
m7 = mpmi.dropna().iloc[-1]
MON.append(dict(id="M7", ind="制造业 PMI 荣枯线", thr="49.00", dir="低于阈值触发",
                val=m7, fmt=f"{m7:.2f}", asof=str(mpmi.dropna().index[-1].date()),
                trig=m7 < 49, gap="2026-08 缺月(结构性空值, 未插补), 按最新可得月判定"))
m8 = afre_yoy.dropna().iloc[-1]
MON.append(dict(id="M8", ind="社融存量增速", thr="8.00%", dir="低于阈值触发",
                val=m8, fmt=f"{m8:.2f}%", asof=str(afre_yoy.dropna().index[-1].date()),
                trig=m8 < 8.0,
                gap="数据缺口: 社融序列截断于 2026-04, 按最近可得月判定"))
MOND = pd.DataFrame(MON)
for r in MON:
    status = "触发" if r["trig"] else "正常"
    if r["gap"]:
        status += " | " + r["gap"]
    print(f"  {r['id']} {r['ind']}: 阈值 {r['thr']} ({r['dir']}), 最新值 {r['fmt']}, "
          f"数据截至 {r['asof']} → {status}")
n_trig = sum(r["trig"] for r in MON)
print(f"\n触发指标数量: {n_trig} / 8")
# =============================================================================
# S10. 图表输出 (5 张复合 PNG, 中文标注, 含限额参考线, a/b/c 分面标题)
# =============================================================================
hdr("[S10] 图表输出")
from matplotlib.dates import date2num  # noqa: E402

CHART_FILES = []


def save(fig, fname):
    p = os.path.join(CHART_DIR, fname)
    fig.savefig(p, dpi=150, bbox_inches="tight")
    plt.close(fig)
    CHART_FILES.append(p)
    print("已输出:", p)


# ---------- 图1: 数据覆盖与缺口 ----------
fig = plt.figure(figsize=(13.5, 11))
gs = fig.add_gridspec(2, 1, height_ratios=[2.1, 1.6], hspace=0.5)
ax = fig.add_subplot(gs[0])
names = V["series"].tolist()[::-1]
starts = [pd.Timestamp(s) for s in V["start"].tolist()[::-1]]
ends = [pd.Timestamp(s) for s in V["end"].tolist()[::-1]]
notes = V["note"].tolist()[::-1]
ypos = np.arange(len(names))
ax.barh(ypos, [date2num(e) - date2num(s) for s, e in zip(starts, ends)],
        left=[date2num(s) for s in starts], height=0.62,
        color=["#c0392b" if ("截断" in n or "缺月" in n or "仅 2026" in n) else "#2c6fbb"
               for n in notes], alpha=0.85)
for i, (s, e, n) in enumerate(zip(starts, ends, notes)):
    if "截断" in n or "缺月" in n or "仅 2026" in n:
        ax.text(date2num(e) + 20, i, "截断/缺口", va="center", fontsize=8, color="#c0392b")
ax.axvline(date2num(AS_OF), color="red", lw=1.6)
ax.text(date2num(AS_OF) + 20, len(names) - 0.6, f"分析截至日 {AS_OF.date()}",
        color="red", fontsize=9)
ax.axvline(date2num(cov_end_cgb), color="darkorange", lw=1.4, ls="--")
ax.text(date2num(cov_end_cgb) - 250, len(names) - 1.6,
        f"共同覆盖终点(中债截断) {cov_end_cgb.date()}", color="darkorange",
        fontsize=9, ha="right")
ax.set_yticks(ypos)
ax.set_yticklabels(names, fontsize=9)
ax.set_title(f"图1-a 各序列实际覆盖区间 (2018-01-02 ~ {AS_OF.date()}, 红色=存在截断/缺口)",
             fontsize=11)
ax.grid(axis="x", alpha=0.3)

ax = fig.add_subplot(gs[1])
z0, z1 = pd.Timestamp("2026-01-01"), pd.Timestamp("2026-09-30")
zs = [max(s, z0) for s in starts]
ze = [min(e, z1) for e in ends]
ax.barh(ypos, [max(date2num(e) - date2num(s), 0.5) for s, e in zip(zs, ze)],
        left=[date2num(s) for s in zs], height=0.62,
        color=["#c0392b" if e < AS_OF else "#2c6fbb" for e in ends], alpha=0.85)
for i, (nm, e) in enumerate(zip(names, ends)):
    if e < AS_OF and e >= z0:
        ax.text(date2num(e) + 2, i, f"止于{e.date()}", va="center", fontsize=7.5,
                color="#c0392b")
for er in excluded_rows:
    nm = "沪深300" if "000300" in er["file"] else "中证500"
    i = names.index(nm)
    ax.plot(date2num(pd.Timestamp(er["date"])), i, "x", color="black", ms=8, mew=2)
    ax.text(date2num(pd.Timestamp(er["date"])) - 60, i + 0.45,
            "休市日异常记录(剔除)", fontsize=7.5)
pmi_i = names.index("制造业PMI")
# 缺月位置从数据推导: mpmi 月度索引中值为 NaN 的月份 (结构性空值, 不插补)
for mt in mpmi.index[mpmi.isna()]:
    m_start = mt.to_period("M").to_timestamp()      # 月初, 仅作图标记位置
    if z0 <= m_start <= z1:
        ax.plot(date2num(m_start), pmi_i, "x", color="black", ms=8, mew=2)
        ax.text(date2num(m_start) - 26, pmi_i + 0.45,
                f"{mt.strftime('%Y-%m')} 缺月", fontsize=7.5)
ax.axvline(date2num(AS_OF), color="red", lw=1.6)
ax.set_yticks(ypos)
ax.set_yticklabels(names, fontsize=9)
ax.set_xlim(date2num(z0), date2num(z1))
ax.set_title("图1-b 2026 年放大: 截断位置、缺月与剔除的休市日异常记录", fontsize=11)
ax.grid(axis="x", alpha=0.3)
fig.suptitle("图1 数据覆盖与缺口 (数据核验先于计算)", fontsize=13)
save(fig, "FIN3-WKN-149_chart01_数据覆盖与缺口.png")

# ---------- 图2: 历史风险总览 ----------
fig = plt.figure(figsize=(13.5, 10))
gs = fig.add_gridspec(2, 1, height_ratios=[1.2, 1.0], hspace=0.45)
ax = fig.add_subplot(gs[0])
for nm in PLAN_NAMES:
    nav = METRICS[nm]["_nav"]
    ax.plot(nav.index, nav.values, label=nm, color=PLAN_COLORS[nm], lw=1.4,
            ls="--" if nm == "当前组合" else "-")
ax.set_title(f"图2-a 各方案累计净值曲线 (每日再平衡, {Rc.index.min().date()} = 1.00, "
             f"至 {Rc.index.max().date()}; 受中债截断限制)", fontsize=11)
ax.legend(loc="upper left", fontsize=9)
ax.grid(alpha=0.3)
ax.set_ylabel("净值")

ax = fig.add_subplot(gs[1])
metrics_lbl = ["年化波动率", "1日ES99", "10日VaR99", "最大回撤|·|"]
keys = ["ann_vol", "es99_1d", "var99_10d", "mdd"]
x = np.arange(len(metrics_lbl))
wd = 0.16
for j, nm in enumerate(PLAN_NAMES):
    vals = [abs(METRICS[nm][k]) * 100 for k in keys]
    bars = ax.bar(x + (j - 2) * wd, vals, wd, label=nm, color=PLAN_COLORS[nm])
    ax.bar_label(bars, fmt="%.2f", fontsize=7, padding=1)
ax.plot([1 - 2.6 * wd, 1 + 2.6 * wd], [L6_ES99 * 100] * 2, color="red", lw=2, ls="--")
ax.text(1 + 2.7 * wd, L6_ES99 * 100, f"L6上限 {L6_ES99*100:.1f}%", color="red",
        va="center", fontsize=9)
ax.plot([2 - 2.6 * wd, 2 + 2.6 * wd], [L7_VA10 * 100] * 2, color="darkorange", lw=2, ls="--")
ax.text(2 + 2.7 * wd, L7_VA10 * 100, f"L7上限 {L7_VA10*100:.1f}%", color="darkorange",
        va="center", fontsize=9)
ax.set_xticks(x)
ax.set_xticklabels(metrics_lbl)
ax.set_ylabel("%")
ax.set_title("图2-b 各方案年化波动率、1日ES99、10日VaR99、最大回撤与限额参考线", fontsize=11)
ax.legend(fontsize=8, ncol=5)
ax.grid(axis="y", alpha=0.3)
fig.suptitle("图2 历史风险总览 (历史窗口: 共同覆盖样本)", fontsize=13)
save(fig, "FIN3-WKN-149_chart02_历史风险总览.png")

# ---------- 图3: 情景识别与校准 ----------
SC_NAMES = {r.scenario_id: r.scenario for r in rules_scen.itertuples()}
fig = plt.figure(figsize=(14, 11.5))
gs = fig.add_gridspec(3, 1, height_ratios=[0.9, 1.15, 1.15], hspace=0.55)
ax = fig.add_subplot(gs[0])
mat = np.array([[ident[sc].get(m, 0) for m in EVAL_MONTHS]
                for sc in ["S1", "S2", "S3", "S4"]], dtype=float)
cmap = ListedColormap(["#9e9e9e", "#cfe3f7", "#c0392b"])
ax.imshow(mat, aspect="auto", cmap=cmap, vmin=-0.5, vmax=2.5,
          extent=[-0.5, len(EVAL_MONTHS) - 0.5, 3.5, -0.5])
ax.set_yticks(range(4))
ax.set_yticklabels([f"{sc} {SC_NAMES[sc]}" for sc in ["S1", "S2", "S3", "S4"]],
                   fontsize=9)
xt = [i for i, m in enumerate(EVAL_MONTHS) if m.month == 1]
ax.set_xticks(xt)
ax.set_xticklabels([EVAL_MONTHS[i].year for i in xt], fontsize=9)
ax.set_title("图3-a 四情景月度识别结果 (2018-02 ~ 2026-08; 2026-09 为不完整当月不参与)",
             fontsize=11)
ax.legend(handles=[mpatches.Patch(color="#c0392b", label="合格"),
                   mpatches.Patch(color="#cfe3f7", label="不合格"),
                   mpatches.Patch(color="#9e9e9e", label="无法识别(数据缺口)")],
          loc="upper left", bbox_to_anchor=(0, -0.18), ncol=3, fontsize=9)

fac_lbl = ["沪深300", "中证500", "创业板指", "标普500(USD)", "USD/CNH", "国债组合*"]
sc_list = ["S1", "S2", "S3", "S4"]


def calib_vec(sc):
    cal = CALIB[sc]
    cgb_pi = cgb_price_impact({("dy_" + t): cal["dybp_" + t] for t in TENORS}) * 100
    return [cal["r300"] * 100, cal["r905"] * 100, cal["r399"] * 100,
            cal["rspx"] * 100, cal["rfx"] * 100, cgb_pi]


def comm_vec(sc):
    c = COMM[sc]
    return [c["eq"] * 100] * 3 + [c["spx"] * 100, c["fx"] * 100,
                                  cgb_price_impact(c["dy_bp"]) * 100]


ax = fig.add_subplot(gs[1])
x = np.arange(4)
wd = 0.13
colors6 = plt.cm.tab10(np.linspace(0, 1, 6))
for j in range(6):
    vals = [calib_vec(sc)[j] for sc in sc_list]
    bars = ax.bar(x + (j - 2.5) * wd, vals, wd, color=colors6[j], label=fac_lbl[j])
    ax.bar_label(bars, fmt="%.1f", fontsize=6.5, padding=1)
ax.axhline(0, color="black", lw=0.8)
ax.set_xticks(x)
ax.set_xticklabels([f"{sc} {SC_NAMES[sc]}" for sc in sc_list], fontsize=9)
ax.set_ylabel("% (10 个交易日累计)")
ax.set_title("图3-b 各情景历史窗口校准冲击 (中位数; *国债为久期折算价格冲击, "
             "原始 bp 见备忘录第四章)", fontsize=11)
ax.legend(fontsize=8, ncol=6)
ax.grid(axis="y", alpha=0.3)

ax = fig.add_subplot(gs[2])
grp_lbl = ["境内权益(三指数均值)", "标普500(USD)", "USD/CNH", "国债组合价格冲击*"]
x = np.arange(4)
wd = 0.1
for si, sc in enumerate(sc_list):
    cv, kv = comm_vec(sc), calib_vec(sc)
    for fj, cidx in enumerate([slice(0, 3), 3, 4, 5]):
        if isinstance(cidx, slice):
            c_m, k_m = np.mean(cv[cidx]), np.mean(kv[cidx])
        else:
            c_m, k_m = cv[cidx], kv[cidx]
        pos = x[si] + (fj * 2 - 3.5) * wd
        b1 = ax.bar(pos, c_m, wd * 0.92, color=colors6[fj])
        b2 = ax.bar(pos + wd, k_m, wd * 0.92, color=colors6[fj], alpha=0.40)
        ax.bar_label(b1, fmt="%.1f", fontsize=6, padding=1)
        ax.bar_label(b2, fmt="%.1f", fontsize=6, padding=1)
ax.axhline(0, color="black", lw=0.8)
ax.set_xticks(x)
ax.set_xticklabels([f"{sc} {SC_NAMES[sc]}" for sc in sc_list], fontsize=9)
ax.set_ylabel("%")
ax.set_title("图3-c 沿用冲击(深色) 与 历史校准冲击(浅色) 严格程度对比", fontsize=11)
ax.legend(handles=[mpatches.Patch(color=colors6[fj], label=grp_lbl[fj]) for fj in range(4)]
          + [mpatches.Patch(color="#bbbbbb", label="沿用冲击(深色)"),
             mpatches.Patch(color="#dddddd", label="历史校准(浅色)")],
          fontsize=8, ncol=3)
ax.grid(axis="y", alpha=0.3)
fig.suptitle("图3 情景识别与校准", fontsize=13)
save(fig, "FIN3-WKN-149_chart03_情景识别与校准.png")

# ---------- 图4: 方案决策与执行 ----------
fig = plt.figure(figsize=(14, 12))
gs = fig.add_gridspec(3, 1, height_ratios=[1, 1, 1], hspace=0.55)
ax = fig.add_subplot(gs[0])
vals = [MAXLOSS[nm]["loss"] * 100 for nm in PLAN_NAMES]
bars = ax.bar(PLAN_NAMES, vals, 0.55, color=[PLAN_COLORS[nm] for nm in PLAN_NAMES])
for b, nm in zip(bars, PLAN_NAMES):
    m = MAXLOSS[nm]
    ax.text(b.get_x() + b.get_width() / 2, b.get_height() + 0.12,
            f"{m['loss']*100:.2f}%\n({m['scenario']}/{m['set'][:4]})",
            ha="center", fontsize=8)
ax.axhline(L8_MAX * 100, color="red", lw=2, ls="--")
ax.text(4.42, L8_MAX * 100, f"L8 压力损失上限 {L8_MAX*100:.0f}%", color="red",
        va="center", fontsize=9)
ax.axhline(L9_BUF * 100, color="darkorange", lw=2, ls=":")
ax.text(4.42, L9_BUF * 100, f"L9 缓冲线 {L9_BUF*100:.0f}%", color="darkorange",
        va="center", fontsize=9)
ax.set_ylim(0, max(vals) * 1.28)
ax.set_ylabel("最大压力损失 (%)")
ax.set_title("图4-a 各方案最大压力损失 (4 情景 × 2 套冲击的最不利结果)", fontsize=11)
ax.grid(axis="y", alpha=0.3)

ax = fig.add_subplot(gs[1])
steps = [s for s, _ in path_sf]
y1 = [c / NAV_TOTAL * 100 for _, c in path_sf]
y2 = [c / NAV_TOTAL * 100 for _, c in path_bf]
xx = np.arange(len(steps))
ax.plot(xx, y1, "o-", color="#2ca02c", lw=2, label="先卖出后买入(规则要求)")
ax.plot(xx, y2, "s--", color="#d62728", lw=2, label="先买入后卖出(对照)")
ax.axhline(CASH_FLOOR * 100, color="red", lw=2, ls="--")
ax.text(len(steps) - 0.4, CASH_FLOOR * 100 + 0.6, f"现金下限 {CASH_FLOOR*100:.0f}%",
        color="red", ha="right", fontsize=9)
for xi, v in zip(xx, y2):
    if v < CASH_FLOOR * 100:
        ax.annotate(f"击穿: {v:.2f}%", (xi, v), textcoords="offset points",
                    xytext=(8, -14), color="#d62728", fontsize=9)
ax.set_xticks(xx)
ax.set_xticklabels(steps, fontsize=8.5, rotation=12)
ax.set_ylabel("人民币现金及货基占比 (%)")
ax.set_title("图4-b 调仓执行现金路径与 8% 下限线 (净值 10,000 万元)", fontsize=11)
ax.legend(fontsize=9)
ax.grid(alpha=0.3)

ax = fig.add_subplot(gs[2])
xr = REV["L9缓冲线7%"]["x"]
pct_vals = xr[:5] * 100
bp_vals = xr[5:]
xx = np.arange(10)
c1 = ["#1f77b4"] * 3 + ["#ff7f0e", "#2ca02c"]
b1 = ax.bar(xx[:5], pct_vals, 0.6, color=c1)
ax.bar_label(b1, fmt="%.2f%%", fontsize=8)
ax.set_ylabel("10 日累计变动 (%)")
ax2 = ax.twinx()
b2 = ax2.bar(xx[5:], bp_vals, 0.6, color="#8c5fbf")
ax2.bar_label(b2, fmt="%.1fbp", fontsize=8)
ax2.set_ylabel("中债收益率 10 日累计变动 (bp)")
ax.set_xticks(xx)
ax.set_xticklabels(FAC_NAMES, fontsize=8.5, rotation=20)
ax.axhline(0, color="black", lw=0.8)
ax2.axhline(0, color="black", lw=0.8)
ax.set_title(f"图4-c 反向压力测试最可能情景: 推荐方案损失达 {L9_BUF*100:.0f}% 所需的"
             f"因子变动 (最小马氏距离 {REV['L9缓冲线7%']['dist']:.2f})", fontsize=11)
ax.grid(axis="y", alpha=0.3)
fig.suptitle("图4 方案决策与执行", fontsize=13)
save(fig, "FIN3-WKN-149_chart04_方案决策与执行.png")

# ---------- 图5: 监测指标触发状态 ----------
fig = plt.figure(figsize=(14, 9))
gs = fig.add_gridspec(2, 1, height_ratios=[1, 1.1], hspace=0.35)
ax = fig.add_subplot(gs[0])
thr_num = [-5.0, 2.0, 20.0, 10.0, 40.0, 1.5, 49.0, 8.0]
below = [True, False, False, False, False, False, True, True]
margins = []
for r, tv, bl in zip(MON, thr_num, below):
    margins.append(((r["val"] - tv) / abs(tv) * 100) if bl
                   else ((tv - r["val"]) / abs(tv) * 100))
colors = ["#d62728" if m < 0 else "#2ca02c" for m in margins]
bars = ax.bar([r["id"] for r in MON], margins, 0.55, color=colors)
for b, r, m in zip(bars, MON, margins):
    ax.text(b.get_x() + b.get_width() / 2,
            b.get_height() + (2 if m >= 0 else -6),
            f"{r['fmt']}\n(阈值{r['thr']})", ha="center", fontsize=8)
ax.axhline(0, color="black", lw=1.2)
ax.set_ylabel("触发裕度 (相对阈值, %)")
ax.set_ylim(min(margins) - 35, max(max(margins), 60) + 40)
ax.set_title("图5-a 八个监测指标触发裕度 (负值=已触发; 柱上标注最新值与阈值)", fontsize=11)
ax.grid(axis="y", alpha=0.3)

ax = fig.add_subplot(gs[1])
ax.axis("off")
cols = ["指标ID", "监测指标", "阈值", "方向", "最新值", "数据截至", "状态", "是否触发"]
cell = []
cellcol = []
for r in MON:
    status = "数据缺口,按最近可得值判定" if r["gap"] else "正常监测"
    trig = "触发" if r["trig"] else "未触发"
    row = [r["id"], r["ind"], r["thr"], r["dir"], r["fmt"], r["asof"], status, trig]
    cell.append(row)
    cc = ["#ffffff"] * 8
    cc[7] = "#f8cbad" if r["trig"] else "#c6e0b4"
    if r["gap"]:
        cc[6] = "#ffe699"
    cellcol.append(cc)
tab = ax.table(cellText=cell, colLabels=cols, cellColours=cellcol,
               colColours=["#d9d9d9"] * 8, cellLoc="center", loc="center")
tab.auto_set_font_size(False)
tab.set_fontsize(8.5)
tab.scale(1, 1.5)
ax.set_title("图5-b 监测指标明细 (template_monitor.csv 口径)", fontsize=11, pad=18)
fig.suptitle("图5 监测指标触发状态 (截至 2026-09-15)", fontsize=13)
save(fig, "FIN3-WKN-149_chart05_监测指标触发状态.png")

# =============================================================================
# 汇总
# =============================================================================
hdr("[汇总] 关键结论数字 (供备忘录引用)")
print(f"样本: 上交所交易日 {TD.min().date()} ~ {AS_OF.date()} 共 {n_days_full} 天; "
      f"共同覆盖 {TD.min().date()} ~ {cov_end_cgb.date()} 共 {n_days_common} 天")
print(f"剔除休市日异常记录 {len(excluded_rows)} 条 (2026-09-12 周六)")
for nm in PLAN_NAMES:
    m, ml = METRICS[nm], MAXLOSS[nm]
    c9 = CHECKS[nm]["C9"]["ok"]
    verdict = ("不适用" if c9 is None else ("通过" if c9 else "未通过"))
    fails = [cid for cid, r in CHECKS[nm].items()
             if r["ok"] is not None and not bool(r["ok"])]
    print(f"{nm}: 年化波动 {m['ann_vol']*100:.2f}% | ES99_1d {m['es99_1d']*100:.2f}% | "
          f"VaR99_10d {m['var99_10d']*100:.2f}% | MDD {m['mdd']*100:.2f}% | "
          f"最大压力损失 {ml['loss']*100:.2f}% ({ml['scenario']}/{ml['set']}) | "
          f"九项检查未通过 {len(fails)} 项"
          f"{' (' + '/'.join(fails) + ')' if fails else ''} | C9 {verdict}")
print(f"推荐方案: 单向换手率 {TURNOVER*100:.2f}%, 现金路径最低 "
      f"{min(c for _, c in path_sf)/NAV_TOTAL*100:.2f}% (先卖后买), "
      f"对照路径最低 {min(c for _, c in path_bf)/NAV_TOTAL*100:.2f}% (先买后卖)")
print(f"反向压力测试: 损失达 7% 的最小马氏距离 {REV['L9缓冲线7%']['dist']:.2f}, "
      f"达 8% 为 {REV['L8上限8%']['dist']:.2f}")
print(f"监测触发: {n_trig}/8 → " +
      ", ".join(r["id"] for r in MON if r["trig"]))
print("\n图表文件:")
for p in CHART_FILES:
    print(" ", p)
print("\n运行完毕: 备忘录中全部数字均可由本脚本从 /app/input_files/ 原始快照复现。")
