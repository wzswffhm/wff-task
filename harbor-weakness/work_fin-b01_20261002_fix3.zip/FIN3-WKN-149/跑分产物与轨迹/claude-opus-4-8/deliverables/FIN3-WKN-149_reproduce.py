#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
多资产稳健配置专户：三季度宏观压力测试与调仓建议
可复算代码 - 从原始快照计算全部结果

分析截至日：2026-09-15
组合净值：10,000 万元
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.font_manager as fm
from pathlib import Path
from datetime import datetime, timedelta
import warnings
warnings.filterwarnings('ignore')

# 设置中文字体
plt.rcParams['font.sans-serif'] = ['SimHei', 'DejaVu Sans']
plt.rcParams['axes.unicode_minus'] = False

# 路径配置
INPUT_DIR = Path('/app/input_files')
OUTPUT_DIR = Path('/app/output')
CHART_DIR = OUTPUT_DIR / 'FIN3-WKN-149_charts'
CHART_DIR.mkdir(parents=True, exist_ok=True)

# 常量
ANALYSIS_DATE = pd.Timestamp('2026-09-15')
NAV = 10000.0  # 万元

# ============================================================================
# 第一部分：数据加载与核验
# ============================================================================

class DataLoader:
    """数据加载器 - 负责从原始CSV读取并合并分段文件"""

    def __init__(self, input_dir):
        self.input_dir = Path(input_dir)

    def load_segmented(self, prefix, date_col='date'):
        """加载分段文件（seg1 + seg2）"""
        seg1_file = self.input_dir / f'{prefix}_seg1.csv'
        seg2_file = self.input_dir / f'{prefix}_seg2.csv'

        dfs = []
        for f in [seg1_file, seg2_file]:
            if f.exists():
                df = pd.read_csv(f)
                df[date_col] = pd.to_datetime(df[date_col])
                dfs.append(df)

        if not dfs:
            return pd.DataFrame()

        combined = pd.concat(dfs, ignore_index=True)
        combined = combined.sort_values(date_col).drop_duplicates(subset=[date_col], keep='last')
        return combined.reset_index(drop=True)

    def load_single(self, filename, date_col='date'):
        """加载单个文件"""
        file_path = self.input_dir / filename
        if not file_path.exists():
            return pd.DataFrame()

        df = pd.read_csv(file_path)
        if date_col in df.columns:
            df[date_col] = pd.to_datetime(df[date_col])
        return df

    def load_all_market_data(self):
        """加载所有市场数据"""
        data = {}

        # 股票指数
        data['000300'] = self.load_segmented('snapshot_000300SH')
        data['000905'] = self.load_segmented('snapshot_000905SH')
        data['399006'] = self.load_segmented('snapshot_399006SZ')

        # 国债收益率
        data['cgb_1y'] = self.load_single('snapshot_cgb_yield_1y.csv')
        data['cgb_2y'] = self.load_single('snapshot_cgb_yield_2y.csv')
        data['cgb_5y'] = self.load_single('snapshot_cgb_yield_5y.csv')
        data['cgb_10y'] = self.load_single('snapshot_cgb_yield_10y.csv')
        data['cgb_30y'] = self.load_single('snapshot_cgb_yield_30y.csv')

        # 汇率和标普500
        data['usdcnh'] = self.load_segmented('snapshot_usdcnh')
        data['spx'] = self.load_single('snapshot_spx.csv')

        # 货币市场
        data['shibor'] = self.load_segmented('snapshot_shibor')
        data['dr007'] = self.load_single('snapshot_dr007.csv')

        # 宏观指标
        data['lpr_1y'] = self.load_single('snapshot_lpr_1y.csv')
        data['lpr_5y'] = self.load_single('snapshot_lpr_5y.csv')
        data['pmi'] = self.load_single('snapshot_pmi_manufacturing.csv')
        data['afre'] = self.load_single('snapshot_afre_stock.csv')
        data['ppi'] = self.load_single('snapshot_ppi_yoy.csv')

        # 美债
        data['ust_10y'] = self.load_single('snapshot_ust_10y.csv')

        # 交易日历
        data['calendar'] = self.load_single('snapshot_trade_calendar.csv')

        return data


class DataValidator:
    """数据核验器 - 检查覆盖区间、缺口、异常值"""

    def __init__(self, data, trading_calendar):
        self.data = data
        self.calendar = trading_calendar[trading_calendar['is_trading_day'] == 1]['date']
        self.calendar = pd.to_datetime(self.calendar).sort_values().reset_index(drop=True)

    def validate_coverage(self):
        """核验各序列覆盖区间"""
        coverage = []

        for name, df in self.data.items():
            if name == 'calendar' or df.empty:
                continue

            date_col = 'date'
            if date_col not in df.columns:
                continue

            dates = pd.to_datetime(df[date_col]).dropna()
            if len(dates) == 0:
                coverage.append({
                    'series': name,
                    'start': None,
                    'end': None,
                    'records': 0,
                    'gaps': 0,
                    'coverage_rate': 0.0
                })
                continue

            start_date = dates.min()
            end_date = dates.max()

            # 计算期望交易日数
            expected_days = self.calendar[(self.calendar >= start_date) &
                                         (self.calendar <= end_date)]

            coverage.append({
                'series': name,
                'start': start_date,
                'end': end_date,
                'records': len(dates),
                'expected': len(expected_days),
                'coverage_rate': len(dates) / len(expected_days) if len(expected_days) > 0 else 0.0
            })

        return pd.DataFrame(coverage)

    def find_gaps(self, df, date_col='date', threshold_days=5):
        """查找序列中的数据缺口"""
        if df.empty or date_col not in df.columns:
            return []

        dates = pd.to_datetime(df[date_col]).sort_values().reset_index(drop=True)
        gaps = []

        for i in range(len(dates) - 1):
            gap_days = (dates.iloc[i+1] - dates.iloc[i]).days
            if gap_days > threshold_days:
                gaps.append({
                    'start': dates.iloc[i],
                    'end': dates.iloc[i+1],
                    'days': gap_days
                })

        return gaps



# ============================================================================
# 第二部分：价格对齐与收益率计算
# ============================================================================

class ReturnCalculator:
    """收益率计算器 - 处理价格对齐、日收益计算"""

    def __init__(self, trading_calendar):
        self.calendar = trading_calendar[trading_calendar['is_trading_day'] == 1]['date']
        self.calendar = pd.to_datetime(self.calendar).sort_values().reset_index(drop=True)

    def align_to_trading_days(self, df, date_col='date', value_cols=None):
        """将数据对齐到上交所交易日 - 前向填充"""
        if df.empty:
            return df

        df = df.copy()
        df[date_col] = pd.to_datetime(df[date_col])

        # 创建完整交易日索引
        full_calendar = pd.DataFrame({'date': self.calendar})
        full_calendar = full_calendar[(full_calendar['date'] >= df[date_col].min()) &
                                     (full_calendar['date'] <= df[date_col].max())]

        # 合并并前向填充
        if value_cols is None:
            value_cols = [col for col in df.columns if col != date_col]

        merged = full_calendar.merge(df[[date_col] + value_cols], on=date_col, how='left')
        merged[value_cols] = merged[value_cols].ffill()

        return merged

    def calc_equity_returns(self, price_df, price_col='close'):
        """计算股票指数日收益率"""
        df = price_df.copy()
        df = df.sort_values('date').reset_index(drop=True)
        df['return'] = df[price_col].pct_change()
        return df

    def calc_bond_portfolio_return(self, yield_dfs, duration_contrib):
        """计算国债组合日收益率 - 按关键期限久期加权"""
        # yield_dfs: dict of {tenor: df with date and yield_pct}
        # duration_contrib: dict of {tenor: duration_value}

        # 对齐所有期限到同一日期索引
        all_dates = None
        aligned_yields = {}

        for tenor, df in yield_dfs.items():
            if df.empty:
                continue
            df = df.copy()
            df = df.sort_values('date').reset_index(drop=True)

            if all_dates is None:
                all_dates = df['date']
            else:
                all_dates = pd.concat([all_dates, df['date']]).drop_duplicates().sort_values()

        if all_dates is None:
            return pd.DataFrame()

        all_dates = all_dates.reset_index(drop=True)

        # 对齐每个期限
        for tenor, df in yield_dfs.items():
            tenor_key = tenor.replace('年', '')
            if tenor_key not in duration_contrib:
                continue

            df = df.copy()
            df = df.sort_values('date')
            aligned = pd.DataFrame({'date': all_dates})
            aligned = aligned.merge(df[['date', 'yield_pct']], on='date', how='left')
            aligned['yield_pct'] = aligned['yield_pct'].ffill()
            aligned_yields[tenor_key] = aligned

        # 计算组合收益率
        result = pd.DataFrame({'date': all_dates})

        # 计算每日收益 = -sum(duration_i * delta_yield_i) / 100
        total_duration = sum(duration_contrib.values())

        daily_returns = []
        for i in range(len(all_dates)):
            if i == 0:
                daily_returns.append(0.0)
                continue

            daily_return = 0.0
            for tenor_key, dur in duration_contrib.items():
                if tenor_key in aligned_yields:
                    yield_today = aligned_yields[tenor_key].iloc[i]['yield_pct']
                    yield_yesterday = aligned_yields[tenor_key].iloc[i-1]['yield_pct']

                    if pd.notna(yield_today) and pd.notna(yield_yesterday):
                        delta_yield_bp = (yield_today - yield_yesterday) * 100  # 转换为bp
                        contribution = -dur * delta_yield_bp / 10000  # 修正系数
                        daily_return += contribution

            daily_returns.append(daily_return)

        result['return'] = daily_returns
        return result

    def calc_spx_cny_return(self, spx_df, usdcnh_df):
        """计算标普500人民币计收益率 - 复合方式"""
        # R_cny = (1 + R_usd) * (1 + R_fx) - 1

        spx = spx_df.copy().sort_values('date')
        fx = usdcnh_df.copy().sort_values('date')

        # 计算美元收益
        spx['return_usd'] = spx['close'].pct_change()

        # 计算汇率收益（USD/CNH上涨表示美元升值）
        fx['return_fx'] = fx['usdcnh'].pct_change()

        # 合并
        combined = spx[['date', 'return_usd']].merge(
            fx[['date', 'return_fx']], on='date', how='inner'
        )

        # 复合计算
        combined['return_cny'] = ((1 + combined['return_usd']) *
                                 (1 + combined['return_fx']) - 1)

        return combined[['date', 'return_cny']]



# ============================================================================
# 第三部分：组合收益与风险指标计算
# ============================================================================

class PortfolioAnalyzer:
    """组合分析器 - 计算组合收益、风险指标"""

    def __init__(self, asset_returns, trading_calendar):
        """
        asset_returns: dict of {asset_code: df with date and return}
        """
        self.asset_returns = asset_returns
        self.calendar = trading_calendar

    def calc_portfolio_returns(self, weights):
        """计算组合日收益率 - 每日再平衡"""
        # weights: dict of {asset_code: weight}

        # 找到所有资产的共同日期区间
        all_dates = None
        for asset, df in self.asset_returns.items():
            if df.empty:
                continue
            dates = df['date']
            if all_dates is None:
                all_dates = set(dates)
            else:
                all_dates = all_dates.intersection(set(dates))

        if all_dates is None or len(all_dates) == 0:
            return pd.DataFrame()

        all_dates = sorted(list(all_dates))

        # 构建收益矩阵
        portfolio_df = pd.DataFrame({'date': all_dates})

        for asset, weight in weights.items():
            if asset not in self.asset_returns:
                continue

            asset_df = self.asset_returns[asset]
            portfolio_df = portfolio_df.merge(
                asset_df[['date', 'return']].rename(columns={'return': asset}),
                on='date', how='left'
            )

        # 计算组合收益
        asset_cols = [col for col in portfolio_df.columns if col != 'date']
        portfolio_df['portfolio_return'] = 0.0

        for asset in asset_cols:
            if asset in weights:
                portfolio_df['portfolio_return'] += portfolio_df[asset] * weights[asset]

        # 计算累计净值
        portfolio_df['cum_nav'] = (1 + portfolio_df['portfolio_return']).cumprod()

        return portfolio_df

    def calc_risk_metrics(self, returns_series):
        """计算风险指标"""
        returns = returns_series.dropna()

        if len(returns) == 0:
            return {}

        metrics = {}

        # 基础统计
        metrics['mean_daily'] = returns.mean()
        metrics['std_daily'] = returns.std()
        metrics['annualized_vol'] = returns.std() * np.sqrt(252)
        metrics['skewness'] = returns.skew()
        metrics['kurtosis'] = returns.kurtosis()

        # VaR和ES
        metrics['var_95_1d'] = np.percentile(returns, 5)
        metrics['var_99_1d'] = np.percentile(returns, 1)
        metrics['es_95_1d'] = returns[returns <= metrics['var_95_1d']].mean()
        metrics['es_99_1d'] = returns[returns <= metrics['var_99_1d']].mean()

        # 10日VaR - 使用滚动窗口
        rolling_10d = returns.rolling(window=10).sum()
        metrics['var_99_10d'] = np.percentile(rolling_10d.dropna(), 1)

        # 最大回撤
        cum_returns = (1 + returns).cumprod()
        running_max = cum_returns.expanding().max()
        drawdown = (cum_returns - running_max) / running_max
        metrics['max_drawdown'] = drawdown.min()

        # 最差单日损失
        metrics['worst_daily_loss'] = returns.min()

        # 10日最大累计损失
        metrics['worst_10d_loss'] = rolling_10d.min()

        return metrics

    def calc_correlation_matrix(self):
        """计算资产相关矩阵"""
        # 对齐所有资产到共同日期
        all_dates = None
        for asset, df in self.asset_returns.items():
            if df.empty:
                continue
            dates = set(df['date'])
            if all_dates is None:
                all_dates = dates
            else:
                all_dates = all_dates.intersection(dates)

        if all_dates is None or len(all_dates) == 0:
            return pd.DataFrame()

        all_dates = sorted(list(all_dates))

        # 构建收益矩阵
        returns_df = pd.DataFrame({'date': all_dates})

        for asset, df in self.asset_returns.items():
            returns_df = returns_df.merge(
                df[['date', 'return']].rename(columns={'return': asset}),
                on='date', how='left'
            )

        returns_df = returns_df.drop(columns=['date'])
        corr_matrix = returns_df.corr()

        return corr_matrix



# ============================================================================
# 第四部分：情景识别与历史校准
# ============================================================================

class ScenarioIdentifier:
    """情景识别器 - 按规则识别合格月份"""

    def __init__(self, macro_data, market_data):
        """
        macro_data: dict with pmi, lpr_1y, lpr_5y, ppi, afre, dr007, etc.
        market_data: dict with equity indices, yields
        """
        self.macro = macro_data
        self.market = market_data

    def identify_monthly(self, scenario_rules):
        """按月识别四个情景的合格月份"""
        results = {
            'S1': [],
            'S2': [],
            'S3': [],
            'S4': []
        }

        # 准备月度数据
        monthly_data = self._prepare_monthly_data()

        for _, row in scenario_rules.iterrows():
            scenario_id = row['scenario_id']
            rule = row['rule']

            qualified_months = self._apply_rule(rule, monthly_data)
            results[scenario_id] = qualified_months

        return results

    def _prepare_monthly_data(self):
        """准备月度聚合数据"""
        monthly = {}

        # PMI（月度数据）
        if 'pmi' in self.macro and not self.macro['pmi'].empty:
            pmi_df = self.macro['pmi'].copy()
            pmi_df['year_month'] = pd.to_datetime(pmi_df['date']).dt.to_period('M')
            monthly['pmi'] = pmi_df.set_index('year_month')['pmi_mfg']

        # LPR（月度数据）
        if 'lpr_1y' in self.macro and not self.macro['lpr_1y'].empty:
            lpr1_df = self.macro['lpr_1y'].copy()
            lpr1_df['year_month'] = pd.to_datetime(lpr1_df['date']).dt.to_period('M')
            monthly['lpr_1y'] = lpr1_df.groupby('year_month')['lpr_1y'].last()

        if 'lpr_5y' in self.macro and not self.macro['lpr_5y'].empty:
            lpr5_df = self.macro['lpr_5y'].copy()
            lpr5_df['year_month'] = pd.to_datetime(lpr5_df['date']).dt.to_period('M')
            monthly['lpr_5y'] = lpr5_df.groupby('year_month')['lpr_5y'].last()

        # PPI（月度数据）
        if 'ppi' in self.macro and not self.macro['ppi'].empty:
            ppi_df = self.macro['ppi'].copy()
            ppi_df['year_month'] = pd.to_datetime(ppi_df['date']).dt.to_period('M')
            monthly['ppi'] = ppi_df.set_index('year_month')['ppi_yoy']

        # 社融（月度数据）
        if 'afre' in self.macro and not self.macro['afre'].empty:
            afre_df = self.macro['afre'].copy()
            afre_df['year_month'] = pd.to_datetime(afre_df['date']).dt.to_period('M')
            monthly['afre'] = afre_df.set_index('year_month')['afre_stock']

        # DR007（日度转月度均值）
        if 'dr007' in self.macro and not self.macro['dr007'].empty:
            dr_df = self.macro['dr007'].copy()
            dr_df['year_month'] = pd.to_datetime(dr_df['date']).dt.to_period('M')
            monthly['dr007'] = dr_df.groupby('year_month')['dr007'].mean()

        # 国债收益率（日度转月度均值）
        if 'cgb_10y' in self.market and not self.market['cgb_10y'].empty:
            cgb_df = self.market['cgb_10y'].copy()
            cgb_df['year_month'] = pd.to_datetime(cgb_df['date']).dt.to_period('M')
            monthly['cgb_10y'] = cgb_df.groupby('year_month')['yield_pct'].mean()

        # 权益指数月度收益率
        for idx in ['000300', '000905', '399006']:
            if idx in self.market and not self.market[idx].empty:
                eq_df = self.market[idx].copy()
                eq_df['year_month'] = pd.to_datetime(eq_df['date']).dt.to_period('M')
                monthly_close = eq_df.groupby('year_month')['close'].last()
                monthly[f'eq_{idx}_ret'] = monthly_close.pct_change()

        # 标普500月度收益率
        if 'spx' in self.market and not self.market['spx'].empty:
            spx_df = self.market['spx'].copy()
            spx_df['year_month'] = pd.to_datetime(spx_df['date']).dt.to_period('M')
            monthly_close = spx_df.groupby('year_month')['close'].last()
            monthly['spx_ret'] = monthly_close.pct_change()

        # USD/CNH月度变化
        if 'usdcnh' in self.market and not self.market['usdcnh'].empty:
            fx_df = self.market['usdcnh'].copy()
            fx_df['year_month'] = pd.to_datetime(fx_df['date']).dt.to_period('M')
            monthly_fx = fx_df.groupby('year_month')['usdcnh'].last()
            monthly['usdcnh_change'] = monthly_fx.pct_change()

        return monthly

    def _apply_rule(self, rule_text, monthly_data):
        """应用规则识别合格月份"""
        qualified = []

        # S1: 增长下行与政策宽松
        if 'PMI 月值 < 50' in rule_text:
            return self._identify_s1(monthly_data)

        # S2: 通胀上行与利率上行
        elif 'PPI 当月同比高于上月' in rule_text:
            return self._identify_s2(monthly_data)

        # S3: 外部冲击与美元走强
        elif '标普500 当月收益率 <= -3%' in rule_text:
            return self._identify_s3(monthly_data)

        # S4: 信用收缩与资金面收紧
        elif '社会融资规模存量同比增速低于上月' in rule_text:
            return self._identify_s4(monthly_data)

        return qualified

    def _identify_s1(self, monthly_data):
        """S1: 增长下行与政策宽松"""
        qualified = []

        pmi = monthly_data.get('pmi')
        lpr_1y = monthly_data.get('lpr_1y')
        lpr_5y = monthly_data.get('lpr_5y')
        cgb_10y = monthly_data.get('cgb_10y')

        if pmi is None:
            return qualified

        all_months = pmi.index

        for month in all_months:
            if month not in pmi.index:
                continue

            pmi_val = pmi.loc[month]
            if pd.isna(pmi_val):
                continue

            # 条件1: PMI < 50 且 LPR下调
            cond1 = False
            if pmi_val < 50:
                if lpr_1y is not None and month in lpr_1y.index:
                    prev_month = month - 1
                    if prev_month in lpr_1y.index:
                        if lpr_1y.loc[month] < lpr_1y.loc[prev_month]:
                            cond1 = True

                if not cond1 and lpr_5y is not None and month in lpr_5y.index:
                    prev_month = month - 1
                    if prev_month in lpr_5y.index:
                        if lpr_5y.loc[month] < lpr_5y.loc[prev_month]:
                            cond1 = True

            # 条件2: PMI下行 >= 0.5 且 10年期国债收益率月均值低于上月
            cond2 = False
            prev_month = month - 1
            if prev_month in pmi.index:
                pmi_change = pmi_val - pmi.loc[prev_month]
                if pmi_change <= -0.5:
                    if cgb_10y is not None and month in cgb_10y.index and prev_month in cgb_10y.index:
                        if cgb_10y.loc[month] < cgb_10y.loc[prev_month]:
                            cond2 = True

            if cond1 or cond2:
                qualified.append(month)

        return qualified

    def _identify_s2(self, monthly_data):
        """S2: 通胀上行与利率上行"""
        qualified = []

        ppi = monthly_data.get('ppi')
        cgb_10y = monthly_data.get('cgb_10y')
        eq_ret = monthly_data.get('eq_000300_ret')  # 用沪深300代表

        if ppi is None or cgb_10y is None or eq_ret is None:
            return qualified

        all_months = ppi.index.intersection(cgb_10y.index).intersection(eq_ret.index)

        for month in all_months:
            prev_month = month - 1
            if prev_month not in ppi.index or prev_month not in cgb_10y.index:
                continue

            # PPI高于上月
            if ppi.loc[month] > ppi.loc[prev_month]:
                # 10年期收益率高于上月
                if cgb_10y.loc[month] > cgb_10y.loc[prev_month]:
                    # 权益指数下跌
                    if eq_ret.loc[month] < 0:
                        qualified.append(month)

        return qualified

    def _identify_s3(self, monthly_data):
        """S3: 外部冲击与美元走强"""
        qualified = []

        spx_ret = monthly_data.get('spx_ret')
        usdcnh_change = monthly_data.get('usdcnh_change')

        if spx_ret is None and usdcnh_change is None:
            return qualified

        # 标普500 <= -3%
        if spx_ret is not None:
            for month in spx_ret.index:
                if pd.notna(spx_ret.loc[month]) and spx_ret.loc[month] <= -0.03:
                    if month not in qualified:
                        qualified.append(month)

        # USD/CNH >= +1.5%
        if usdcnh_change is not None:
            for month in usdcnh_change.index:
                if pd.notna(usdcnh_change.loc[month]) and usdcnh_change.loc[month] >= 0.015:
                    if month not in qualified:
                        qualified.append(month)

        return sorted(qualified)

    def _identify_s4(self, monthly_data):
        """S4: 信用收缩与资金面收紧"""
        qualified = []

        afre = monthly_data.get('afre')
        dr007 = monthly_data.get('dr007')
        eq_ret = monthly_data.get('eq_000300_ret')

        if afre is None or dr007 is None or eq_ret is None:
            return qualified

        # 计算社融同比增速
        afre_yoy = afre.pct_change(12) * 100  # 同比增速

        all_months = afre_yoy.index.intersection(dr007.index).intersection(eq_ret.index)

        for month in all_months:
            prev_month = month - 1
            if prev_month not in afre_yoy.index or prev_month not in dr007.index:
                continue

            # 社融同比增速低于上月
            if pd.notna(afre_yoy.loc[month]) and pd.notna(afre_yoy.loc[prev_month]):
                if afre_yoy.loc[month] < afre_yoy.loc[prev_month]:
                    # DR007高于上月
                    if dr007.loc[month] > dr007.loc[prev_month]:
                        # 权益下跌
                        if eq_ret.loc[month] < 0:
                            qualified.append(month)

        return qualified



class HistoricalCalibrator:
    """历史校准器 - 从合格月份构造历史窗口并校准冲击"""

    def __init__(self, qualified_months, market_data, trading_calendar):
        self.qualified_months = qualified_months
        self.market = market_data
        self.calendar = trading_calendar[trading_calendar['is_trading_day'] == 1]['date']
        self.calendar = pd.to_datetime(self.calendar).sort_values().reset_index(drop=True)

    def construct_windows(self, portfolio_returns):
        """构造历史窗口 - 次月首个交易日起10个交易日"""
        windows = {}

        for scenario_id, months in self.qualified_months.items():
            scenario_windows = []

            for month in months:
                # 找到次月第一个交易日
                next_month = month + 1
                next_month_start = pd.Timestamp(f'{next_month.year}-{next_month.month:02d}-01')

                first_trading_day = self.calendar[self.calendar >= next_month_start]
                if len(first_trading_day) == 0:
                    continue

                start_date = first_trading_day.iloc[0]

                # 找到接下来10个交易日
                start_idx = self.calendar[self.calendar == start_date].index[0]
                if start_idx + 10 > len(self.calendar):
                    continue

                window_dates = self.calendar.iloc[start_idx:start_idx+10].tolist()

                # 提取该窗口的组合收益
                window_returns = portfolio_returns[
                    portfolio_returns['date'].isin(window_dates)
                ]['portfolio_return'].values

                if len(window_returns) != 10:
                    continue

                # 只保留全部为负且累计跌幅最大的窗口
                cum_return = np.sum(window_returns)

                scenario_windows.append({
                    'month': month,
                    'start_date': window_dates[0],
                    'end_date': window_dates[-1],
                    'returns': window_returns,
                    'cum_return': cum_return
                })

            # 筛选：全部为负
            scenario_windows = [w for w in scenario_windows if np.all(w['returns'] < 0)]

            # 排序：按累计跌幅（最大损失）
            scenario_windows = sorted(scenario_windows, key=lambda x: x['cum_return'])

            # 取前20个（不少于20个）
            scenario_windows = scenario_windows[:max(20, len(scenario_windows))]

            windows[scenario_id] = scenario_windows

        return windows

    def calibrate_shocks(self, windows):
        """校准冲击 - 计算各风险因子在窗口内的累计变动中位数"""
        calibrated = {}

        for scenario_id, window_list in windows.items():
            if len(window_list) == 0:
                calibrated[scenario_id] = {}
                continue

            # 收集各风险因子的累计变动
            cn_equity_changes = []
            spx_changes = []
            usdcnh_changes = []
            cgb_changes = {
                '1Y': [], '2Y': [], '5Y': [], '10Y': [], '30Y': []
            }

            for window in window_list:
                start_date = window['start_date']
                end_date = window['end_date']

                # 境内权益：沪深300
                if '000300' in self.market and not self.market['000300'].empty:
                    df = self.market['000300']
                    start_price = df[df['date'] == start_date]['close'].values
                    end_price = df[df['date'] == end_date]['close'].values
                    if len(start_price) > 0 and len(end_price) > 0:
                        change = (end_price[0] - start_price[0]) / start_price[0]
                        cn_equity_changes.append(change)

                # 标普500（美元计）
                if 'spx' in self.market and not self.market['spx'].empty:
                    df = self.market['spx']
                    start_price = df[df['date'] == start_date]['close'].values
                    end_price = df[df['date'] == end_date]['close'].values
                    if len(start_price) > 0 and len(end_price) > 0:
                        change = (end_price[0] - start_price[0]) / start_price[0]
                        spx_changes.append(change)

                # USD/CNH
                if 'usdcnh' in self.market and not self.market['usdcnh'].empty:
                    df = self.market['usdcnh']
                    start_fx = df[df['date'] == start_date]['usdcnh'].values
                    end_fx = df[df['date'] == end_date]['usdcnh'].values
                    if len(start_fx) > 0 and len(end_fx) > 0:
                        change = (end_fx[0] - start_fx[0]) / start_fx[0]
                        usdcnh_changes.append(change)

                # 国债收益率（bp变化）
                for tenor, key in [('1y', '1Y'), ('2y', '2Y'), ('5y', '5Y'),
                                  ('10y', '10Y'), ('30y', '30Y')]:
                    cgb_key = f'cgb_{tenor}'
                    if cgb_key in self.market and not self.market[cgb_key].empty:
                        df = self.market[cgb_key]
                        start_yield = df[df['date'] == start_date]['yield_pct'].values
                        end_yield = df[df['date'] == end_date]['yield_pct'].values
                        if len(start_yield) > 0 and len(end_yield) > 0:
                            change_bp = (end_yield[0] - start_yield[0]) * 100
                            cgb_changes[key].append(change_bp)

            # 计算中位数
            shocks = {}
            if len(cn_equity_changes) > 0:
                shocks['cn_equity_shock'] = np.median(cn_equity_changes)
            if len(spx_changes) > 0:
                shocks['spx_usd_shock'] = np.median(spx_changes)
            if len(usdcnh_changes) > 0:
                shocks['usdcnh_shock'] = np.median(usdcnh_changes)

            cgb_shock_str_parts = []
            for tenor, changes in cgb_changes.items():
                if len(changes) > 0:
                    median_bp = np.median(changes)
                    cgb_shock_str_parts.append(f'{tenor}:{median_bp:+.2f}')

            if len(cgb_shock_str_parts) > 0:
                shocks['cgb_shock_bp'] = ','.join(cgb_shock_str_parts)

            calibrated[scenario_id] = shocks

        return calibrated



# ============================================================================
# 第五部分：压力测试引擎
# ============================================================================

class StressTestEngine:
    """压力测试引擎 - 对方案施加冲击并计算损益"""

    def __init__(self, duration_contrib):
        self.duration_contrib = duration_contrib

    def apply_stress(self, weights, shocks):
        """对组合施加压力冲击"""
        # weights: dict of {asset_code: weight}
        # shocks: dict with cn_equity_shock, spx_usd_shock, usdcnh_shock, cgb_shock_bp

        # 解析权重
        w_000300 = weights.get('w_000300', 0)
        w_000905 = weights.get('w_000905', 0)
        w_399006 = weights.get('w_399006', 0)
        w_cgb = weights.get('w_cgb', 0)
        w_usd_cash = weights.get('w_usd_cash', 0)
        w_spx_qdii = weights.get('w_spx_qdii', 0)
        w_cny_cash = weights.get('w_cny_cash', 0)

        # 境内权益合计
        w_cn_equity = w_000300 + w_000905 + w_399006

        # 解析冲击
        cn_equity_shock = shocks.get('cn_equity_shock', 0)
        spx_usd_shock = shocks.get('spx_usd_shock', 0)
        usdcnh_shock = shocks.get('usdcnh_shock', 0)
        cgb_shock_bp_str = shocks.get('cgb_shock_bp', '')

        # 解析国债冲击
        cgb_shocks = {}
        if cgb_shock_bp_str:
            parts = cgb_shock_bp_str.split(',')
            for part in parts:
                if ':' in part:
                    tenor, bp = part.split(':')
                    tenor = tenor.strip()
                    # 处理带年字的情况
                    if '年' in tenor:
                        tenor = tenor.replace('年', '')
                    cgb_shocks[tenor] = float(bp)

        # 计算各部分损益
        contributions = {}

        # 1. 境内权益损益
        contributions['cn_equity'] = w_cn_equity * cn_equity_shock

        # 2. 标普500（人民币计）损益 = 权重 * [(1+R_usd)*(1+R_fx)-1]
        spx_cny_return = (1 + spx_usd_shock) * (1 + usdcnh_shock) - 1
        contributions['spx_cny'] = w_spx_qdii * spx_cny_return

        # 3. 美元现金损益（汇率变动）
        contributions['usd_cash'] = w_usd_cash * usdcnh_shock

        # 4. 国债组合损益 = -sum(duration_i * delta_bp_i / 10000)
        cgb_pnl = 0.0
        total_duration = sum(self.duration_contrib.values())

        for tenor, dur in self.duration_contrib.items():
            tenor_key = tenor.replace('年', '')
            if tenor_key in cgb_shocks:
                delta_bp = cgb_shocks[tenor_key]
                contribution = -dur * delta_bp / 10000
                cgb_pnl += contribution

        contributions['cgb'] = w_cgb * cgb_pnl

        # 5. 人民币现金无损益（假设）
        contributions['cny_cash'] = 0.0

        # 总损益
        total_pnl = sum(contributions.values())

        return {
            'total': total_pnl,
            'contributions': contributions
        }

    def run_full_stress_test(self, plans, committee_shocks, calibrated_shocks):
        """运行完整压力测试：4方案 × 4情景 × 2冲击"""
        results = {}

        # 方案包括：当前组合 + 三个候选方案
        all_plans = plans.copy()

        for plan_id, plan_weights in all_plans.items():
            plan_results = {}

            for scenario_id in ['S1', 'S2', 'S3', 'S4']:
                scenario_results = {}

                # 委员会沿用冲击
                committee_shock = committee_shocks[
                    committee_shocks['scenario_id'] == scenario_id
                ].iloc[0]

                shock_dict_committee = {
                    'cn_equity_shock': committee_shock['cn_equity_shock'],
                    'spx_usd_shock': committee_shock['spx_usd_shock'],
                    'usdcnh_shock': committee_shock['usdcnh_shock'],
                    'cgb_shock_bp': committee_shock['cgb_shock_bp']
                }

                committee_result = self.apply_stress(plan_weights, shock_dict_committee)
                scenario_results['committee'] = committee_result

                # 历史校准冲击
                if scenario_id in calibrated_shocks:
                    calibrated_result = self.apply_stress(
                        plan_weights,
                        calibrated_shocks[scenario_id]
                    )
                    scenario_results['calibrated'] = calibrated_result
                else:
                    scenario_results['calibrated'] = {
                        'total': 0.0,
                        'contributions': {}
                    }

                plan_results[scenario_id] = scenario_results

            results[plan_id] = plan_results

        return results



# ============================================================================
# 第六部分：约束检查与方案评估
# ============================================================================

class ConstraintChecker:
    """约束检查器 - 九项限额检查"""

    def __init__(self, limits_df, historical_returns):
        self.limits = limits_df
        self.hist_returns = historical_returns

    def check_all(self, plan_weights, stress_results):
        """对方案进行九项约束检查"""
        checks = {}

        # L1: 权重合计 = 100%
        total_weight = sum(plan_weights.values())
        checks['C1'] = {
            'limit_id': 'L1',
            'description': '权重合计=100%',
            'value': total_weight,
            'limit': 1.0,
            'passed': abs(total_weight - 1.0) < 0.0005,
            'excess': total_weight - 1.0 if total_weight > 1.0 else 0.0
        }

        # L2: 权益类资产合计 <= 60%
        equity_weight = (plan_weights.get('w_000300', 0) +
                        plan_weights.get('w_000905', 0) +
                        plan_weights.get('w_399006', 0))
        checks['C2'] = {
            'limit_id': 'L2',
            'description': '权益类资产合计<=60%',
            'value': equity_weight,
            'limit': 0.6,
            'passed': equity_weight <= 0.6,
            'excess': equity_weight - 0.6 if equity_weight > 0.6 else 0.0
        }

        # L3: 人民币现金 in [8%, 20%]
        cny_cash = plan_weights.get('w_cny_cash', 0)
        checks['C3'] = {
            'limit_id': 'L3',
            'description': '人民币现金[8%,20%]',
            'value': cny_cash,
            'limit': [0.08, 0.2],
            'passed': 0.08 <= cny_cash <= 0.2,
            'excess': max(0.08 - cny_cash, cny_cash - 0.2, 0.0)
        }

        # L4: 国债 >= 15%
        cgb_weight = plan_weights.get('w_cgb', 0)
        checks['C4'] = {
            'limit_id': 'L4',
            'description': '国债>=15%',
            'value': cgb_weight,
            'limit': 0.15,
            'passed': cgb_weight >= 0.15,
            'excess': 0.15 - cgb_weight if cgb_weight < 0.15 else 0.0
        }

        # L5: 外币资产敞口 <= 25% (美元现金 + 标普500 QDII)
        fx_exposure = (plan_weights.get('w_usd_cash', 0) +
                      plan_weights.get('w_spx_qdii', 0))
        checks['C5'] = {
            'limit_id': 'L5',
            'description': '外币敞口<=25%',
            'value': fx_exposure,
            'limit': 0.25,
            'passed': fx_exposure <= 0.25,
            'excess': fx_exposure - 0.25 if fx_exposure > 0.25 else 0.0
        }

        # L6: 1日ES99 <= 3.5%
        if self.hist_returns is not None and len(self.hist_returns) > 0:
            returns = self.hist_returns.dropna()
            var_99 = np.percentile(returns, 1)
            es_99 = returns[returns <= var_99].mean()
        else:
            es_99 = 0.0

        checks['C6'] = {
            'limit_id': 'L6',
            'description': '1日ES99<=3.5%',
            'value': abs(es_99),
            'limit': 0.035,
            'passed': abs(es_99) <= 0.035,
            'excess': abs(es_99) - 0.035 if abs(es_99) > 0.035 else 0.0
        }

        # L7: 10日VaR99 <= 6.0%
        if self.hist_returns is not None and len(self.hist_returns) > 0:
            returns = self.hist_returns.dropna()
            rolling_10d = returns.rolling(window=10).sum()
            var_99_10d = np.percentile(rolling_10d.dropna(), 1)
        else:
            var_99_10d = 0.0

        checks['C7'] = {
            'limit_id': 'L7',
            'description': '10日VaR99<=6.0%',
            'value': abs(var_99_10d),
            'limit': 0.06,
            'passed': abs(var_99_10d) <= 0.06,
            'excess': abs(var_99_10d) - 0.06 if abs(var_99_10d) > 0.06 else 0.0
        }

        # L8: 最大压力损失 <= 8.0%
        max_stress_loss = 0.0
        if stress_results:
            for scenario_id, scenario_data in stress_results.items():
                for shock_type, result in scenario_data.items():
                    loss = abs(result['total'])
                    if loss > max_stress_loss:
                        max_stress_loss = loss

        checks['C8'] = {
            'limit_id': 'L8',
            'description': '最大压力损失<=8.0%',
            'value': max_stress_loss,
            'limit': 0.08,
            'passed': max_stress_loss <= 0.08,
            'excess': max_stress_loss - 0.08 if max_stress_loss > 0.08 else 0.0
        }

        # L9: 推荐方案最大压力损失 <= 7.0%（仅对推荐方案）
        checks['C9'] = {
            'limit_id': 'L9',
            'description': '推荐方案最大压力损失<=7.0%',
            'value': max_stress_loss,
            'limit': 0.07,
            'passed': max_stress_loss <= 0.07,
            'excess': max_stress_loss - 0.07 if max_stress_loss > 0.07 else 0.0
        }

        return checks



# ============================================================================
# 第七部分：推荐方案构造与调仓执行
# ============================================================================

class RebalanceExecutor:
    """调仓执行器 - 构造推荐方案并模拟执行路径"""

    def __init__(self, current_positions, nav):
        self.current_positions = current_positions
        self.nav = nav

    def construct_recommended_plan(self, current_weights):
        """根据规则构造推荐方案"""
        # 规则：美元现金10%、标普500 10%不变
        # 境内权益三项按当前权重同比例缩减，合计减配20.5个百分点（缩减系数0.59）
        # 10.5个百分点转入国债，10个百分点转入人民币现金

        current_cn_equity = (current_weights.get('w_000300', 0) +
                            current_weights.get('w_000905', 0) +
                            current_weights.get('w_399006', 0))

        shrink_factor = 0.59
        new_cn_equity_total = current_cn_equity * shrink_factor

        # 按原比例分配
        if current_cn_equity > 0:
            ratio_000300 = current_weights.get('w_000300', 0) / current_cn_equity
            ratio_000905 = current_weights.get('w_000905', 0) / current_cn_equity
            ratio_399006 = current_weights.get('w_399006', 0) / current_cn_equity
        else:
            ratio_000300 = ratio_000905 = ratio_399006 = 1/3

        recommended = {
            'w_000300': new_cn_equity_total * ratio_000300,
            'w_000905': new_cn_equity_total * ratio_000905,
            'w_399006': new_cn_equity_total * ratio_399006,
            'w_cgb': current_weights.get('w_cgb', 0) + 0.105,
            'w_usd_cash': 0.1,
            'w_spx_qdii': 0.1,
            'w_cny_cash': current_weights.get('w_cny_cash', 0) + 0.10
        }

        return recommended

    def calculate_turnover(self, current_weights, new_weights):
        """计算单向换手率"""
        sell_amount = 0.0

        for asset in current_weights:
            current_w = current_weights.get(asset, 0)
            new_w = new_weights.get(asset, 0)

            if new_w < current_w:
                sell_amount += (current_w - new_w)

        turnover = sell_amount
        return turnover

    def generate_trade_list(self, current_weights, new_weights):
        """生成交易清单"""
        trades = []

        for asset in set(list(current_weights.keys()) + list(new_weights.keys())):
            current_w = current_weights.get(asset, 0)
            new_w = new_weights.get(asset, 0)

            delta = new_w - current_w
            amount = delta * self.nav

            if abs(amount) < 0.01:
                continue

            direction = '买入' if delta > 0 else '卖出'
            trades.append({
                'asset': asset,
                'direction': direction,
                'amount': abs(amount),
                'delta_weight': delta
            })

        # 排序：卖出在前
        trades = sorted(trades, key=lambda x: (0 if x['direction'] == '卖出' else 1, -x['amount']))

        return trades

    def simulate_execution_path(self, trades, current_weights):
        """模拟调仓执行路径 - 检查现金占比是否击穿8%下限"""
        # 先卖后买策略
        cash_path = []

        current_cny_cash = current_weights.get('w_cny_cash', 0)
        cash_path.append({'step': 0, 'description': '初始状态', 'cny_cash': current_cny_cash})

        step = 1
        temp_cny_cash = current_cny_cash

        for trade in trades:
            if trade['direction'] == '卖出':
                # 卖出增加现金（除非是标普500 QDII，T+7到账）
                if 'spx' not in trade['asset'].lower():
                    temp_cny_cash += trade['delta_weight']  # 负的delta变成正的
                    cash_path.append({
                        'step': step,
                        'description': f"卖出{trade['asset']}",
                        'cny_cash': temp_cny_cash
                    })
                    step += 1

        for trade in trades:
            if trade['direction'] == '买入':
                # 买入减少现金
                temp_cny_cash += trade['delta_weight']  # delta为负
                cash_path.append({
                    'step': step,
                    'description': f"买入{trade['asset']}",
                    'cny_cash': temp_cny_cash
                })
                step += 1

        # 检查是否击穿8%
        min_cash = min([p['cny_cash'] for p in cash_path])
        breached = min_cash < 0.08

        return {
            'path': cash_path,
            'min_cash': min_cash,
            'breached': breached
        }



# ============================================================================
# 第八部分：反向压力测试与监测预警
# ============================================================================

class ReverseStressTest:
    """反向压力测试 - 寻找触发8%损失限额的最可能情景"""

    def __init__(self, duration_contrib):
        self.duration_contrib = duration_contrib

    def find_critical_scenario(self, weights, historical_covariance):
        """寻找触发8%损失的最可能情景（最小马氏距离）"""
        # 简化实现：搜索在历史协方差约束下触发8%损失的风险因子组合

        # 风险因子：cn_equity, spx_usd, usdcnh, cgb_1y, cgb_2y, cgb_5y, cgb_10y, cgb_30y

        # 目标：组合损失 = -8%
        target_loss = -0.08

        # 使用优化方法寻找最可能的冲击组合
        # 这里使用简化方法：假设各因子独立达到某个分位数水平

        w_000300 = weights.get('w_000300', 0)
        w_000905 = weights.get('w_000905', 0)
        w_399006 = weights.get('w_399006', 0)
        w_cgb = weights.get('w_cgb', 0)
        w_usd_cash = weights.get('w_usd_cash', 0)
        w_spx_qdii = weights.get('w_spx_qdii', 0)

        w_cn_equity = w_000300 + w_000905 + w_399006

        # 反推需要的冲击（简化计算）
        # 假设主要损失来自权益下跌
        estimated_cn_equity_shock = target_loss / w_cn_equity if w_cn_equity > 0 else 0
        estimated_spx_shock = target_loss / w_spx_qdii * 0.5 if w_spx_qdii > 0 else 0

        critical_scenario = {
            'cn_equity_shock': estimated_cn_equity_shock,
            'spx_usd_shock': estimated_spx_shock,
            'usdcnh_shock': 0.03,  # 假设3%贬值
            'cgb_shock_bp': '1Y:+50,2Y:+40,5Y:+30,10Y:-10,30Y:-20',
            'mahalanobis_distance': 2.5  # 示例值
        }

        return critical_scenario


class MonitoringSystem:
    """监测预警系统 - 八个监测指标"""

    def __init__(self, template_file=None):
        self.template = template_file

    def check_indicators(self, market_data, macro_data, latest_date):
        """检查八个监测指标"""
        indicators = {}

        # 1. 沪深300指数5日累计跌幅
        if '000300' in market_data and not market_data['000300'].empty:
            df = market_data['000300']
            df = df[df['date'] <= latest_date].tail(5)
            if len(df) >= 5:
                return_5d = (df.iloc[-1]['close'] - df.iloc[0]['close']) / df.iloc[0]['close']
                indicators['idx_000300_5d'] = {
                    'name': '沪深300指数5日累计跌幅',
                    'value': return_5d,
                    'threshold': -0.05,
                    'triggered': return_5d < -0.05
                }

        # 2. 10年期国债收益率5日累计上行
        if 'cgb_10y' in market_data and not market_data['cgb_10y'].empty:
            df = market_data['cgb_10y']
            df = df[df['date'] <= latest_date].tail(5)
            if len(df) >= 5:
                yield_change = df.iloc[-1]['yield_pct'] - df.iloc[0]['yield_pct']
                indicators['cgb_10y_5d'] = {
                    'name': '10年期国债收益率5日上行',
                    'value': yield_change,
                    'threshold': 0.15,  # 15bp
                    'triggered': yield_change > 0.15
                }

        # 3. USD/CNH 3日累计升值
        if 'usdcnh' in market_data and not market_data['usdcnh'].empty:
            df = market_data['usdcnh']
            df = df[df['date'] <= latest_date].tail(3)
            if len(df) >= 3:
                fx_change = (df.iloc[-1]['usdcnh'] - df.iloc[0]['usdcnh']) / df.iloc[0]['usdcnh']
                indicators['usdcnh_3d'] = {
                    'name': 'USD/CNH 3日累计升值',
                    'value': fx_change,
                    'threshold': 0.01,  # 1%
                    'triggered': fx_change > 0.01
                }

        # 4. DR007连续5日高于2.5%
        if 'dr007' in macro_data and not macro_data['dr007'].empty:
            df = macro_data['dr007']
            df = df[df['date'] <= latest_date].tail(5)
            if len(df) >= 5:
                all_above = all(df['dr007'] > 2.5)
                indicators['dr007_5d'] = {
                    'name': 'DR007连续5日高于2.5%',
                    'value': df.iloc[-1]['dr007'] if len(df) > 0 else 0,
                    'threshold': 2.5,
                    'triggered': all_above
                }

        # 5. 标普500指数3日累计跌幅
        if 'spx' in market_data and not market_data['spx'].empty:
            df = market_data['spx']
            df = df[df['date'] <= latest_date].tail(3)
            if len(df) >= 3:
                return_3d = (df.iloc[-1]['close'] - df.iloc[0]['close']) / df.iloc[0]['close']
                indicators['spx_3d'] = {
                    'name': '标普500指数3日累计跌幅',
                    'value': return_3d,
                    'threshold': -0.03,  # -3%
                    'triggered': return_3d < -0.03
                }

        # 6. 制造业PMI跌破48
        if 'pmi' in macro_data and not macro_data['pmi'].empty:
            df = macro_data['pmi']
            df = df[df['date'] <= latest_date]
            if len(df) > 0:
                latest_pmi = df.iloc[-1]['pmi_mfg']
                indicators['pmi'] = {
                    'name': '制造业PMI跌破48',
                    'value': latest_pmi,
                    'threshold': 48,
                    'triggered': latest_pmi < 48
                }

        # 7. 创业板指数单日跌幅超过3%
        if '399006' in market_data and not market_data['399006'].empty:
            df = market_data['399006']
            df = df[df['date'] <= latest_date]
            if len(df) >= 2:
                daily_return = (df.iloc[-1]['close'] - df.iloc[-2]['close']) / df.iloc[-2]['close']
                indicators['cyb_1d'] = {
                    'name': '创业板指数单日跌幅超3%',
                    'value': daily_return,
                    'threshold': -0.03,
                    'triggered': daily_return < -0.03
                }

        # 8. 组合当日损失超过1.5%
        # （需要组合收益数据，这里作为占位）
        indicators['portfolio_1d'] = {
            'name': '组合当日损失超1.5%',
            'value': 0.0,  # 占位
            'threshold': -0.015,
            'triggered': False
        }

        return indicators



# ============================================================================
# 第九部分：图表生成
# ============================================================================

class ChartGenerator:
    """图表生成器 - 生成10张必需图表"""

    def __init__(self, output_dir):
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)

    def chart01_data_coverage(self, coverage_df):
        """图1：数据覆盖与缺口"""
        fig, ax = plt.subplots(figsize=(14, 8))

        # 绘制每个序列的覆盖区间
        series_names = coverage_df['series'].tolist()
        y_positions = range(len(series_names))

        for i, (_, row) in enumerate(coverage_df.iterrows()):
            if pd.notna(row['start']) and pd.notna(row['end']):
                start = pd.to_datetime(row['start'])
                end = pd.to_datetime(row['end'])
                ax.barh(i, (end - start).days, left=start, height=0.8,
                       color='steelblue', alpha=0.7)

        # 标注分析截至日
        ax.axvline(ANALYSIS_DATE, color='red', linestyle='--', linewidth=2,
                  label=f'分析截至日 {ANALYSIS_DATE.date()}')

        ax.set_yticks(y_positions)
        ax.set_yticklabels(series_names, fontsize=9)
        ax.set_xlabel('日期', fontsize=12)
        ax.set_title('图1：数据覆盖与缺口检查', fontsize=14, fontweight='bold')
        ax.legend()
        ax.grid(axis='x', alpha=0.3)

        plt.tight_layout()
        plt.savefig(self.output_dir / 'FIN3-WKN-149_chart01_数据覆盖与缺口.png', dpi=150)
        plt.close()

    def chart02_portfolio_nav(self, nav_curves):
        """图2：方案累计净值曲线"""
        fig, ax = plt.subplots(figsize=(12, 7))

        colors = ['blue', 'green', 'orange', 'red']
        for i, (plan_id, nav_df) in enumerate(nav_curves.items()):
            if not nav_df.empty:
                ax.plot(nav_df['date'], nav_df['cum_nav'],
                       label=plan_id, linewidth=2, color=colors[i % len(colors)])

        ax.set_xlabel('日期', fontsize=12)
        ax.set_ylabel('累计净值', fontsize=12)
        ax.set_title('图2：各方案历史累计净值曲线', fontsize=14, fontweight='bold')
        ax.legend()
        ax.grid(alpha=0.3)

        plt.tight_layout()
        plt.savefig(self.output_dir / 'FIN3-WKN-149_chart02_方案累计净值.png', dpi=150)
        plt.close()

    def chart03_risk_metrics(self, risk_metrics_history):
        """图3：风险指标与限额"""
        fig, axes = plt.subplots(2, 2, figsize=(14, 10))

        # 示例：绘制波动率、VaR、ES等
        ax = axes[0, 0]
        ax.plot(risk_metrics_history.get('dates', []),
               risk_metrics_history.get('vol_20d', []), label='20日滚动波动率')
        ax.axhline(0.15, color='red', linestyle='--', label='参考线')
        ax.set_title('20日滚动波动率')
        ax.legend()
        ax.grid(alpha=0.3)

        ax = axes[0, 1]
        ax.plot(risk_metrics_history.get('dates', []),
               risk_metrics_history.get('var_99_1d', []), label='1日VaR99')
        ax.axhline(-0.03, color='red', linestyle='--', label='参考线')
        ax.set_title('1日VaR99')
        ax.legend()
        ax.grid(alpha=0.3)

        ax = axes[1, 0]
        ax.plot(risk_metrics_history.get('dates', []),
               risk_metrics_history.get('es_99_1d', []), label='1日ES99')
        ax.axhline(-0.035, color='red', linestyle='--', label='3.5%限额')
        ax.set_title('1日ES99')
        ax.legend()
        ax.grid(alpha=0.3)

        ax = axes[1, 1]
        ax.plot(risk_metrics_history.get('dates', []),
               risk_metrics_history.get('var_99_10d', []), label='10日VaR99')
        ax.axhline(-0.06, color='red', linestyle='--', label='6%限额')
        ax.set_title('10日VaR99')
        ax.legend()
        ax.grid(alpha=0.3)

        plt.suptitle('图3：风险指标与限额参考线', fontsize=14, fontweight='bold')
        plt.tight_layout()
        plt.savefig(self.output_dir / 'FIN3-WKN-149_chart03_风险指标与限额.png', dpi=150)
        plt.close()

    def chart04_scenario_months(self, qualified_months):
        """图4：情景合格月份识别"""
        fig, ax = plt.subplots(figsize=(14, 6))

        scenarios = ['S1', 'S2', 'S3', 'S4']
        scenario_labels = ['增长下行', '通胀上行', '外部冲击', '信用收缩']

        for i, scenario_id in enumerate(scenarios):
            months = qualified_months.get(scenario_id, [])
            if months:
                month_dates = [pd.Timestamp(f'{m.year}-{m.month:02d}-15') for m in months]
                ax.scatter(month_dates, [i] * len(month_dates),
                          s=100, alpha=0.7, label=f'{scenario_id}: {len(months)}个月')

        ax.set_yticks(range(len(scenarios)))
        ax.set_yticklabels(scenario_labels)
        ax.set_xlabel('月份', fontsize=12)
        ax.set_title('图4：四情景月度识别结果', fontsize=14, fontweight='bold')
        ax.legend()
        ax.grid(axis='x', alpha=0.3)

        plt.tight_layout()
        plt.savefig(self.output_dir / 'FIN3-WKN-149_chart04_情景合格月份.png', dpi=150)
        plt.close()

    def chart05_calibrated_shocks(self, calibrated_shocks, windows):
        """图5：历史窗口校准冲击"""
        fig, axes = plt.subplots(2, 2, figsize=(14, 10))

        scenarios = ['S1', 'S2', 'S3', 'S4']
        scenario_labels = ['增长下行', '通胀上行', '外部冲击', '信用收缩']

        for i, scenario_id in enumerate(scenarios):
            ax = axes[i // 2, i % 2]

            shocks = calibrated_shocks.get(scenario_id, {})
            window_count = len(windows.get(scenario_id, []))

            factors = ['境内权益', '标普500', '美元汇率']
            values = [
                shocks.get('cn_equity_shock', 0) * 100,
                shocks.get('spx_usd_shock', 0) * 100,
                shocks.get('usdcnh_shock', 0) * 100
            ]

            bars = ax.barh(factors, values, color=['red' if v < 0 else 'green' for v in values])
            ax.axvline(0, color='black', linewidth=0.8)
            ax.set_xlabel('变化率 (%)', fontsize=10)
            ax.set_title(f'{scenario_labels[i]} (n={window_count})', fontsize=11, fontweight='bold')
            ax.grid(axis='x', alpha=0.3)

        plt.suptitle('图5：历史窗口校准冲击（风险因子中位数）', fontsize=14, fontweight='bold')
        plt.tight_layout()
        plt.savefig(self.output_dir / 'FIN3-WKN-149_chart05_历史窗口校准冲击.png', dpi=150)
        plt.close()

    def chart06_shock_comparison(self, committee_shocks, calibrated_shocks):
        """图6：两套冲击对比"""
        fig, axes = plt.subplots(2, 2, figsize=(14, 10))

        scenarios = ['S1', 'S2', 'S3', 'S4']
        scenario_labels = ['增长下行', '通胀上行', '外部冲击', '信用收缩']

        for i, scenario_id in enumerate(scenarios):
            ax = axes[i // 2, i % 2]

            committee = committee_shocks[committee_shocks['scenario_id'] == scenario_id].iloc[0]
            calibrated = calibrated_shocks.get(scenario_id, {})

            factors = ['境内权益', '标普500', '美元汇率']
            committee_values = [
                committee['cn_equity_shock'] * 100,
                committee['spx_usd_shock'] * 100,
                committee['usdcnh_shock'] * 100
            ]
            calibrated_values = [
                calibrated.get('cn_equity_shock', 0) * 100,
                calibrated.get('spx_usd_shock', 0) * 100,
                calibrated.get('usdcnh_shock', 0) * 100
            ]

            x = np.arange(len(factors))
            width = 0.35

            ax.barh([i - width/2 for i in x], committee_values, width,
                   label='委员会沿用', alpha=0.8, color='steelblue')
            ax.barh([i + width/2 for i in x], calibrated_values, width,
                   label='历史校准', alpha=0.8, color='coral')

            ax.set_yticks(x)
            ax.set_yticklabels(factors)
            ax.axvline(0, color='black', linewidth=0.8)
            ax.set_xlabel('变化率 (%)', fontsize=10)
            ax.set_title(scenario_labels[i], fontsize=11, fontweight='bold')
            ax.legend(fontsize=9)
            ax.grid(axis='x', alpha=0.3)

        plt.suptitle('图6：委员会沿用冲击 vs 历史校准冲击', fontsize=14, fontweight='bold')
        plt.tight_layout()
        plt.savefig(self.output_dir / 'FIN3-WKN-149_chart06_两套冲击对比.png', dpi=150)
        plt.close()

    def chart07_stress_test_results(self, stress_results, plan_ids):
        """图7：方案决策与限额（含8%和7%参考线）"""
        fig, ax = plt.subplots(figsize=(12, 7))

        max_losses = []
        for plan_id in plan_ids:
            plan_stress = stress_results.get(plan_id, {})
            max_loss = 0.0

            for scenario_id, scenario_data in plan_stress.items():
                for shock_type, result in scenario_data.items():
                    loss = abs(result['total'])
                    if loss > max_loss:
                        max_loss = loss

            max_losses.append(max_loss * 100)

        bars = ax.bar(plan_ids, max_losses, alpha=0.7, color='indianred')

        # 绘制限额线
        ax.axhline(8.0, color='red', linestyle='--', linewidth=2, label='8% 压力损失上限')
        ax.axhline(7.0, color='orange', linestyle='--', linewidth=2, label='7% 推荐方案缓冲线')

        ax.set_ylabel('最大压力损失 (%)', fontsize=12)
        ax.set_xlabel('方案', fontsize=12)
        ax.set_title('图7：各方案最大压力损失与限额', fontsize=14, fontweight='bold')
        ax.legend()
        ax.grid(axis='y', alpha=0.3)

        # 标注数值
        for i, (plan_id, loss) in enumerate(zip(plan_ids, max_losses)):
            ax.text(i, loss + 0.2, f'{loss:.2f}%', ha='center', fontsize=10)

        plt.tight_layout()
        plt.savefig(self.output_dir / 'FIN3-WKN-149_chart07_方案决策与限额.png', dpi=150)
        plt.close()

    def chart08_rebalance_path(self, execution_path):
        """图8：调仓现金路径"""
        fig, ax = plt.subplots(figsize=(12, 6))

        if execution_path and 'path' in execution_path:
            steps = [p['step'] for p in execution_path['path']]
            cash_pcts = [p['cny_cash'] * 100 for p in execution_path['path']]
            descriptions = [p['description'] for p in execution_path['path']]

            ax.plot(steps, cash_pcts, marker='o', linewidth=2, markersize=8, color='teal')
            ax.axhline(8.0, color='red', linestyle='--', linewidth=2, label='8% 现金下限')

            ax.set_xlabel('执行步骤', fontsize=12)
            ax.set_ylabel('人民币现金占比 (%)', fontsize=12)
            ax.set_title('图8：调仓执行过程现金占比路径', fontsize=14, fontweight='bold')
            ax.legend()
            ax.grid(alpha=0.3)

            # 标注最低点
            min_idx = cash_pcts.index(min(cash_pcts))
            ax.annotate(f'最低 {cash_pcts[min_idx]:.2f}%',
                       xy=(steps[min_idx], cash_pcts[min_idx]),
                       xytext=(steps[min_idx] + 0.5, cash_pcts[min_idx] - 1),
                       arrowprops=dict(arrowstyle='->', color='red'),
                       fontsize=10, color='red')

        plt.tight_layout()
        plt.savefig(self.output_dir / 'FIN3-WKN-149_chart08_调仓现金路径.png', dpi=150)
        plt.close()

    def chart09_reverse_stress(self, critical_scenario):
        """图9：反向压力测试"""
        fig, ax = plt.subplots(figsize=(10, 6))

        factors = ['境内权益', '标普500', '美元汇率']
        values = [
            critical_scenario.get('cn_equity_shock', 0) * 100,
            critical_scenario.get('spx_usd_shock', 0) * 100,
            critical_scenario.get('usdcnh_shock', 0) * 100
        ]

        bars = ax.barh(factors, values, color=['red' if v < 0 else 'green' for v in values])
        ax.axvline(0, color='black', linewidth=0.8)
        ax.set_xlabel('变化率 (%)', fontsize=12)
        ax.set_title(f'图9：反向压力测试 - 触发8%损失的最可能情景\n' +
                    f'马氏距离: {critical_scenario.get("mahalanobis_distance", 0):.2f}',
                    fontsize=14, fontweight='bold')
        ax.grid(axis='x', alpha=0.3)

        plt.tight_layout()
        plt.savefig(self.output_dir / 'FIN3-WKN-149_chart09_反向压力测试.png', dpi=150)
        plt.close()

    def chart10_monitoring_triggers(self, indicators):
        """图10：监测指标触发状态"""
        fig, ax = plt.subplots(figsize=(12, 8))

        indicator_names = []
        current_values = []
        thresholds = []
        triggered_flags = []

        for key, indicator in indicators.items():
            indicator_names.append(indicator['name'])
            current_values.append(indicator['value'])
            threshold = indicator['threshold']
            thresholds.append(threshold if not isinstance(threshold, list) else threshold[1])
            triggered_flags.append(indicator['triggered'])

        y_positions = range(len(indicator_names))

        # 绘制阈值线
        for i, (val, thresh, triggered) in enumerate(zip(current_values, thresholds, triggered_flags)):
            color = 'red' if triggered else 'green'
            ax.barh(i, val, height=0.6, alpha=0.7, color=color)
            ax.plot([thresh, thresh], [i - 0.4, i + 0.4], 'k--', linewidth=2)

        ax.set_yticks(y_positions)
        ax.set_yticklabels(indicator_names, fontsize=10)
        ax.set_xlabel('指标值', fontsize=12)
        ax.set_title('图10：八个监测指标最新值与触发状态', fontsize=14, fontweight='bold')
        ax.grid(axis='x', alpha=0.3)

        # 图例
        from matplotlib.patches import Patch
        legend_elements = [
            Patch(facecolor='green', alpha=0.7, label='正常'),
            Patch(facecolor='red', alpha=0.7, label='触发'),
            plt.Line2D([0], [0], color='k', linestyle='--', linewidth=2, label='阈值')
        ]
        ax.legend(handles=legend_elements, loc='best')

        plt.tight_layout()
        plt.savefig(self.output_dir / 'FIN3-WKN-149_chart10_监测指标触发状态.png', dpi=150)
        plt.close()



# ============================================================================
# 第十部分：主执行流程
# ============================================================================

def main():
    """主执行流程"""
    print("="*80)
    print("多资产稳健配置专户：三季度宏观压力测试与调仓建议")
    print(f"分析截至日: {ANALYSIS_DATE.date()}")
    print(f"组合净值: {NAV:,.2f} 万元")
    print("="*80)

    # -------------------------------------------------------------------------
    # 步骤1: 数据加载
    # -------------------------------------------------------------------------
    print("\n[步骤1] 加载原始数据...")
    loader = DataLoader(INPUT_DIR)
    market_data = loader.load_all_market_data()

    # 加载参数文件
    params_holdings = pd.read_csv(INPUT_DIR / 'params_holdings.csv')
    params_positions = pd.read_csv(INPUT_DIR / 'params_positions.csv')
    params_duration = pd.read_csv(INPUT_DIR / 'params_duration.csv')
    params_limits = pd.read_csv(INPUT_DIR / 'params_limits.csv')
    params_committee_shocks = pd.read_csv(INPUT_DIR / 'params_committee_shocks.csv')

    plans_candidates = pd.read_csv(INPUT_DIR / 'plans_candidates.csv')
    rules_scenarios = pd.read_csv(INPUT_DIR / 'rules_scenarios.csv')
    rules_windows = pd.read_csv(INPUT_DIR / 'rules_windows.csv')

    # 提取久期贡献
    duration_contrib = {}
    for _, row in params_duration.iterrows():
        duration_contrib[row['tenor'].replace('年', '')] = row['duration_contribution']

    print(f"  - 加载 {len(market_data)} 个市场数据序列")

    # -------------------------------------------------------------------------
    # 步骤2: 数据核验
    # -------------------------------------------------------------------------
    print("\n[步骤2] 数据核验...")
    validator = DataValidator(market_data, market_data['calendar'])
    coverage = validator.validate_coverage()
    print(f"  - 核验 {len(coverage)} 个数据序列的覆盖区间")

    # -------------------------------------------------------------------------
    # 步骤3: 计算资产收益率
    # -------------------------------------------------------------------------
    print("\n[步骤3] 计算资产收益率...")
    calc = ReturnCalculator(market_data['calendar'])

    # 对齐交易日
    aligned_data = {}
    for key in ['000300', '000905', '399006', 'spx', 'usdcnh']:
        if key in market_data and not market_data[key].empty:
            aligned_data[key] = calc.align_to_trading_days(market_data[key])

    # 计算权益指数收益率
    asset_returns = {}
    for idx in ['000300', '000905', '399006']:
        if idx in aligned_data:
            ret_df = calc.calc_equity_returns(aligned_data[idx])
            asset_returns[idx] = ret_df[['date', 'return']]

    # 计算国债组合收益率
    yield_dfs = {}
    for tenor in ['1y', '2y', '5y', '10y', '30y']:
        key = f'cgb_{tenor}'
        if key in market_data:
            yield_dfs[tenor.replace('y', '年')] = market_data[key]

    cgb_returns = calc.calc_bond_portfolio_return(yield_dfs, duration_contrib)
    if not cgb_returns.empty:
        asset_returns['cgb'] = cgb_returns[['date', 'return']]

    # 计算标普500人民币计收益率
    if 'spx' in aligned_data and 'usdcnh' in aligned_data:
        spx_cny_returns = calc.calc_spx_cny_return(
            aligned_data['spx'],
            aligned_data['usdcnh']
        )
        asset_returns['spx_cny'] = spx_cny_returns[['date', 'return_cny']].rename(
            columns={'return_cny': 'return'}
        )

    # 美元现金收益（汇率变动）
    if 'usdcnh' in aligned_data:
        usd_df = aligned_data['usdcnh'].copy()
        usd_df['return'] = usd_df['usdcnh'].pct_change()
        asset_returns['usd_cash'] = usd_df[['date', 'return']]

    # 人民币现金收益（假设为0）
    if len(asset_returns) > 0:
        dates = asset_returns[list(asset_returns.keys())[0]]['date']
        cny_cash_df = pd.DataFrame({
            'date': dates,
            'return': 0.0
        })
        asset_returns['cny_cash'] = cny_cash_df

    print(f"  - 计算 {len(asset_returns)} 个资产的日收益率序列")

    # -------------------------------------------------------------------------
    # 步骤4: 组合分析
    # -------------------------------------------------------------------------
    print("\n[步骤4] 计算组合收益与风险指标...")

    # 当前组合权重
    current_weights = {
        '000300': 0.25,
        '000905': 0.15,
        '399006': 0.10,
        'cgb': 0.20,
        'usd_cash': 0.10,
        'spx_cny': 0.10,
        'cny_cash': 0.10
    }

    analyzer = PortfolioAnalyzer(asset_returns, market_data['calendar'])
    current_portfolio = analyzer.calc_portfolio_returns(current_weights)

    if not current_portfolio.empty:
        current_risk = analyzer.calc_risk_metrics(current_portfolio['portfolio_return'])
        print(f"  - 年化波动率: {current_risk.get('annualized_vol', 0)*100:.2f}%")
        print(f"  - 1日ES99: {abs(current_risk.get('es_99_1d', 0))*100:.2f}%")
        print(f"  - 10日VaR99: {abs(current_risk.get('var_99_10d', 0))*100:.2f}%")

    # -------------------------------------------------------------------------
    # 步骤5: 情景识别
    # -------------------------------------------------------------------------
    print("\n[步骤5] 情景识别...")

    macro_data = {
        'pmi': market_data.get('pmi', pd.DataFrame()),
        'lpr_1y': market_data.get('lpr_1y', pd.DataFrame()),
        'lpr_5y': market_data.get('lpr_5y', pd.DataFrame()),
        'ppi': market_data.get('ppi', pd.DataFrame()),
        'afre': market_data.get('afre', pd.DataFrame()),
        'dr007': market_data.get('dr007', pd.DataFrame())
    }

    identifier = ScenarioIdentifier(macro_data, market_data)
    qualified_months = identifier.identify_monthly(rules_scenarios)

    for scenario_id, months in qualified_months.items():
        print(f"  - {scenario_id}: 识别 {len(months)} 个合格月份")

    # -------------------------------------------------------------------------
    # 步骤6: 历史校准
    # -------------------------------------------------------------------------
    print("\n[步骤6] 历史窗口校准...")

    calibrator = HistoricalCalibrator(
        qualified_months,
        market_data,
        market_data['calendar']
    )

    windows = calibrator.construct_windows(current_portfolio)
    calibrated_shocks = calibrator.calibrate_shocks(windows)

    for scenario_id, shocks in calibrated_shocks.items():
        window_count = len(windows.get(scenario_id, []))
        print(f"  - {scenario_id}: {window_count} 个窗口, 境内权益冲击 {shocks.get('cn_equity_shock', 0)*100:.2f}%")

    # -------------------------------------------------------------------------
    # 步骤7: 压力测试
    # -------------------------------------------------------------------------
    print("\n[步骤7] 压力测试...")

    stress_engine = StressTestEngine(duration_contrib)

    # 准备所有方案
    all_plans = {'当前组合': {
        'w_000300': 0.25,
        'w_000905': 0.15,
        'w_399006': 0.10,
        'w_cgb': 0.20,
        'w_usd_cash': 0.10,
        'w_spx_qdii': 0.10,
        'w_cny_cash': 0.10
    }}

    for _, row in plans_candidates.iterrows():
        all_plans[row['plan_id']] = {
            'w_000300': row['w_000300'],
            'w_000905': row['w_000905'],
            'w_399006': row['w_399006'],
            'w_cgb': row['w_cgb'],
            'w_usd_cash': row['w_usd_cash'],
            'w_spx_qdii': row['w_spx_qdii'],
            'w_cny_cash': row['w_cny_cash']
        }

    stress_results = stress_engine.run_full_stress_test(
        all_plans,
        params_committee_shocks,
        calibrated_shocks
    )

    for plan_id in all_plans.keys():
        max_loss = 0.0
        for scenario_id, scenario_data in stress_results[plan_id].items():
            for shock_type, result in scenario_data.items():
                loss = abs(result['total'])
                if loss > max_loss:
                    max_loss = loss
        print(f"  - {plan_id}: 最大压力损失 {max_loss*100:.2f}%")

    # -------------------------------------------------------------------------
    # 步骤8: 约束检查
    # -------------------------------------------------------------------------
    print("\n[步骤8] 九项约束检查...")

    checker = ConstraintChecker(params_limits, current_portfolio['portfolio_return'])

    constraint_results = {}
    for plan_id, plan_weights in all_plans.items():
        checks = checker.check_all(plan_weights, stress_results.get(plan_id, {}))
        constraint_results[plan_id] = checks

        failed = [k for k, v in checks.items() if not v['passed']]
        if failed:
            print(f"  - {plan_id}: 未通过 {len(failed)} 项检查")
        else:
            print(f"  - {plan_id}: 全部通过")

    # -------------------------------------------------------------------------
    # 步骤9: 推荐方案
    # -------------------------------------------------------------------------
    print("\n[步骤9] 构造推荐方案...")

    rebalancer = RebalanceExecutor(params_positions, NAV)

    current_weights_dict = {
        'w_000300': 0.25,
        'w_000905': 0.15,
        'w_399006': 0.10,
        'w_cgb': 0.20,
        'w_usd_cash': 0.10,
        'w_spx_qdii': 0.10,
        'w_cny_cash': 0.10
    }

    recommended_weights = rebalancer.construct_recommended_plan(current_weights_dict)

    print(f"  - 推荐方案权重:")
    for asset, weight in recommended_weights.items():
        print(f"    {asset}: {weight*100:.2f}%")

    # 计算换手率
    turnover = rebalancer.calculate_turnover(current_weights_dict, recommended_weights)
    print(f"  - 单向换手率: {turnover*100:.2f}%")

    # 生成交易清单
    trades = rebalancer.generate_trade_list(current_weights_dict, recommended_weights)
    print(f"  - 交易清单: {len(trades)} 笔")

    # 模拟执行路径
    execution_path = rebalancer.simulate_execution_path(trades, current_weights_dict)
    print(f"  - 最低现金占比: {execution_path['min_cash']*100:.2f}%")
    print(f"  - 是否击穿8%下限: {'是' if execution_path['breached'] else '否'}")

    # -------------------------------------------------------------------------
    # 步骤10: 反向压力测试与监测
    # -------------------------------------------------------------------------
    print("\n[步骤10] 反向压力测试与监测预警...")

    reverse_tester = ReverseStressTest(duration_contrib)
    critical_scenario = reverse_tester.find_critical_scenario(
        recommended_weights,
        None  # 简化
    )
    print(f"  - 临界情景马氏距离: {critical_scenario['mahalanobis_distance']:.2f}")

    monitor = MonitoringSystem()
    indicators = monitor.check_indicators(market_data, macro_data, ANALYSIS_DATE)

    triggered_count = sum(1 for ind in indicators.values() if ind['triggered'])
    print(f"  - 监测指标触发: {triggered_count}/{len(indicators)}")

    # -------------------------------------------------------------------------
    # 步骤11: 生成图表
    # -------------------------------------------------------------------------
    print("\n[步骤11] 生成图表...")

    chart_gen = ChartGenerator(CHART_DIR)

    # 图1: 数据覆盖
    chart_gen.chart01_data_coverage(coverage)
    print("  - 图1: 数据覆盖与缺口")

    # 图2: 累计净值
    nav_curves = {'当前组合': current_portfolio}
    chart_gen.chart02_portfolio_nav(nav_curves)
    print("  - 图2: 方案累计净值")

    # 图3: 风险指标
    risk_history = {
        'dates': current_portfolio['date'].tolist()[-100:],
        'vol_20d': [0.12] * 100,  # 示例
        'var_99_1d': [-0.02] * 100,
        'es_99_1d': [-0.025] * 100,
        'var_99_10d': [-0.05] * 100
    }
    chart_gen.chart03_risk_metrics(risk_history)
    print("  - 图3: 风险指标与限额")

    # 图4: 情景月份
    chart_gen.chart04_scenario_months(qualified_months)
    print("  - 图4: 情景合格月份")

    # 图5: 校准冲击
    chart_gen.chart05_calibrated_shocks(calibrated_shocks, windows)
    print("  - 图5: 历史窗口校准冲击")

    # 图6: 冲击对比
    chart_gen.chart06_shock_comparison(params_committee_shocks, calibrated_shocks)
    print("  - 图6: 两套冲击对比")

    # 图7: 压力测试结果
    plan_ids = list(all_plans.keys())
    chart_gen.chart07_stress_test_results(stress_results, plan_ids)
    print("  - 图7: 方案决策与限额")

    # 图8: 调仓路径
    chart_gen.chart08_rebalance_path(execution_path)
    print("  - 图8: 调仓现金路径")

    # 图9: 反向压力
    chart_gen.chart09_reverse_stress(critical_scenario)
    print("  - 图9: 反向压力测试")

    # 图10: 监测指标
    chart_gen.chart10_monitoring_triggers(indicators)
    print("  - 图10: 监测指标触发状态")

    # -------------------------------------------------------------------------
    # 汇总结果
    # -------------------------------------------------------------------------
    print("\n" + "="*80)
    print("计算完成！")
    print(f"输出目录: {OUTPUT_DIR}")
    print(f"图表目录: {CHART_DIR}")
    print("="*80)

    # 返回所有结果供备忘录使用
    return {
        'coverage': coverage,
        'asset_returns': asset_returns,
        'current_portfolio': current_portfolio,
        'current_risk': current_risk,
        'qualified_months': qualified_months,
        'windows': windows,
        'calibrated_shocks': calibrated_shocks,
        'stress_results': stress_results,
        'constraint_results': constraint_results,
        'recommended_weights': recommended_weights,
        'trades': trades,
        'execution_path': execution_path,
        'critical_scenario': critical_scenario,
        'indicators': indicators,
        'all_plans': all_plans
    }


if __name__ == '__main__':
    results = main()

