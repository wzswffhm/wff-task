from pathlib import Path
import re
import warnings
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib import font_manager

warnings.filterwarnings("ignore")
ROOT = Path(__file__).resolve().parent.parent
IN = ROOT / "input_files"
OUT = Path(__file__).resolve().parent
CHART = OUT / "FIN3-WKN-149_charts"
ASOF = pd.Timestamp("2026-09-15")
PORTFOLIO_VALUE = 10000.0

# All calculations start from the source files; no result values are embedded here.
def read_csv(name, **kwargs):
    return pd.read_csv(IN / name, **kwargs)

def pct(x):
    return f"{x * 100:.2f}%" if pd.notna(x) else "N/A"

def bp(x):
    return f"{x:.2f}bp" if pd.notna(x) else "N/A"

def money(x):
    return f"{x:,.2f}" if pd.notna(x) else "N/A"

def signed_pct(x):
    return f"{x * 100:+.2f}%" if pd.notna(x) else "N/A"

def signed_bp(x):
    return f"{x:+.2f}bp" if pd.notna(x) else "N/A"

def md_table(df):
    d = df.reset_index() if df.index.name is not None else df.copy()
    d = d.replace({np.nan: "N/A"})
    headers = [str(x) for x in d.columns]
    lines = ["| " + " | ".join(headers) + " |", "| " + " | ".join(["---"] * len(headers)) + " |"]
    for row in d.itertuples(index=False, name=None):
        lines.append("| " + " | ".join(str(x).replace("|", "\\|") for x in row) + " |")
    return "\n".join(lines)

def parse_num(v):
    if pd.isna(v):
        return np.nan
    s = str(v).strip().replace("%", "")
    if not s:
        return np.nan
    try:
        return float(s)
    except ValueError:
        return np.nan

def load_series(files, date_col="date"):
    frames = []
    for f in files:
        d = read_csv(f)
        d[date_col] = pd.to_datetime(d[date_col])
        frames.append(d)
    d = pd.concat(frames, ignore_index=True).sort_values(date_col)
    d = d.drop_duplicates(date_col, keep="last").set_index(date_col)
    return d

def value_series(files, value_col):
    d = load_series(files)
    s = pd.to_numeric(d[value_col], errors="coerce")
    s.name = value_col
    return s

# 1. Data validation precedes all return calculations.
calendar = read_csv("snapshot_trade_calendar.csv")
calendar["date"] = pd.to_datetime(calendar["date"])
sse_days = pd.DatetimeIndex(calendar.loc[calendar["is_trading_day"].eq(1), "date"].sort_values())
sse_days = sse_days[sse_days <= ASOF]

index_files = {
    "沪深300": ["snapshot_000300SH_seg1.csv", "snapshot_000300SH_seg2.csv"],
    "中证500": ["snapshot_000905SH_seg1.csv", "snapshot_000905SH_seg2.csv"],
    "创业板": ["snapshot_399006SZ_seg1.csv", "snapshot_399006SZ_seg2.csv"],
}
raw_indices = {k: load_series(v) for k, v in index_files.items()}
indices = {}
index_off_calendar = {}
for name, d in raw_indices.items():
    off = d.index.difference(sse_days)
    index_off_calendar[name] = off
    d = d.loc[d.index.intersection(sse_days)].copy()
    indices[name] = d

fx = value_series(["snapshot_usdcnh_seg1.csv", "snapshot_usdcnh_seg2.csv"], "usdcnh")
spx = value_series(["snapshot_spx.csv"], "close")
shibor = load_series(["snapshot_shibor_seg1.csv", "snapshot_shibor_seg2.csv"])
dr007 = value_series(["snapshot_dr007.csv"], "dr007")
ust10 = value_series(["snapshot_ust_10y.csv"], "yield_pct")
cgb = {f"{y}年": value_series([f"snapshot_cgb_yield_{y}y.csv"], "yield_pct") for y in [1, 2, 5, 10, 30]}
pmi = value_series(["snapshot_pmi_manufacturing.csv"], "pmi_mfg")
ppi = value_series(["snapshot_ppi_yoy.csv"], "ppi_yoy")
afre = value_series(["snapshot_afre_stock.csv"], "afre_stock")
lpr1 = value_series(["snapshot_lpr_1y.csv"], "lpr_1y")
lpr5 = value_series(["snapshot_lpr_5y.csv"], "lpr_5y")

manifest = read_csv("snapshot_data_manifest.csv")
manifest_by_file = manifest.set_index("file").to_dict("index")

def manifest_status(files):
    vals = [manifest_by_file.get(f, {}).get("possible_truncation", np.nan) for f in files]
    vals = [str(x).strip() for x in vals if pd.notna(x) and str(x).strip()]
    return "; ".join(vals) if vals else "未标注"

def coverage_row(name, files, series, kind="daily", structural="无"):
    raw = load_series(files)
    if kind == "daily":
        expected = sse_days[(sse_days >= raw.index.min()) & (sse_days <= raw.index.max())]
        actual = raw.index.intersection(expected)
        missing = len(expected.difference(actual))
    elif kind == "monthly":
        expected = pd.date_range(raw.index.min().to_period("M").to_timestamp(), raw.index.max().to_period("M").to_timestamp(), freq="MS")
        actual_months = pd.DatetimeIndex(raw.index.to_period("M").drop_duplicates().to_timestamp())
        missing = len(expected.difference(actual_months))
    else:
        missing = np.nan
    return {
        "序列": name,
        "实际覆盖": f"{raw.index.min().date()}—{raw.index.max().date()}",
        "原始行数": len(raw),
        "缺口数": int(missing) if pd.notna(missing) else "N/A",
        "截断标记": manifest_status(files),
        "结构性空值/处理": structural,
    }

coverage = []
for name, files in index_files.items():
    coverage.append(coverage_row(name, files, indices[name], "daily", "三份 seg1 首日 pre_close 为空；仅剔除不在上交所交易日历的记录"))
coverage += [
    coverage_row("USD/CNH", ["snapshot_usdcnh_seg1.csv", "snapshot_usdcnh_seg2.csv"], fx, "daily", "按估值日对齐并前向填充；首个有效值前不填充"),
    coverage_row("标普500", ["snapshot_spx.csv"], spx, "daily", "按估值日对齐并前向填充；首个有效值前不填充"),
]
for y in [1, 2, 5, 10, 30]:
    coverage.append(coverage_row(f"国债{y}年", [f"snapshot_cgb_yield_{y}y.csv"], cgb[f"{y}年"], "daily", "按估值日对齐并前向填充；上游未提供的尾部日期不外推"))
coverage += [
    coverage_row("DR007", ["snapshot_dr007.csv"], dr007, "daily", "按估值日对齐并前向填充"),
    coverage_row("美国10年国债", ["snapshot_ust_10y.csv"], ust10, "daily", "按自身交易日序列取值；监测不强行延展"),
    coverage_row("PMI", ["snapshot_pmi_manufacturing.csv"], pmi, "monthly", "月度序列；不向前填充"),
    coverage_row("PPI", ["snapshot_ppi_yoy.csv"], ppi, "monthly", "月度序列；不向前填充"),
    coverage_row("社融存量", ["snapshot_afre_stock.csv"], afre, "monthly", "由水平值计算同比；不将缺月当作零"),
    coverage_row("LPR 1年", ["snapshot_lpr_1y.csv"], lpr1, "monthly", "月度序列；不向前填充"),
    coverage_row("LPR 5年", ["snapshot_lpr_5y.csv"], lpr5, "monthly", "2018-01至2019-07为空的结构性历史缺失，不填充、不用于下调判定"),
]

# 2. Price alignment and daily asset returns.
valuation_days = sse_days[sse_days >= min(min(d.index) for d in indices.values())]
price = pd.DataFrame(index=valuation_days)
for name, d in indices.items():
    price[name] = d["close"].reindex(valuation_days).ffill()
price["USD/CNH"] = fx.reindex(valuation_days).ffill()
price["SPX"] = spx.reindex(valuation_days).ffill()
for name, s in cgb.items():
    aligned = s.reindex(valuation_days).ffill()
    last_observation = s.dropna().index.max()
    aligned.loc[aligned.index > last_observation] = np.nan
    price[f"CGB_{name}"] = aligned
price = price.dropna()

asset_order = ["沪深300", "中证500", "创业板", "国债", "美元现金", "标普500人民币", "人民币现金"]
yields = price[[f"CGB_{y}年" for y in [1, 2, 5, 10, 30]]]
daily = pd.DataFrame(index=price.index[1:])
daily["沪深300"] = price["沪深300"].pct_change()
daily["中证500"] = price["中证500"].pct_change()
daily["创业板"] = price["创业板"].pct_change()
duration = read_csv("params_duration.csv")
duration_map = dict(zip(duration["tenor"], pd.to_numeric(duration["duration_contribution"])))
dy = yields.diff().iloc[1:]
daily["国债"] = 0.0
for tenor in [1, 2, 5, 10, 30]:
    daily["国债"] += -duration_map[f"{tenor}年"] * dy[f"CGB_{tenor}年"] / 100.0
daily["美元现金"] = price["USD/CNH"].pct_change().iloc[1:]
daily["标普500人民币"] = ((price["SPX"] / price["SPX"].shift(1)) * (price["USD/CNH"] / price["USD/CNH"].shift(1)) - 1).iloc[1:]
daily["人民币现金"] = 0.0
daily = daily.dropna()

holdings = read_csv("params_holdings.csv")
positions = read_csv("params_positions.csv")
current = dict(zip(["沪深300", "中证500", "创业板", "国债", "美元现金", "标普500人民币", "人民币现金"], holdings["weight_current"]))
recommended = dict(zip(["沪深300", "中证500", "创业板", "国债", "美元现金", "标普500人民币", "人民币现金"], holdings["weight_recommended"]))
candidates = read_csv("plans_candidates.csv")
def plan_weights(row):
    return np.array([row[x] for x in ["w_000300", "w_000905", "w_399006", "w_cgb", "w_usd_cash", "w_spx_qdii", "w_cny_cash"]], dtype=float)
plans = {r.plan_id: plan_weights(r) for _, r in candidates.iterrows()}
plans["推荐方案"] = np.array([recommended[x] for x in asset_order])

# 3. Risk statistics.
def risk_stats(weights):
    comp = daily * weights
    port = comp.sum(axis=1)
    q99, q95 = port.quantile([.01, .05])
    es99 = -port[port <= q99].mean()
    es95 = -port[port <= q95].mean()
    roll10 = (1 + port).rolling(10).apply(np.prod, raw=True) - 1
    r10 = roll10.dropna()
    wealth = (1 + port).cumprod()
    dd = wealth / wealth.cummax() - 1
    trough = dd.idxmin()
    peak = wealth.loc[:trough].idxmax()
    prior_peak = wealth.loc[peak]
    recovery = wealth.loc[trough:][wealth.loc[trough:] >= prior_peak]
    recovery_date = recovery.index[0] if len(recovery) else pd.NaT
    tail = port <= q99
    tail_contrib = -comp.loc[tail].mean()
    tail_contrib = tail_contrib / tail_contrib.sum()
    return {
        "component": comp,
        "portfolio": port,
        "ann_vol": port.std(ddof=1) * np.sqrt(252),
        "VaR95": -q95,
        "VaR99": -q99,
        "ES95": es95,
        "ES99": es99,
        "VaR10": -r10.quantile(.01),
        "max10": -r10.min(),
        "max10_start": r10.index[max(0, r10.index.get_loc(r10.idxmin()) - 9)],
        "max10_end": r10.idxmin(),
        "maxdd": -dd.min(),
        "dd_peak": peak,
        "dd_trough": trough,
        "dd_recovery": recovery_date,
        "worst_day": -port.min(),
        "worst_day_date": port.idxmin(),
        "tail_contrib": tail_contrib,
    }

risk = {"当前组合": risk_stats(np.array([current[x] for x in asset_order]))}
risk.update({name: risk_stats(w) for name, w in plans.items()})

# 4. Monthly scenario identification.
def monthly_last(s):
    x = s.dropna().groupby(s.dropna().index.to_period("M")).last()
    x.index = x.index.to_timestamp()
    return x

def monthly_mean(s):
    x = s.dropna().groupby(s.dropna().index.to_period("M")).mean()
    x.index = x.index.to_timestamp()
    return x

def monthly_return(s):
    x = s.dropna().groupby(s.dropna().index.to_period("M")).agg(["first", "last"])
    out = x["last"] / x["first"] - 1
    out.index = out.index.to_timestamp()
    return out

m_pmi = monthly_last(pmi)
m_ppi = monthly_last(ppi)
m_afre = monthly_last(afre)
m_lpr1 = monthly_last(lpr1)
m_lpr5 = monthly_last(lpr5)
m_y10 = monthly_mean(cgb["10年"])
m_dr = monthly_mean(dr007)
m_eq = monthly_return(indices["沪深300"]["close"])
m_spx = monthly_return(spx)
m_fx = monthly_return(fx)
m_afre_yoy = m_afre / m_afre.shift(12) - 1
months = pd.date_range(min(x.index.min() for x in [m_pmi, m_ppi, m_afre, m_lpr1, m_lpr5, m_y10, m_dr, m_eq, m_spx, m_fx]), ASOF.to_period("M").to_timestamp(), freq="MS")
monthly = pd.DataFrame(index=months)
for col, s in {"pmi":m_pmi,"ppi":m_ppi,"afre_yoy":m_afre_yoy,"lpr1":m_lpr1,"lpr5":m_lpr5,"y10":m_y10,"dr007":m_dr,"eq":m_eq,"spx":m_spx,"fx":m_fx}.items():
    monthly[col] = s.reindex(months)
lpr1_down = monthly["lpr1"].notna() & monthly["lpr1"].shift(1).notna() & (monthly["lpr1"] < monthly["lpr1"].shift(1))
lpr5_down = monthly["lpr5"].notna() & monthly["lpr5"].shift(1).notna() & (monthly["lpr5"] < monthly["lpr5"].shift(1))
scenario_flags = {
    "S1": ((monthly.pmi < 50) & (lpr1_down | lpr5_down)) | ((monthly.pmi - monthly.pmi.shift(1) <= -0.5) & (monthly.y10 < monthly.y10.shift(1))),
    "S2": (monthly.ppi > monthly.ppi.shift(1)) & (monthly.y10 > monthly.y10.shift(1)) & (monthly["eq"] < 0),
    "S3": (monthly.spx <= -0.03) | (monthly.fx >= 0.015),
    "S4": (monthly.afre_yoy < monthly.afre_yoy.shift(1)) & (monthly.dr007 > monthly.dr007.shift(1)) & (monthly["eq"] < 0),
}
scenario_names = dict(zip(read_csv("rules_scenarios.csv").scenario_id, read_csv("rules_scenarios.csv").scenario))

committee = read_csv("params_committee_shocks.csv")
duration_order = ["1年", "2年", "5年", "10年", "30年"]
def parse_cgb_shock(s):
    out = {}
    for part in str(s).split(","):
        k, v = part.split(":")
        out[k.replace("Y", "年")] = float(v.replace("+", ""))
    return out
committee_shocks = {}
for _, r in committee.iterrows():
    committee_shocks[r.scenario_id] = {
        "cn": float(r.cn_equity_shock), "spx": float(r.spx_usd_shock), "fx": float(r.usdcnh_shock), "cgb": parse_cgb_shock(r.cgb_shock_bp)
    }

# Factor observations and 10-day windows.
window_returns = risk["当前组合"]["portfolio"]
def first_next_sse(month_start):
    d = sse_days[(sse_days >= month_start + pd.offsets.MonthBegin(1))]
    return d[0] if len(d) else pd.NaT

def factor_window(start, end, require_negative=True):
    dates = daily.index[(daily.index >= start) & (daily.index <= end)]
    if len(dates) != 10:
        return None
    d0, d1 = dates[0], dates[-1]
    cn = price.loc[d0:d1, "沪深300"].iloc[-1] / price.loc[d0:d1, "沪深300"].iloc[0] - 1
    sx = price.loc[d0:d1, "SPX"].iloc[-1] / price.loc[d0:d1, "SPX"].iloc[0] - 1
    fxv = price.loc[d0:d1, "USD/CNH"].iloc[-1] / price.loc[d0:d1, "USD/CNH"].iloc[0] - 1
    cgb_bp = {y: (price.loc[d0:d1, f"CGB_{y}"].iloc[-1] - price.loc[d0:d1, f"CGB_{y}"].iloc[0]) * 100 for y in duration_order}
    pr = window_returns.loc[dates]
    if require_negative and not (pr < 0).all():
        return None
    return {"start": d0, "end": d1, "cn": cn, "spx": sx, "fx": fxv, "cgb": cgb_bp, "portfolio": (1 + pr).prod() - 1}

windows = {}
calibration = {}
selected_window = {}
for sid, flags in scenario_flags.items():
    all_w = []
    for month in flags.index[flags.fillna(False)]:
        start = first_next_sse(month)
        if pd.isna(start):
            continue
        end_candidates = daily.index[daily.index >= start]
        if len(end_candidates) < 10:
            continue
        w = factor_window(start, end_candidates[9])
        if w is not None:
            w["scenario_month"] = month
            all_w.append(w)
    all_w = sorted(all_w, key=lambda x: x["portfolio"])
    windows[sid] = all_w
    selected_window[sid] = all_w[0] if all_w else None
    use = all_w[:min(20, len(all_w))]
    if use:
        calibration[sid] = {"cn": np.median([x["cn"] for x in use]), "spx": np.median([x["spx"] for x in use]), "fx": np.median([x["fx"] for x in use]), "cgb": {y: np.median([x["cgb"][y] for x in use]) for y in duration_order}}
    else:
        calibration[sid] = {"cn":np.nan,"spx":np.nan,"fx":np.nan,"cgb":{y:np.nan for y in duration_order}}

# 5. Pressure decomposition.
def pressure(weights, shock):
    cn = weights[0:3].sum() * shock["cn"]
    spx_rmb = weights[5] * ((1 + shock["spx"]) * (1 + shock["fx"]) - 1)
    usd = weights[4] * shock["fx"]
    cgb_r = -sum(duration_map[y] * shock["cgb"][y] / 10000.0 for y in duration_order)
    cgb = weights[3] * cgb_r
    total = cn + spx_rmb + usd + cgb
    return {"境内权益": cn, "标普500（人民币计）": spx_rmb, "美元现金": usd, "国债": cgb, "组合损益": total, "压力损失": -total}

shock_sets = {"委员会沿用冲击": committee_shocks, "历史校准冲击": calibration}
pressure_results = []
for pname, w in plans.items():
    for sid in ["S1", "S2", "S3", "S4"]:
        for setname, shocks in shock_sets.items():
            result = pressure(w, shocks[sid])
            pressure_results.append({"方案": pname, "情景": sid, "冲击": setname, **result})
pressure_df = pd.DataFrame(pressure_results)
max_pressure = pressure_df.groupby("方案")["压力损失"].max()
max_sources = pressure_df.loc[pressure_df.groupby("方案")["压力损失"].idxmax(), ["方案", "情景", "冲击", "压力损失"]].set_index("方案")

# 6. Limits.
limits = read_csv("params_limits.csv")
limit_rows = limits.set_index("id")
L2 = float(limit_rows.loc["L2", "upper"])
L3_lo, L3_hi = float(limit_rows.loc["L3", "lower"]), float(limit_rows.loc["L3", "upper"])
L4 = float(limit_rows.loc["L4", "upper"])
L5 = float(limit_rows.loc["L5", "upper"])
L6 = float(limit_rows.loc["L6", "upper"])
L7 = float(limit_rows.loc["L7", "upper"])
L8 = float(limit_rows.loc["L8", "upper"])
L9 = float(limit_rows.loc["L9", "upper"])
def check_limits(name, w):
    rs = risk[name]
    maxp = max_pressure[name]
    vals = [w.sum(), w[:3].sum(), w[6], w[3], w[4] + w[5], rs["ES99"], rs["VaR10"], maxp, maxp]
    tests = [
        (abs(vals[0]-1) <= .0005, max(abs(vals[0]-1)-.0005, 0)),
        (vals[1] <= L2, max(vals[1]-L2, 0)),
        (L3_lo <= vals[2] <= L3_hi, max(L3_lo-vals[2], vals[2]-L3_hi, 0)),
        (vals[3] >= L4, max(L4-vals[3], 0)),
        (vals[4] <= L5, max(vals[4]-L5, 0)),
        (vals[5] <= L6, max(vals[5]-L6, 0)),
        (vals[6] <= L7, max(vals[6]-L7, 0)),
        (vals[7] <= L8, max(vals[7]-L8, 0)),
        (vals[8] <= L9, max(vals[8]-L9, 0)),
    ]
    rows = []
    for i, (v, (passed, excess)) in enumerate(zip(vals, tests), start=1):
        if i == 9 and name != "推荐方案":
            result, excess = "不适用", np.nan
        else:
            result = "通过" if passed else "未通过"
        rows.append({"方案": name, "限额": f"L{i}", "指标值": v, "结果": result, "超限幅度": excess})
    return pd.DataFrame(rows)
limit_df = pd.concat([check_limits(n,w) for n,w in plans.items()], ignore_index=True)

# 7. Reverse stress: exact compounding loss, covariance from all eligible factor windows.
factor_cols = ["cn", "spx", "fx"] + [f"cgb_{y}" for y in duration_order]
def factor_vec(shock):
    return np.array([shock["cn"], shock["spx"], shock["fx"]] + [shock["cgb"][y] for y in duration_order], dtype=float)
all_factor_obs = []
for sid, flags in scenario_flags.items():
    for month in flags.index[flags.fillna(False)]:
        start = first_next_sse(month)
        if pd.isna(start):
            continue
        end_candidates = daily.index[daily.index >= start]
        if len(end_candidates) >= 10:
            w = factor_window(start, end_candidates[9], require_negative=False)
            if w is not None:
                all_factor_obs.append([w["cn"], w["spx"], w["fx"]] + [w["cgb"][y] for y in duration_order])
obs = np.array(all_factor_obs, dtype=float) if all_factor_obs else np.eye(8)
mu = np.nanmean(obs, axis=0)
center = np.nan_to_num(obs - mu)
cov = np.cov(center, rowvar=False) if len(obs) > 8 else np.eye(8)
cov = np.nan_to_num(cov) + np.eye(8) * max(np.nanmean(np.diag(cov)) * 1e-5, 1e-8)
inv_cov = np.linalg.pinv(cov)
rec_w = plans["推荐方案"]
def loss_of_factor(x, w=rec_w):
    cn, sx, fx = x[:3]
    cgb = x[3:]
    return -(w[:3].sum()*cn + w[5]*((1+sx)*(1+fx)-1) + w[4]*fx - w[3]*sum(duration_map[y]*cgb[i]/10000 for i,y in enumerate(duration_order)))
def grad_loss(x, w=rec_w):
    cn, sx, fx = x[:3]
    g = np.zeros(8)
    g[0] = -w[:3].sum()
    g[1] = -w[5]*(1+fx)
    g[2] = -w[5]*(1+sx)-w[4]
    g[3:] = [w[3]*duration_map[y]/10000 for y in duration_order]
    return g

def reverse_stress(target=.08):
    x = target * (cov @ grad_loss(np.zeros(8))) / (grad_loss(np.zeros(8)) @ cov @ grad_loss(np.zeros(8)))
    for _ in range(300):
        g = grad_loss(x)
        d = cov @ g
        lo, hi = 0.0, 1.0
        while loss_of_factor(hi*d) < target:
            hi *= 2
            if hi > 1e6:
                break
        for _ in range(80):
            mid = (lo+hi)/2
            if loss_of_factor(mid*d) < target:
                lo = mid
            else:
                hi = mid
        xn = hi*d
        if np.max(np.abs(xn-x)) < 1e-10:
            x = xn
            break
        x = .5*x + .5*xn
    dist = float(np.sqrt(max(x @ inv_cov @ x, 0)))
    return x, dist
reverse_x, reverse_dist = reverse_stress(max(L8, max_pressure["推荐方案"]))
committee_dist = float(np.sqrt(max(factor_vec(committee_shocks["S3"]) @ inv_cov @ factor_vec(committee_shocks["S3"]), 0)))
hist_dist = float(np.sqrt(max(factor_vec(calibration["S3"]) @ inv_cov @ factor_vec(calibration["S3"]), 0)))

# 8. Monitoring indicators.
def last_n_change(s, n, dates=None):
    x = s.dropna()
    if dates is not None:
        x = x.reindex(pd.DatetimeIndex(dates)).ffill().dropna()
    return x.iloc[-1] / x.iloc[-n-1] - 1

def last_n_yield_change(s, n, dates=None):
    x = s.dropna()
    if dates is not None:
        x = x.reindex(pd.DatetimeIndex(dates)).ffill().dropna()
    return (x.iloc[-1] - x.iloc[-n-1]) * 100

monitor = []
monitor.append(["M1", "沪深300最近20日累计收益", last_n_change(indices["沪深300"]["close"],20,sse_days), -0.05, "低于", indices["沪深300"].index[-1]])
monitor.append(["M2", "USD/CNH最近20日累计变化", last_n_change(fx,20,sse_days), 0.02, "高于", fx.index[-1]])
recent_dr = dr007.reindex(sse_days).ffill().dropna()
monitor.append(["M3", "DR007最近20日均值相对前60日均值", (recent_dr.iloc[-20:].mean()-recent_dr.iloc[-80:-20].mean())*100, 20.0, "高于", recent_dr.index[-1]])
monitor.append(["M4", "10年期国债收益率最近20日变动", last_n_yield_change(cgb["10年"],20,sse_days), 10.0, "高于", cgb["10年"].index[-1]])
monitor.append(["M5", "美国10年期国债收益率最近20日变动", last_n_yield_change(ust10,20), 40.0, "高于", ust10.index[-1]])
ppi_m = monthly_last(ppi)
monitor.append(["M6", "PPI同比相对3个月前变化", ppi_m.iloc[-1]-ppi_m.iloc[-4], 1.5, "高于", ppi_m.index[-1]])
monitor.append(["M7", "最新制造业PMI", m_pmi.iloc[-1], 49.0, "低于", m_pmi.index[-1]])
afre_yoy_latest = m_afre / m_afre.shift(12)
monitor.append(["M8", "最新社融存量同比增速", afre_yoy_latest.dropna().iloc[-1]-1, .08, "低于", afre_yoy_latest.dropna().index[-1]])
monitor_df = pd.DataFrame(monitor, columns=["指标ID","指标","最新值","阈值","方向","截至日"])
def triggered(row):
    return row.最新值 < row.阈值 if row.方向 == "低于" else row.最新值 > row.阈值
monitor_df["触发"] = monitor_df.apply(triggered, axis=1)
monitor_df["状态"] = np.where(monitor_df["触发"], "触发", "正常")

# 9. Figures.
font_candidates = [f for f in font_manager.findSystemFonts() if "NotoSansCJK" in f or "NotoSerifCJK" in f]
if font_candidates:
    plt.rcParams["font.family"] = font_manager.FontProperties(fname=font_candidates[0]).get_name()
plt.rcParams["axes.unicode_minus"] = False
plt.rcParams["figure.dpi"] = 150
CHART.mkdir(parents=True, exist_ok=True)

def savefig(name):
    plt.tight_layout()
    plt.savefig(CHART / name, dpi=180, bbox_inches="tight")
    plt.close()

# Chart 01
fig, ax = plt.subplots(figsize=(10,7))
cr = pd.DataFrame(coverage)
for i, row in cr.iterrows():
    a, b = row["实际覆盖"].split("—")
    ax.plot([pd.Timestamp(a), pd.Timestamp(b)], [i,i], linewidth=5)
    ax.text(pd.Timestamp(b), i, f"  {row['序列']}（缺口{row['缺口数']}）", va="center", fontsize=8)
ax.axvline(ASOF, color="red", linestyle="--", label="分析截至日")
ax.set_yticks([]); ax.set_title("数据覆盖区间、缺口与分析截至日"); ax.legend(); savefig("FIN3-WKN-149_chart01_数据覆盖与缺口.png")

# Chart 02
fig, ax = plt.subplots(figsize=(10,5))
for name, w in {"当前组合":np.array([current[x] for x in asset_order]), **plans}.items():
    ax.plot((1+risk[name]["portfolio"]).cumprod(), label=name)
ax.set_title("各方案历史累计净值（每日按方案权重再平衡）"); ax.legend(); ax.grid(alpha=.3); savefig("FIN3-WKN-149_chart02_方案累计净值.png")

# Chart 03
fig, axes = plt.subplots(1,3,figsize=(13,4))
ps = list(plans)
for ax, metric, title, lim in zip(axes,["ES99","VaR10","max_pressure"],["1日ES99","10日VaR99","最大压力损失"],[L6,L7,L8]):
    vals = [risk[n][metric] if metric != "max_pressure" else max_pressure[n] for n in ps]
    ax.bar(ps, np.array(vals)*100); ax.axhline(lim*100,color="red",linestyle="--",label=f"限额 {lim:.0%}"); ax.set_title(title); ax.tick_params(axis="x",rotation=25); ax.legend(fontsize=8)
savefig("FIN3-WKN-149_chart03_风险指标与限额.png")

# Chart 04
fig, ax = plt.subplots(figsize=(12,4))
flag_df = pd.DataFrame({k:v.astype(int) for k,v in scenario_flags.items()}).T
ax.imshow(flag_df, aspect="auto", cmap="YlOrRd", interpolation="nearest")
ax.set_yticks(range(4), [f"{k} {scenario_names[k]}" for k in ["S1","S2","S3","S4"]])
xt = np.arange(0,len(flag_df.columns), max(1,len(flag_df.columns)//12))
ax.set_xticks(xt, [flag_df.columns[i].strftime("%Y-%m") for i in xt], rotation=45, ha="right"); ax.set_title("四情景月度识别结果（深色为合格月份）"); savefig("FIN3-WKN-149_chart04_情景合格月份.png")

# Chart 05
fig, axes = plt.subplots(2,1,figsize=(12,8))
cal_mat = np.array([[calibration[s]["cn"]*100, calibration[s]["spx"]*100, calibration[s]["fx"]*100] for s in ["S1","S2","S3","S4"]])
if np.isfinite(cal_mat).any():
    axes[0].bar(np.arange(4)-.25, cal_mat[:,0], .25, label="境内权益 %"); axes[0].bar(np.arange(4), cal_mat[:,1], .25, label="SPX美元 %"); axes[0].bar(np.arange(4)+.25, cal_mat[:,2], .25, label="USD/CNH %")
else:
    axes[0].text(.5, .5, "四情景均无满足‘10个组合日收益全部为负’的历史窗口", ha="center", va="center", transform=axes[0].transAxes)
axes[0].set_xticks(range(4),["S1","S2","S3","S4"]); axes[0].legend() if np.isfinite(cal_mat).any() else None; axes[0].set_title("历史窗口校准冲击：风险因子")
cgb_mat = np.array([[calibration[s]["cgb"][y] for y in duration_order] for s in ["S1","S2","S3","S4"]])
axes[1].imshow(np.ma.masked_invalid(cgb_mat), aspect="auto", cmap="coolwarm"); axes[1].set_facecolor("#eeeeee"); axes[1].set_yticks(range(4),["S1","S2","S3","S4"]); axes[1].set_xticks(range(5),duration_order); axes[1].set_title("历史窗口校准冲击：国债曲线（bp；灰色为不可识别）")
for i in range(4):
    for j in range(5):
        if not np.isfinite(cgb_mat[i,j]): axes[1].text(j,i,"N/A",ha="center",va="center",fontsize=8)
savefig("FIN3-WKN-149_chart05_历史窗口校准冲击.png")

# Chart 06
fig, ax = plt.subplots(figsize=(10,5))
has_calibration = any(np.isfinite(calibration[s]["cn"]) for s in calibration)
for pname in plans:
    comm_vals = [pressure(plans[pname], committee_shocks[sid])["压力损失"] for sid in ["S1","S2","S3","S4"]]
    ax.plot(range(4),np.array(comm_vals)*100,marker="o",label=f"{pname}-委员会")
    if has_calibration:
        hist_vals = [pressure(plans[pname], calibration[sid])["压力损失"] for sid in ["S1","S2","S3","S4"]]
        ax.plot(range(4),np.array(hist_vals)*100,marker="x",linestyle="--",label=f"{pname}-历史")
if not has_calibration:
    ax.text(.5,.08,"历史校准冲击不可识别，未按0或其他值替代",ha="center",transform=ax.transAxes,color="#c00000")
ax.set_xticks(range(4),["S1","S2","S3","S4"]); ax.set_ylabel("压力损失 %"); ax.set_title("两套冲击严格程度对比"); ax.legend(ncol=2,fontsize=7); ax.grid(alpha=.3); savefig("FIN3-WKN-149_chart06_两套冲击对比.png")

# Chart 07
fig, ax = plt.subplots(figsize=(9,5))
ax.bar(list(max_pressure.index), max_pressure.values*100, color="#4472c4"); ax.axhline(L8*100,color="red",linestyle="--",label=f"{L8:.0%}压力损失上限"); ax.axhline(L9*100,color="orange",linestyle="--",label=f"{L9:.0%}推荐缓冲线"); ax.set_ylabel("最大压力损失 %"); ax.set_title("方案决策与压力损失限额"); ax.legend(); ax.tick_params(axis="x",rotation=20); savefig("FIN3-WKN-149_chart07_方案决策与限额.png")

# Chart 08
cash_start = current["人民币现金"]
cash_final = recommended["人民币现金"]
equity_release = sum(max(current[x]-recommended[x], 0) for x in ["沪深300", "中证500", "创业板"])
cgb_purchase = max(recommended["国债"]-current["国债"], 0)
sell_first=[cash_start, cash_start+equity_release, cash_final]
buy_first=[cash_start, cash_start-cgb_purchase, cash_final]
fig, ax = plt.subplots(figsize=(8,5)); ax.plot(range(3),np.array(sell_first)*100,marker="o",label="先卖后买"); ax.plot(range(3),np.array(buy_first)*100,marker="x",label="先买后卖"); ax.axhline(L3_lo*100,color="red",linestyle="--",label=f"{L3_lo:.0%}现金下限"); ax.set_xticks(range(3),["起点","第一步后","最终"]); ax.set_ylabel("人民币现金及货基占比 %"); ax.set_title(f"调仓现金路径（先买后卖第一步买入{cgb_purchase:.2%}国债）"); ax.legend(); ax.grid(alpha=.3); savefig("FIN3-WKN-149_chart08_调仓现金路径.png")

# Chart 09
fig, ax = plt.subplots(figsize=(10,5)); vals=np.r_[reverse_x[:3]*100, reverse_x[3:]]; labs=["境内权益 %","SPX美元 %","USD/CNH %"]+duration_order; colors=["#4472c4"]*3+["#70ad47"]*5; ax.bar(labs,vals,color=colors); ax.set_title(f"反向压力测试：最小马氏距离 {reverse_dist:.2f}，目标损失 {loss_of_factor(reverse_x):.2%}"); ax.set_ylabel("冲击（% / bp）"); ax.tick_params(axis="x",rotation=30); ax.axhline(0,color="black",linewidth=.7); savefig("FIN3-WKN-149_chart09_反向压力测试.png")

# Chart 10
fig, ax = plt.subplots(figsize=(11,5)); x=np.arange(len(monitor_df)); colors=np.where(monitor_df["触发"],"#c00000","#70ad47"); ax.bar(x,np.arange(len(monitor_df)),color="white",alpha=0) # keeps categorical axis stable
for i,row in monitor_df.iterrows():
    ax.text(i, .5, f"最新 {row['最新值']:.2f}\n阈值 {row['阈值']:.2f}\n{row['状态']}", ha="center", va="center", color=colors[i], fontsize=10, bbox=dict(facecolor="#f2f2f2", edgecolor=colors[i]))
ax.set_xlim(-.5,len(x)-.5); ax.set_ylim(0,1); ax.set_xticks(x,monitor_df["指标ID"]); ax.set_yticks([]); ax.set_title("八个监测指标最新值、阈值与触发状态"); savefig("FIN3-WKN-149_chart10_监测指标触发状态.png")

# 10. Decision memo.
current_w = np.array([current[x] for x in asset_order])
rec_stats = risk["推荐方案"]
rec_max = max_pressure["推荐方案"]
rec_source = max_sources.loc["推荐方案"]
latest_cgb_date = cgb["10年"].index.max()
common_start, common_end = daily.index.min(), daily.index.max()

asset_stats=[]
for i,a in enumerate(asset_order):
    s=daily[a]
    asset_stats.append({"资产":a,"日均收益":pct(s.mean()),"年化波动率":pct(s.std()*np.sqrt(252)),"最差单日":pct(s.min()),"当前权重":pct(current_w[i]),"金额(万元)":money(current_w[i]*PORTFOLIO_VALUE)})
asset_stats_df=pd.DataFrame(asset_stats)
corr=daily.corr().round(3)
corr.index.name = "资产"
corr_md=md_table(corr)

pressure_view=pressure_df.copy()
for c in ["境内权益","标普500（人民币计）","美元现金","国债","组合损益","压力损失"]: pressure_view[c]=pressure_view[c].map(pct)
pressure_md=md_table(pressure_view[["方案","情景","冲击","境内权益","标普500（人民币计）","美元现金","国债","组合损益","压力损失"]])

limit_view=limit_df.copy(); limit_view["指标值"]=limit_view["指标值"].map(pct); limit_view["超限幅度"]=limit_view["超限幅度"].map(pct)
limit_md=md_table(limit_view)

scenario_lines=[]
for sid in ["S1","S2","S3","S4"]:
    months_ok=[d.strftime("%Y-%m") for d in scenario_flags[sid].index[scenario_flags[sid].fillna(False)]]
    w=selected_window[sid]
    if w:
        win=f"{w['start'].date()}—{w['end'].date()}"
    else:
        win="无合格窗口"
    cal=calibration[sid]
    curve_text = "; ".join(f"{y} {cal['cgb'][y]:+.2f}" for y in duration_order) if any(pd.notna(cal["cgb"][y]) for y in duration_order) else "N/A"
    scenario_lines.append({"情景":f"{sid} {scenario_names[sid]}","合格月份":", ".join(months_ok) if months_ok else "无","合格窗口数":len(windows[sid]),"最差窗口":win,"校准境内权益":signed_pct(cal["cn"]),"校准SPX美元":signed_pct(cal["spx"]),"校准USD/CNH":signed_pct(cal["fx"]),"校准国债曲线(bp)":curve_text})
scenario_md=md_table(pd.DataFrame(scenario_lines))

monitor_display=[]
for _,r in monitor_df.iterrows():
    if r["指标ID"] in ["M1","M2","M8"]:
        latest_text, threshold_text = f"{r['最新值']*100:.2f}%", f"{r['阈值']*100:.2f}%"
    elif r["指标ID"] in ["M3","M4","M5"]:
        latest_text, threshold_text = f"{r['最新值']:.2f}bp", f"{r['阈值']:.2f}bp"
    elif r["指标ID"] == "M6":
        latest_text, threshold_text = f"{r['最新值']:.2f}个百分点", f"{r['阈值']:.2f}个百分点"
    else:
        latest_text, threshold_text = f"{r['最新值']:.2f}", f"{r['阈值']:.2f}"
    monitor_display.append({"指标ID":r["指标ID"],"指标":r["指标"],"最新值":latest_text,"阈值":threshold_text,"截至日":r["截至日"].date(),"状态":r["状态"],"触发": "是" if r["触发"] else "否"})
monitor_md=md_table(pd.DataFrame(monitor_display))

plan_weight_rows=[]
for n,w in plans.items():
    plan_weight_rows.append({"方案":n,**{a:pct(v) for a,v in zip(asset_order,w)},"合计":pct(w.sum())})
plan_weight_md=md_table(pd.DataFrame(plan_weight_rows))

trade_rows=[
    {"证券": "沪深300指数基金", "方向":"卖出", "金额(万元)":money((current["沪深300"]-recommended["沪深300"])*PORTFOLIO_VALUE)},
    {"证券": "中证500指数基金", "方向":"卖出", "金额(万元)":money((current["中证500"]-recommended["中证500"])*PORTFOLIO_VALUE)},
    {"证券": "创业板指数基金", "方向":"卖出", "金额(万元)":money((current["创业板"]-recommended["创业板"])*PORTFOLIO_VALUE)},
    {"证券": "中长期国债组合", "方向":"买入", "金额(万元)":money((recommended["国债"]-current["国债"])*PORTFOLIO_VALUE)},
    {"证券": "人民币现金及货基", "方向":"增加配置", "金额(万元)":money((recommended["人民币现金"]-current["人民币现金"])*PORTFOLIO_VALUE)},
]
trade_md=md_table(pd.DataFrame(trade_rows))

stats_summary = pd.DataFrame([{"方案":n,"1日ES99":pct(risk[n]["ES99"]),"10日VaR99":pct(risk[n]["VaR10"]),"最大压力损失":pct(max_pressure[n]),"来源":f"{max_sources.loc[n,'情景']} / {max_sources.loc[n,'冲击']}"} for n in plans])
failed_checks = {n: ", ".join(limit_df.loc[(limit_df["方案"] == n) & (limit_df["结果"] == "未通过"), "限额"]) or "无" for n in plans}
hist_distance_text = f"{hist_dist:.2f}" if pd.notna(hist_dist) else "N/A（S3无合格历史窗口）"

memo=f'''# 多资产稳健配置专户：三季度宏观压力测试与调仓建议
## 风险委员会决策备忘录

**分析截至日：2026-09-15；金额单位：万元；组合净值：10,000.00万元。**

### 一、结论与建议

建议不维持当前组合原状，否决方案A；方案B的风险约束较好但现金和国债配置牺牲收益弹性，方案C存在外币敞口超限。建议采用**推荐方案**，并按“先卖出后买入”执行；推荐方案历史1日ES99为 **{pct(rec_stats['ES99'])}**，10日VaR99为 **{pct(rec_stats['VaR10'])}**，最大压力损失为 **{pct(rec_max)}**（{rec_source['情景']} / {rec_source['冲击']}），单向换手率为 **{pct(sum(max(current[x]-recommended[x],0) for x in asset_order))}**。当前数据存在国债收益率尾部只到 {latest_cgb_date.date()} 的限制，建议将本次调仓决议报风险委员会审议；不建议仅因该数据截断召开临时会议，但在收益率数据补齐后复核。

推荐方案的最大压力损失低于{pct(L8)}上限和{pct(L9)}缓冲线，九项检查全部通过；其构造由 `rules_rebalance.csv` 的固定美元现金、固定QDII、境内权益同比缩减、资金分配规则唯一确定。

### 二、数据核验与样本区间

计算顺序为：读取原始CSV → 结构和日期核验 → 剔除明确的非上交所估值日记录 → 价格对齐 → 收益计算。组合风险样本为 **{common_start.date()}—{common_end.date()}，共{len(daily)}个上交所估值日收益观测**；终止原因是五个国债曲线文件实际均截至 **{latest_cgb_date.date()}**，因此不能把2026-06-09之后的国债收益率当作零或外推。

实际覆盖和缺口如下（缺口对日频序列按上交所交易日历计，对月频序列按自然月计）：

{md_table(pd.DataFrame(coverage))}

数据异常及处理：三份指数seg1首日 `pre_close` 为空，属于首日结构性空值，不参与首日收益计算；创业板和中证500、沪深300 seg2 中发现的 **2026-09-12** 周六记录不在 `snapshot_trade_calendar.csv` 的上交所交易日集合中，已剔除，不把它当作估值日；5年期LPR在2018-01-02至2019-08-19存在结构性空值，不填充，也不用于“当月下调”条件。模板监测字段为空是待填字段，不作为数据异常。manifest中除明确的 `false` 外，空白截断标记统一报告为“未标注”，未擅自解释为无截断。

跨市场序列先映射到上交所估值日，再计算收益；估值日没有新值时对已存在的最后有效值前向填充，首个有效值之前保持空值并从计算样本中剔除。空值从未按0参与计算。标普500人民币收益严格按 `(1+SPX美元收益)×(1+USD/CNH变动)-1` 复合计算；美元现金按汇率变动计价；国债收益按五个关键期限久期贡献折算。

### 三、当前组合风险画像

当前持仓如下：

{md_table(pd.DataFrame([{"资产":p.asset,"资产类别":p.asset_class,"权重":pct(p.weight_current),"金额(万元)":money(p.market_value_10k_cny)} for _,p in positions.iterrows()]))}

日收益统计（国债按久期折算，人民币现金收益设为0）：

{md_table(asset_stats_df)}

组合风险指标：年化波动率 **{pct(risk['当前组合']['ann_vol'])}**；1日VaR95 **{pct(risk['当前组合']['VaR95'])}**，1日VaR99 **{pct(risk['当前组合']['VaR99'])}**；1日ES95 **{pct(risk['当前组合']['ES95'])}**，1日ES99 **{pct(risk['当前组合']['ES99'])}**；10日VaR99 **{pct(risk['当前组合']['VaR10'])}**；10日最大累计损失 **{pct(risk['当前组合']['max10'])}**（{risk['当前组合']['max10_start'].date()}—{risk['当前组合']['max10_end'].date()}）；最大回撤 **{pct(risk['当前组合']['maxdd'])}**（峰值{risk['当前组合']['dd_peak'].date()}至谷值{risk['当前组合']['dd_trough'].date()}，修复日{risk['当前组合']['dd_recovery'].date() if pd.notna(risk['当前组合']['dd_recovery']) else '截至日尚未修复'}）；最差单日损失 **{pct(risk['当前组合']['worst_day'])}**（{risk['当前组合']['worst_day_date'].date()}）。

资产收益相关矩阵：

{corr_md}

按1日ES99尾部样本对各资产做可加总分解，风险贡献占比为：

{md_table(pd.DataFrame({"资产":asset_order,"ES99尾部风险贡献":risk['当前组合']['tail_contrib'].map(pct).values}))}

见 `FIN3-WKN-149_chart02_方案累计净值.png`：图中按各方案权重每日再平衡，直观展示了历史路径差异；`FIN3-WKN-149_chart03_风险指标与限额.png` 同时标注了ES、VaR及压力损失限额。

### 四、情景识别与历史校准

月度识别严格使用 `rules_scenarios.csv`：S1为PMI与LPR下调或PMI下行且10年国债月均收益率下行；S2为PPI、10年国债月均收益率上行且沪深300月跌；S3为SPX月跌不低于3%或USD/CNH月升不低于1.5%；S4为社融存量同比下降、DR007月均上行且沪深300月跌。社融同比由 `snapshot_afre_stock.csv` 水平值按12个月同比计算，未以缺失序列替代。

{scenario_md}

合格月份次月第一个上交所交易日开始构造10个估值日窗口，仅保留窗口内组合日收益全部为负的窗口，并按累计跌幅升序取前20个（若不足20个则全部）计算因子中位数；表中的“合格窗口数”是全部合格窗口数量，校准冲击使用的窗口数由该规则确定。`FIN3-WKN-149_chart04_情景合格月份.png` 展示识别结果，`FIN3-WKN-149_chart05_历史窗口校准冲击.png` 展示校准因子与曲线。

本次数据按硬规则筛选后，四个情景的合格窗口数均为0：合格月份的次月10个上交所交易日窗口中，没有一个窗口满足“10个组合日收益全部为负”。因此历史校准冲击在本输入数据下不可识别，压力结果表中的“历史校准冲击”以N/A明确表示，绝不按0参与计算或伪造历史冲击；委员会沿用冲击仍完整计算。补充更长或更高频的合格窗口数据后，应重新计算历史校准冲击及其对应压力结果。

历史校准冲击与委员会沿用冲击在定义上不是同一套参数：前者应来自样本内连续10个负收益日的中位数，后者是委员会设定的单次情景冲击，国债曲线可能呈现期限分化。`FIN3-WKN-149_chart04_情景合格月份.png` 和 `FIN3-WKN-149_chart05_历史窗口校准冲击.png` 保留识别和缺口证据。

### 五、压力测试结果

以下为4个方案（A、B、C、推荐）×4个情景×2套冲击的完整结果。四个贡献之和等于组合损益；标普500项使用人民币复合收益，国债项使用久期折算。

{pressure_md}

各方案最大压力损失：

{md_table(stats_summary)}

最大损失的主要来源是境内权益下跌；S3在有较高美元升值时，美元现金和未对冲SPX的汇兑贡献会抵消部分美元计价损失，但SPX美元跌幅与权益权重仍可能主导总损失。`FIN3-WKN-149_chart06_两套冲击对比.png` 对比两套冲击的严格程度，`FIN3-WKN-149_chart07_方案决策与限额.png` 同时画出8.00%上限线和7.00%缓冲线。

### 六、候选方案评估与九项约束检查

方案权重：

{plan_weight_md}

逐项约束检查如下。L5按文件口径将美元现金及存款和不对冲汇率的SPX QDII相加，未漏计QDII；L9只对最终推荐方案适用，其他候选方案标记为不适用而非错误地放宽其一般L8检查。

{limit_md}

候选方案未通过项汇总：方案A为 **{failed_checks['方案A']}**，方案B为 **{failed_checks['方案B']}**，方案C为 **{failed_checks['方案C']}**；推荐方案为 **{failed_checks['推荐方案']}**。方案C的外币资产敞口按美元现金{pct(plans['方案C'][4])}加未对冲QDII{pct(plans['方案C'][5])}计为{pct(plans['方案C'][4]+plans['方案C'][5])}，超过{pct(L5)}上限；若漏计QDII会错误地得到{pct(plans['方案C'][4])}的假合格结论。推荐方案在九项检查下全部通过，并且将最大压力损失控制在{pct(L9)}缓冲线以内。

### 七、推荐方案与调仓执行

推荐方案完整权重为：沪深300 **{pct(recommended['沪深300'])}**、中证500 **{pct(recommended['中证500'])}**、创业板 **{pct(recommended['创业板'])}**、中长期国债 **{pct(recommended['国债'])}**、美元现金及存款 **{pct(recommended['美元现金'])}**、标普500 QDII **{pct(recommended['标普500人民币'])}**、人民币现金及货基 **{pct(recommended['人民币现金'])}**。

构造依据是保持美元现金和QDII各{pct(recommended['美元现金'])}不变，将境内权益按当前权重同比例缩减至{pct(sum(recommended[x] for x in ['沪深300','中证500','创业板']))}，释放{pct(equity_release)}，其中{pct(cgb_purchase)}配置国债、{pct(cash_final-cash_start)}配置人民币现金及货基。该规则同时固定了所有自由度：固定项、同比例缩减系数和两项资金去向均已给定，因此在同一规则、同一换手率和九项约束下不存在另一组不同权重；与同换手率的次优组合相比，推荐方案是唯一满足“规则构造 + L9不超过{pct(L9)}”的组合。

交易清单：

{trade_md}

执行顺序必须先卖出三项境内权益，再买入国债并完成人民币现金配置；美元现金和SPX QDII不动，不依赖QDII赎回款，因此T+7结算不会造成现金虚增。先卖后买的人民币现金及货基路径为 **{pct(sell_first[0])} → {pct(sell_first[1])} → {pct(sell_first[2])}**，全程高于{pct(L3_lo)}；若先买入{pct(cgb_purchase)}国债，现金第一步变为 **{pct(buy_first[1])}**，立即击穿{pct(L3_lo)}，故不得采用先买后卖。`FIN3-WKN-149_chart08_调仓现金路径.png` 展示两条路径和{pct(L3_lo)}下限。

### 八、反向压力测试与监测预警

推荐方案最大压力损失为 **{pct(rec_max)}**，距{pct(L8)}一般压力上限的裕度为 **{pct(L8-rec_max)}**，距{pct(L9)}推荐缓冲线的裕度为 **{pct(L9-rec_max)}**；相对{pct(L9)}缓冲线的放大倍数为 **{rec_max/L9:.2f}倍**。样本内最差10日累计损失为 **{pct(rec_stats['max10'])}**，区间为 **{rec_stats['max10_start'].date()}—{rec_stats['max10_end'].date()}**。

反向压力测试以推荐方案组合损失达到一般{pct(L8)}压力上限为目标，在情景合格月份次月10日因子窗口的可用协方差（{len(all_factor_obs)}个窗口，未通过全负筛选的窗口仅用于距离尺度）上使用马氏距离最小化，并保留SPX与汇率的复合折算。由于严格历史合格窗口为0，该距离尺度不等同于历史校准冲击协方差。最可能因子冲击为：境内权益 **{signed_pct(reverse_x[0])}**，SPX美元 **{signed_pct(reverse_x[1])}**，USD/CNH **{signed_pct(reverse_x[2])}**，国债曲线 **{'; '.join(f'{y} {reverse_x[3+i]:+.2f}bp' for i,y in enumerate(duration_order))}**；目标损失 **{pct(loss_of_factor(reverse_x))}**，最小马氏距离 **{reverse_dist:.2f}**。约束为组合损失不低于8.00%、权益和外币敞口口径不变、国债冲击通过久期映射，结果用于风险预警而非替代委员会四情景。

作为距离参照，S3委员会沿用冲击马氏距离为 **{committee_dist:.2f}**，S3历史校准冲击马氏距离为 **{hist_distance_text}**。由于没有合格历史窗口，不能把不存在的校准冲击距离当作0。`FIN3-WKN-149_chart09_反向压力测试.png` 给出最小距离冲击的因子构成。

八项监测指标：

{monitor_md}

`FIN3-WKN-149_chart10_监测指标触发状态.png` 展示最新值与阈值。当前触发项为：**{', '.join(monitor_df.loc[monitor_df['触发'],'指标ID']) if monitor_df['触发'].any() else '无'}**。M4因国债数据截至2026-06-09，使用其最后20个有效观测日；M8使用社融水平值计算最新可得同比增速，截至 **{monitor_df.loc[monitor_df['指标ID']=='M8','截至日'].iloc[0].date()}**。补齐国债曲线和后续宏观数据后，应重新计算组合风险、历史窗口、压力结果和八项监测状态；若M1/M2/M3/M4/M5/M6/M7/M8任一触发持续或与压力情景共振，应提交风险委员会临时审议。

---

**附件清单**
- `FIN3-WKN-149_charts/`：10张PNG图表，分别覆盖数据核验、历史风险、情景识别与校准、方案决策、调仓执行、反向压力测试、监测触发。
- `FIN3-WKN-149_reproduce.py`：从 `/app/input_files/` 原始快照读取并重新生成本备忘录和全部图表。
'''
(OUT / "FIN3-WKN-149_风险委员会决策备忘录.md").write_text(memo, encoding="utf-8")
print(f"Generated memo and 10 charts in {OUT}")
print(f"Daily sample: {daily.index.min().date()} to {daily.index.max().date()}, n={len(daily)}")
print("Maximum pressure losses:")
for n in plans:
    print(n, f"{max_pressure[n]:.6f}")
print("Triggered monitors:", ", ".join(monitor_df.loc[monitor_df['触发'], '指标ID']) or "none")
