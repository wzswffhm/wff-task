#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
FIN3-WKN-149 多资产稳健配置专户 · 三季度宏观压力测试与调仓建议 —— 可复算脚本
=============================================================================
- 全部输入读取自 /app/input_files/（只读），全部结论数值均由本脚本计算得出，不硬编码。
- 运行后在标准输出打印备忘录八章所需的全部数字，并在 /app/output/FIN3-WKN-149_charts/
  下生成 10 张 PNG 图表。
- 主要口径（均在备忘录第二章披露）：
  * 对齐：所有跨市场序列先对齐到上交所(SSE)估值日；他市休市/导出缺日按前向填充，
    结构性空值（序列尚未存在、月份未发布、导出截断）不参与填充、不按 0 计入；
  * 国债组合日收益 = -Σ(关键期限久期贡献 × 该期限收益率日变动[百分点])；
  * 标普500 人民币计收益 = (1+美元收益)×(1+USDCNH变动)-1（复合，不用加法近似）；
  * 美元现金：美元计息率按 0 处理，人民币计收益 = USDCNH 日变动；
  * 人民币现金及货基：收益按 0 处理（无对应源数据，风险贡献为 0）；
  * 组合日收益 = Σ(方案权重 × 资产日收益)，权重按日再平衡（恒定）。
依赖：numpy / pandas / matplotlib（无需 scipy，优化为自实现）。
"""
import os
import re
import warnings

import numpy as np
import pandas as pd
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import matplotlib.dates as mdates
from matplotlib.patches import Patch

warnings.filterwarnings("ignore")

IN = "/app/input_files"
OUT = "/app/output"
CHART_DIR = os.path.join(OUT, "FIN3-WKN-149_charts")
os.makedirs(CHART_DIR, exist_ok=True)

plt.rcParams["font.sans-serif"] = ["Noto Sans CJK SC"]
plt.rcParams["axes.unicode_minus"] = False
plt.rcParams["figure.dpi"] = 110

NAV_TOTAL = 10000.0        # 组合净值（万元）—— 题设专户规模
ANN = 252                  # 年化因子（披露口径）
TENORS = ["1Y", "2Y", "5Y", "10Y", "30Y"]
LEG_ORDER = ["EQ_000300", "EQ_000905", "EQ_399006", "CGB", "USD_CASH", "SPX", "CNY_CASH"]

R = {}  # 结果容器，供图表与打印复用


def sec(title):
    print("\n" + "=" * 88)
    print(title)
    print("=" * 88)


def pct(x, nd=2):
    return f"{x * 100:.{nd}f}%"


def bp(x, nd=2):
    return f"{x * 100:.{nd}f}bp"


# ============================================================================
# S0. 读取规则与参数文件（全部来自 input_files，避免硬编码）
# ============================================================================
cal = pd.read_csv(f"{IN}/snapshot_trade_calendar.csv", parse_dates=["date"])
assert (cal["is_trading_day"] == 1).all(), "交易日历存在 is_trading_day!=1 的行"
TD = pd.DatetimeIndex(cal["date"].sort_values().unique())
ASOF = TD.max()                      # 分析截至日 = 日历最后一日（2026-09-15）
TD_POS = {d: i for i, d in enumerate(TD)}

hold = pd.read_csv(f"{IN}/params_holdings.csv")
pos_df = pd.read_csv(f"{IN}/params_positions.csv")
limits = pd.read_csv(f"{IN}/params_limits.csv").set_index("id")
dur_df = pd.read_csv(f"{IN}/params_duration.csv")
comm = pd.read_csv(f"{IN}/params_committee_shocks.csv")
plans_df = pd.read_csv(f"{IN}/plans_candidates.csv")
rules_scen = pd.read_csv(f"{IN}/rules_scenarios.csv")
rules_win = pd.read_csv(f"{IN}/rules_windows.csv").set_index("key")["value"]
rules_chk = pd.read_csv(f"{IN}/rules_checks.csv")
rules_reb = pd.read_csv(f"{IN}/rules_rebalance.csv").set_index("key")["value"]
monitor_tpl = pd.read_csv(f"{IN}/template_monitor.csv", encoding="utf-8-sig")
manifest = pd.read_csv(f"{IN}/snapshot_data_manifest.csv")

# 久期贡献：'1年'->'1Y' 等
_dc_map = {"1年": "1Y", "2年": "2Y", "5年": "5Y", "10年": "10Y", "30年": "30Y"}
DC = pd.Series(
    { _dc_map[r.tenor]: r.duration_contribution for r in dur_df.itertuples() }
).reindex(TENORS)
DC_SUM = float(DC.sum())

# 从 rules_windows.csv 文本中提取窗口参数（不硬编码）
WIN_LEN = int(re.search(r"(\d+)\s*个上交所交易日", rules_win["window_length"]).group(1))
MIN_WIN = int(re.search(r"不少于\s*(\d+)\s*个", rules_win["window_rule"]).group(1))
C1_TOL = float(re.search(r"容差\s*([\d.]+)\s*个百分点", rules_chk.loc[0, "description"]).group(1)) / 100.0
CASH_FLOOR = float(re.search(r"([\d.]+)\s*%", rules_reb["cash_floor"]).group(1)) / 100.0

# 限额（读取自 params_limits.csv）
# 注意：L4（中长期国债组合 >= 下限 15%）在快照中把界值放在 upper 列、lower 列为空，
# 因此按 op 语义取非空界值，避免 NaN 传染到 C4 检查与网格过滤。
def _lim(lid: str, prefer: str) -> float:
    lo, up = limits.loc[lid, "lower"], limits.loc[lid, "upper"]
    v = lo if prefer == "lower" else up
    if pd.isna(v):
        v = up if prefer == "lower" else lo
    return float(v)

LIM = {
    "L2_eq_max": _lim("L2", "upper"),
    "L3_lo": _lim("L3", "lower"),
    "L3_hi": _lim("L3", "upper"),
    "L4_lo": _lim("L4", "lower"),
    "L5_max": _lim("L5", "upper"),
    "L6_es99": _lim("L6", "upper"),
    "L7_var99_10": _lim("L7", "upper"),
    "L8_stress": _lim("L8", "upper"),
    "L9_stress_rec": _lim("L9", "upper"),
}

# 权重向量
def wvec(w300, w905, wcyb, wcgb, wusd, wspx, wcny):
    return np.array([w300, w905, wcyb, wcgb, wusd, wspx, wcny], dtype=float)

W_CUR = wvec(*hold.set_index("asset_class").loc[LEG_ORDER, "weight_current"])
W_REC = wvec(*hold.set_index("asset_class").loc[LEG_ORDER, "weight_recommended"])
PLAN_W = {"当前组合": W_CUR}
for r_ in plans_df.itertuples():
    PLAN_W[r_.plan_id] = wvec(r_.w_000300, r_.w_000905, r_.w_399006, r_.w_cgb,
                              r_.w_usd_cash, r_.w_spx_qdii, r_.w_cny_cash)
PLAN_W["方案D(推荐)"] = W_REC
PLAN_PROPOSER = {"当前组合": "现状", "方案A": "投资经理", "方案B": "风险管理部",
                 "方案C": "宏观策略组", "方案D(推荐)": "风险经理(按 rules_rebalance 构造)"}
STRESS_PLANS = ["方案A", "方案B", "方案C", "方案D(推荐)"]   # 压力测试的“4 个方案”

# ============================================================================
# S1. 数据读取与核验（先于一切计算）
# ============================================================================
sec("R1 数据核验：覆盖区间 / 缺口 / 异常记录 / 结构性空值")


def load_seg(files, valcol, parse_dates=True):
    dfs = [pd.read_csv(f"{IN}/{f}", parse_dates=["date"]) for f in files]
    return pd.concat(dfs, ignore_index=True)


validation = []      # 每序列核验记录
anomalies = []       # 异常明细

def register(name, files, df, valcols, expect_all_td=True, note="", daily=True):
    """登记一个序列的核验信息：覆盖、非SSE行、缺失SSE日、截断、空值。
    daily=False 表示月度/发布日频序列，SSE 逐日对齐口径不适用。"""
    d = df["date"]
    dup = int(d.duplicated().sum())
    in_td = d.isin(TD)
    non_td = df.loc[~in_td]
    cover = (d.min(), d.max())
    if daily:
        tdr = TD[(TD >= d.min()) & (TD <= d.max())]
        have = set(d)
        missing_td = tdr[~tdr.isin(have)]
        trunc_days = int(((TD > d.max()) & (TD <= ASOF)).sum())
    else:
        missing_td = pd.DatetimeIndex([])
        trunc_days = None
    nan_ct = {c: int(df[c].isna().sum()) for c in valcols if df[c].isna().sum() > 0}
    validation.append(dict(series=name, files=";".join(files), rows=len(df),
                           start=cover[0].date(), end=cover[1].date(), dup=dup,
                           non_td_rows=(len(non_td) if daily else None),
                           missing_td=(len(missing_td) if daily else None),
                           missing_list=[str(x.date()) for x in missing_td][:20],
                           trunc_td_days=trunc_days, nans=nan_ct, note=note))
    return non_td, missing_td

# ---- 权益三指数（分段拼接） ----
EQ_RAW = {}
for name, pfx in [("沪深300", "000300SH"), ("中证500", "000905SH"), ("创业板指", "399006SZ")]:
    files = [f"snapshot_{pfx}_seg1.csv", f"snapshot_{pfx}_seg2.csv"]
    df = load_seg(files, None)
    # 休市日异常记录识别：日期不在SSE日历 且 (open==high==low==close==pre_close) 且 成交额异常偏低
    not_in = ~df["date"].isin(TD)
    flat = (df["open"] == df["high"]) & (df["high"] == df["low"]) & (df["low"] == df["close"])
    med_amt = df["amount"].rolling(20, min_periods=5).median()
    thin = df["amount"] < 0.1 * med_amt
    anom = df[not_in & flat & (thin.fillna(True))]
    for r_ in anom.itertuples():
        anomalies.append(dict(series=name, date=str(r_.date.date()),
                               dow=["周一","周二","周三","周四","周五","周六","周日"][r_.date.dayofweek],
                               close=r_.close, amount=r_.amount,
                               why="非SSE交易日+OHLC/pre_close全等+成交额<近20日中位数10%",
                               action="剔除"))
    df_clean = df[~not_in].copy()
    non_td, missing_td = register(name, files, df, ["close"],
                                  note=f"剔除非SSE交易日异常行 {len(anom)} 条")
    s = df_clean.set_index("date")["close"].sort_index().reindex(TD)
    assert s.notna().all(), f"{name} 对齐后仍有缺失"
    EQ_RAW[name] = s
    # pre_close 链条一致性（容差 0.01，剔除后校验）
    dd = df_clean.sort_values("date")
    bad_chain = int((abs(dd["pre_close"] - dd["close"].shift(1)) > 0.01).sum())
    if bad_chain > 0:
        anomalies.append(dict(series=name, date="-", dow="-", close=np.nan, amount=np.nan,
                              why=f"剔除异常行后 pre_close 与前日 close 仍不一致的行数={bad_chain}",
                              action="需复核"))
    else:
        anomalies.append(dict(series=name, date="-", dow="-", close=np.nan, amount=np.nan,
                              why="剔除异常行后 pre_close 与前日 close 链条完全一致",
                              action="核验通过"))

# ---- 中债国债收益率 5 期限 ----
CGB_RAW = {}
for t in TENORS:
    f = f"snapshot_cgb_yield_{t.lower()}.csv"
    df = pd.read_csv(f"{IN}/{f}", parse_dates=["date"])
    non_td, _ = register(f"中债国债{t}", [f], df, ["yield_pct"],
                         note="含银行间调休上班日/特殊发布日行，对齐SSE估值日时剔除")
    CGB_RAW[t] = df.set_index("date")["yield_pct"].sort_index()
CGB_LAST_REAL = max(s.index.max() for s in CGB_RAW.values())   # 截断末日

# ---- USDCNH / SPX / UST ----
u = load_seg(["snapshot_usdcnh_seg1.csv", "snapshot_usdcnh_seg2.csv"], None)
register("USD/CNH", ["snapshot_usdcnh_seg1.csv", "snapshot_usdcnh_seg2.csv"], u, ["usdcnh"],
         note="离岸日历发布，缺SSE交易日按前向填充")
FX_RAW = u.set_index("date")["usdcnh"].sort_index()

spx = pd.read_csv(f"{IN}/snapshot_spx.csv", parse_dates=["date"])
register("标普500", ["snapshot_spx.csv"], spx, ["close"], note="美国日历发布，缺SSE交易日按前向填充")
SPX_RAW = spx.set_index("date")["close"].sort_index()

ust10 = pd.read_csv(f"{IN}/snapshot_ust_10y.csv", parse_dates=["date"])
register("美债10Y", ["snapshot_ust_10y.csv"], ust10, ["yield_pct"], note="美国日历发布，前向填充对齐")
UST10_RAW = ust10.set_index("date")["yield_pct"].sort_index()

ustm2 = pd.read_csv(f"{IN}/snapshot_ust_m2.csv", parse_dates=["date"])
register("美债M2", ["snapshot_ust_m2.csv"], ustm2, ["yield_pct"], note="2018-10-16 起有数据（结构性起点）；本次计算未使用")
ustm4 = pd.read_csv(f"{IN}/snapshot_ust_m4.csv", parse_dates=["date"])
register("美债M4", ["snapshot_ust_m4.csv"], ustm4, ["yield_pct"], note="仅 6 条（2026-09-08 起）；本次计算未使用")

# ---- Shibor / DR007 ----
sh = load_seg(["snapshot_shibor_seg1.csv", "snapshot_shibor_seg2.csv"], None)
register("Shibor", ["snapshot_shibor_seg1.csv", "snapshot_shibor_seg2.csv"], sh,
         ["shibor_on", "shibor_1w"], note="2018-09-03 起；含银行间调休上班日行；未参与收益计算")
dr = pd.read_csv(f"{IN}/snapshot_dr007.csv", parse_dates=["date"])
register("DR007", ["snapshot_dr007.csv"], dr, ["dr007"], note="2018-09-03 起；含银行间调休上班日行")
DR_RAW = dr.set_index("date")["dr007"].sort_index()

# shibor_1w 与 dr007 数值一致性异常（上游导出错位嫌疑）
_sh1w = sh.set_index("date")["shibor_1w"].sort_index()
_common = _sh1w.index.intersection(DR_RAW.index)
_same = float((_sh1w.loc[_common] == DR_RAW.loc[_common]).mean())
anomalies.append(dict(series="Shibor_1W vs DR007", date="-", dow="-", close=np.nan, amount=np.nan,
                       why=f"两序列在 {len(_common)} 个共同日上数值完全相同的比例={_same:.0%}（疑似上游列错位）",
                       action="本次计算仅使用 DR007（S4 规则与 M3 监测），Shibor 不进入任何计算"))

# ---- 月度宏观（月频/发布日频，不适用SSE逐日对齐口径）----
pmi = pd.read_csv(f"{IN}/snapshot_pmi_manufacturing.csv", parse_dates=["date"])
register("制造业PMI", ["snapshot_pmi_manufacturing.csv"], pmi, ["pmi_mfg"], daily=False,
         note="月频；缺 2026-08（结构性未发布，不填充）")
afre = pd.read_csv(f"{IN}/snapshot_afre_stock.csv", parse_dates=["date"])
register("社融存量", ["snapshot_afre_stock.csv"], afre, ["afre_stock"], daily=False,
         note="月频；2026-04 后截断（结构性未发布）")
ppi = pd.read_csv(f"{IN}/snapshot_ppi_yoy.csv", parse_dates=["date"])
register("PPI同比", ["snapshot_ppi_yoy.csv"], ppi, ["ppi_yoy"], daily=False, note="月频；2026-08 后截断")

lpr1 = pd.read_csv(f"{IN}/snapshot_lpr_1y.csv", parse_dates=["date"])
register("LPR_1Y", ["snapshot_lpr_1y.csv"], lpr1, ["lpr_1y"], daily=False, note="发布日频；2026-07-20 后截断")
lpr5 = pd.read_csv(f"{IN}/snapshot_lpr_5y.csv", parse_dates=["date"])
register("LPR_5Y", ["snapshot_lpr_5y.csv"], lpr5, ["lpr_5y"], daily=False,
         note="发布日频；2019-08-20 前为结构性空值（该期限尚未发布），空值不填充不参与计算；2026-08-20 后截断")
register("SSE交易日历", ["snapshot_trade_calendar.csv"], cal.assign(x=1), ["x"], note="2113 个估值日")

# ---- manifest 与实际内容核对 ----
mani_cmp = []
for r_ in manifest.itertuples():
    fn = r_.file
    if not fn.startswith("snapshot_") or not os.path.exists(f"{IN}/{fn}"):
        continue
    dfm = pd.read_csv(f"{IN}/{fn}", parse_dates=["date"])
    act_rows = len(dfm)
    act_start, act_end = dfm["date"].min().date(), dfm["date"].max().date()
    trunc_flag = str(r_.possible_truncation) if pd.notna(r_.possible_truncation) else ""
    real_trunc = act_end < ASOF.date()
    ok = (act_rows == r_.records) and (str(act_start) == str(r_.start)) and (str(act_end) == str(r_.end))
    mani_cmp.append((fn, r_.records, act_rows, str(r_.end), str(act_end), trunc_flag,
                     "截断(实际末日早于分析截至日)" if real_trunc else "完整", ok))

print(f"分析截至日 ASOF = {ASOF.date()}（SSE交易日历最后一日）；样本估值日总数 = {len(TD)}")
print(f"\n{'序列':<14}{'行数':>6}  {'实际覆盖':<25}{'非SSE行':>7}{'缺失SSE日':>9}{'截断缺口(交易日)':>14}  空值列")
for v in validation:
    cov = f"{v['start']}..{v['end']}"
    non_td_s = "—" if v["non_td_rows"] is None else str(v["non_td_rows"])
    miss_s = "—" if v["missing_td"] is None else str(v["missing_td"])
    trunc_s = "—" if v["trunc_td_days"] is None else str(v["trunc_td_days"])
    print(f"{v['series']:<14}{v['rows']:>6}  {cov:<25}{non_td_s:>7}{miss_s:>9}"
          f"{trunc_s:>14}  {v['nans'] if v['nans'] else '无'}")
    if v["missing_list"]:
        print(f"    缺失SSE日明细(前20): {v['missing_list']}")

print("\n数据异常明细：")
for a in anomalies:
    print(f"  - [{a['series']}] {a['date']}({a['dow']}) {a['why']} → {a['action']}")

print("\nmanifest 与文件实际内容核对（行数/起止日均以文件实际内容为准；possible_truncation 字段不保证与内容一致）：")
for m in mani_cmp:
    flag = "" if m[7] else "  <-- manifest 声明与实际不一致"
    print(f"  {m[0]:<34} 声明{m[1]:>5}行/实际{m[2]:>5}行  声明末日{m[3]}/实际末日{m[4]}  "
          f"截断标记'{m[5]}'→实际末日{'早于' if m[6].startswith('截断') else '等于'}分析截至日{flag}")

R["validation"], R["anomalies"], R["mani_cmp"] = validation, anomalies, mani_cmp
R["cgb_last_real"] = CGB_LAST_REAL

# ============================================================================
# S2. 对齐 SSE 估值日并构造收益序列
# ============================================================================
sec("R2 价格对齐与收益构造（对齐SSE估值日；他市缺日前向填充；结构性空值不填充）")


def align(s_raw, name):
    a = s_raw.reindex(TD)
    first_valid = a.first_valid_index()
    a = a.ffill()
    n_ff = int(a.notna().sum() - s_raw.reindex(TD).notna().sum())
    print(f"  {name:<12} 首个有效日={first_valid.date()}  对齐后前向填充日数={n_ff}  "
          f"实际观测末日={s_raw.index.max().date()}")
    return a

P = pd.DataFrame(index=TD)
P["hs300"] = EQ_RAW["沪深300"]
P["zz500"] = EQ_RAW["中证500"]
P["cyb"] = EQ_RAW["创业板指"]
P["spx"] = align(SPX_RAW, "标普500")
P["fx"] = align(FX_RAW, "USD/CNH")
Y = pd.DataFrame({t: align(CGB_RAW[t], f"国债{t}") for t in TENORS})
DR_AL = align(DR_RAW, "DR007")
UST10_AL = align(UST10_RAW, "美债10Y")

R_px = P.pct_change()
dY = Y.diff()                                   # 百分点(pp)
bond_ret = -(dY * DC).sum(axis=1) / 100.0       # 久期折算(Δy换算为小数)，非简单加总
spxcny = (1.0 + R_px["spx"]) * (1.0 + R_px["fx"]) - 1.0   # 复合折算
LEGS = pd.DataFrame({
    "EQ_000300": R_px["hs300"],
    "EQ_000905": R_px["zz500"],
    "EQ_399006": R_px["cyb"],
    "CGB": bond_ret,
    "USD_CASH": R_px["fx"],        # 美元现金：美元利率按0，人民币计收益=汇率变动
    "SPX": spxcny,
    "CNY_CASH": 0.0,               # 人民币现金及货基：收益按0
}).iloc[1:]                     # 2018-01-03 起（首日无前值，结构性不参与）
assert LEGS.notna().all().all(), "收益矩阵存在空值"
print(f"\n收益样本：{LEGS.index[0].date()} .. {LEGS.index[-1].date()}，共 {len(LEGS)} 个日收益观测")
print(f"国债截断期 {CGB_LAST_REAL.date()} 之后至 {ASOF.date()}：收益率前向填充（变动=0），"
      f"涉及 {int((TD > CGB_LAST_REAL).sum())} 个估值日，国债腿日收益按 0.00% 处理（已披露）")

# 方案组合日收益（每日再平衡）
PORT = {k: LEGS.values @ w for k, w in PLAN_W.items()}
PORT_S = {k: pd.Series(v, index=LEGS.index) for k, v in PORT.items()}
R["LEGS"], R["PORT_S"], R["P"], R["Y"] = LEGS, PORT_S, P, Y

# ============================================================================
# S3. 风险统计（当前组合 + 各方案）
# ============================================================================
sec("R3 组合风险画像（当前组合详表 + 各方案风险指标）")


def risk_stats(r, idx=None, label=""):
    r = np.asarray(r, dtype=float)
    n = len(r)
    idx = idx if idx is not None else np.arange(n)
    srt = np.sort(r)
    k95 = max(1, int(np.floor(0.05 * n)))
    k99 = max(1, int(np.floor(0.01 * n)))
    c = np.cumsum(np.log1p(r))
    roll = np.expm1(c[WIN_LEN:] - c[:-WIN_LEN])       # 10日滚动累计（重叠窗口）
    j = int(np.argmin(roll))
    nav = np.cumprod(1.0 + r)
    runmax = np.maximum.accumulate(nav)
    dd = nav / runmax - 1.0
    tr = int(np.argmin(dd))
    pk = int(np.argmax(nav[: tr + 1]))
    rec = None
    for t in range(tr, n):
        if nav[t] >= nav[pk]:
            rec = t
            break
    out = dict(
        label=label, n=n,
        ann_ret=float(np.mean(r) * ANN), ann_vol=float(np.std(r, ddof=1) * np.sqrt(ANN)),
        var95=float(-np.percentile(r, 5)), var99=float(-np.percentile(r, 1)),
        es95=float(-srt[:k95].mean()), es99=float(-srt[:k99].mean()),
        var99_10=float(-np.percentile(roll, 1)),
        worst10=float(roll[j]), w10_base=idx[j], w10_end=idx[j + WIN_LEN],
        mdd=float(dd[tr]), mdd_peak=idx[pk], mdd_trough=idx[tr],
        mdd_rec=(idx[rec] if rec is not None else None),
        worst1=float(r.min()), worst1_day=idx[int(np.argmin(r))],
        tail_k99=k99, roll_n=len(roll),
    )
    return out

STATS = {}
for k, w in PLAN_W.items():
    STATS[k] = risk_stats(PORT[k], LEGS.index.values, k)

st = STATS["当前组合"]
print(f"当前组合（净值 {NAV_TOTAL:.2f} 万元）：样本 {st['n']} 个交易日收益")
print(f"  年化收益 {pct(st['ann_ret'])} | 年化波动 {pct(st['ann_vol'])}")
print(f"  1日 VaR95 {pct(st['var95'])} | VaR99 {pct(st['var99'])} | ES95 {pct(st['es95'])} | ES99 {pct(st['es99'])}"
      f"（尾部样本 {st['tail_k99']} 日）")
print(f"  10日 VaR99 {pct(st['var99_10'])}（重叠窗口 {st['roll_n']} 个）")
print(f"  10日最大累计损失 {pct(st['worst10'])}，区间 {st['w10_base']} → {st['w10_end']}")
print(f"  最大回撤 {pct(st['mdd'])}，峰值 {st['mdd_peak']} → 谷底 {st['mdd_trough']}"
      f"，修复日 {st['mdd_rec'] if st['mdd_rec'] is not None else '截至'+str(ASOF.date())+'未修复'}")
print(f"  最差单日 {pct(st['worst1'])}（{st['worst1_day']}）")

print("\n各方案历史风险指标汇总（同一 2112 日样本、每日再平衡）：")
print("  方案            年化收益   年化波动   1日ES99  10日VaR99   最大回撤   期末净值(1元起)")
for k in ["当前组合", "方案A", "方案B", "方案C", "方案D(推荐)"]:
    s_ = STATS[k]
    end_nav = float(np.prod(1.0 + PORT[k]))
    print(f"  {k:<12} {pct(s_['ann_ret']):>8} {pct(s_['ann_vol']):>9} {pct(s_['es99']):>8} "
          f"{pct(s_['var99_10']):>10} {pct(s_['mdd']):>9} {end_nav:>12.3f}")

# 各资产统计特征 + 相关矩阵
legs_desc = LEGS.describe().T[["mean", "std", "min", "max"]]
legs_desc["年化波动"] = LEGS.std() * np.sqrt(ANN)
legs_desc["年化均值"] = LEGS.mean() * ANN
print("\n各资产腿日收益统计：")
print(legs_desc[["年化均值", "年化波动", "min", "max"]].to_string(
    float_format=lambda x: f"{x*100:.2f}%" if abs(x) < 1 else f"{x:.2f}"))
CORR = LEGS.drop(columns=["CNY_CASH"]).corr()
print("\n相关矩阵（人民币现金收益恒为0，不参与相关计算）：")
print(CORR.round(3).to_string())

cov = LEGS.cov().values
wcur = W_CUR
mcr = cov @ wcur
cr = wcur * mcr / (wcur @ mcr)
print("\n当前组合各资产风险贡献占比（协方差法）：")
for leg, c_ in zip(LEG_ORDER, cr):
    print(f"  {leg:<12} {c_*100:8.2f}%")
R["STATS"], R["CORR"], R["CR"] = STATS, CORR, cr

# 稳健性：截至国债实际观测末日的子样本
mask_sub = np.asarray(LEGS.index <= CGB_LAST_REAL)
print(f"\n[稳健性] 子样本（截至 {CGB_LAST_REAL.date()}，n={int(mask_sub.sum())}）ES99/VaR99_10d：")
for k in PLAN_W:
    s2 = risk_stats(PORT[k][mask_sub], LEGS.index[mask_sub].values, k)
    print(f"  {k:<10} ES99={pct(s2['es99'])}  VaR99_10d={pct(s2['var99_10'])}")

# ============================================================================
# S4. 情景月度识别
# ============================================================================
sec("R4 四情景月度识别（规则见 rules_scenarios.csv；月度口径：SSE估值日月末/月均）")

per = TD.to_period("M")
month_td_cnt = pd.Series(1, index=TD).groupby(per).sum()

# 月末价格（对齐后）与月收益
me = P.groupby(per).last()
mret = me.pct_change()

# 10Y 国债月均：仅用实际观测；当月实际观测覆盖 <50% 当月SSE交易日 → 不可评估(NaN)
y10_real = CGB_RAW["10Y"].reindex(TD)
obs_cnt = y10_real.notna().groupby(per).sum()
y10_mavg = y10_real.groupby(per).mean()
y10_mavg[obs_cnt < 0.5 * month_td_cnt] = np.nan

dr_real = DR_RAW.reindex(TD)
dr_mavg = dr_real.groupby(per).mean()

pmi_m = pmi.set_index(pmi["date"].dt.to_period("M"))["pmi_mfg"]
ppi_m = ppi.set_index(ppi["date"].dt.to_period("M"))["ppi_yoy"]
afre_m = afre.set_index(afre["date"].dt.to_period("M"))["afre_stock"]
afre_yoy = (afre_m / afre_m.shift(12) - 1.0) * 100.0     # %

# LPR 下调月份（发布值较上一发布值下降；1Y 或 5Y）
cut_months = set()
for dfx, c in [(lpr1, "lpr_1y"), (lpr5, "lpr_5y")]:
    v = dfx.dropna(subset=[c]).sort_values("date")
    dwn = v[v[c].diff() < -1e-9]
    cut_months |= set(dwn["date"].dt.to_period("M"))
print("LPR 下调月份（1Y∪5Y，发布日口径）：",
      ", ".join(str(m) for m in sorted(cut_months)))

ALL_M = pd.period_range("2018-01", ASOF.to_period("M"), freq="M")
IDENT_M = [m for m in ALL_M if m < ASOF.to_period("M")]   # 当月(2026-09)不完整，不参与识别


def gv(series, m, shift=0):
    try:
        v = series[m - shift]
        return float(v) if pd.notna(v) else np.nan
    except KeyError:
        return np.nan


scen_months = {s: [] for s in ["S1", "S2", "S3", "S4"]}
scen_detail = []
for m in IDENT_M:
    pmi_c, pmi_p = gv(pmi_m, m), gv(pmi_m, m, 1)
    lpr_cut = m in cut_months
    y10_c, y10_p = gv(y10_mavg, m), gv(y10_mavg, m, 1)
    ppi_c, ppi_p = gv(ppi_m, m), gv(ppi_m, m, 1)
    spx_r = gv(mret["spx"], m) if m in mret.index else np.nan
    fx_r = gv(mret["fx"], m) if m in mret.index else np.nan
    hs_r = gv(mret["hs300"], m) if m in mret.index else np.nan
    afy_c, afy_p = gv(afre_yoy, m), gv(afre_yoy, m, 1)
    dr_c, dr_p = gv(dr_mavg, m), gv(dr_mavg, m, 1)

    s1_a = (pmi_c < 50) and lpr_cut
    s1_b = (not np.isnan(pmi_c) and not np.isnan(pmi_p) and (pmi_c - pmi_p <= -0.5)
            and not np.isnan(y10_c) and not np.isnan(y10_p) and y10_c < y10_p)
    s2 = (not np.isnan(ppi_c) and not np.isnan(ppi_p) and ppi_c > ppi_p
          and not np.isnan(y10_c) and not np.isnan(y10_p) and y10_c > y10_p
          and not np.isnan(hs_r) and hs_r < 0)
    s3 = (not np.isnan(spx_r) and spx_r <= -0.03) or (not np.isnan(fx_r) and fx_r >= 0.015)
    s4 = (not np.isnan(afy_c) and not np.isnan(afy_p) and afy_c < afy_p
          and not np.isnan(dr_c) and not np.isnan(dr_p) and dr_c > dr_p
          and not np.isnan(hs_r) and hs_r < 0)
    for sid, flag in [("S1", s1_a or s1_b), ("S2", s2), ("S3", s3), ("S4", s4)]:
        if flag:
            scen_months[sid].append(m)
    scen_detail.append((m, s1_a or s1_b, s2, s3, s4))

for s in ["S1", "S2", "S3", "S4"]:
    nm = rules_scen.set_index("scenario_id").loc[s, "scenario"]
    ms = scen_months[s]
    print(f"\n{s} {nm}: 合格月份 {len(ms)} 个")
    print("   " + ", ".join(str(m) for m in ms))
R["scen_months"], R["IDENT_M"] = scen_months, IDENT_M

# ============================================================================
# S5. 历史窗口构造与校准冲击
# ============================================================================
sec(f"R5 历史窗口（起点=合格月份次月首个SSE交易日，长度={WIN_LEN}个交易日）与校准冲击")

r_cur = PORT_S["当前组合"]


def build_windows(months):
    pool = []
    for m in months:
        nm = m + 1
        days = TD[TD.to_period("M") == nm]
        if len(days) == 0:
            continue
        i0 = TD_POS[days[0]]
        if i0 + WIN_LEN > len(TD):
            pool.append(dict(month=m, start=days[0], end=None, valid=False, reason="窗口超出样本"))
            continue
        win = TD[i0:i0 + WIN_LEN]
        base = TD[i0 - 1]
        end = win[-1]
        rr = r_cur.loc[win].values
        cum = float(np.prod(1.0 + rr) - 1.0)
        allneg = bool((rr < 0).all())
        fac = {c: float(P[c].loc[end] / P[c].loc[base] - 1.0) for c in ["hs300", "zz500", "cyb", "spx", "fx"]}
        if end <= CGB_LAST_REAL and base <= CGB_LAST_REAL:
            dy = {t: float(Y[t].loc[end] - Y[t].loc[base]) for t in TENORS}
            valid = True
        else:
            dy = {t: np.nan for t in TENORS}
            valid = False     # 国债数据截断，收益率累计变动为结构性缺失，窗口不用于校准
        pool.append(dict(month=m, start=win[0], end=end, base=base, valid=valid,
                         cum=cum, allneg=allneg, fac=fac, dy=dy,
                         reason=("国债收益率截断" if not valid else "")))
    return pool


WINDOWS, CALIB = {}, {}
for s in ["S1", "S2", "S3", "S4"]:
    pool = build_windows(scen_months[s])
    valid = [w for w in pool if w.get("valid", False)]
    invalid_n = len(pool) - len(valid)
    strict = sorted([w for w in valid if w["allneg"]], key=lambda w: w["cum"])
    rest = sorted([w for w in valid if not w["allneg"]], key=lambda w: w["cum"])
    if len(strict) >= MIN_WIN:
        selected = strict[:MIN_WIN]
        rule_note = f"全部为负窗口 {len(strict)} 个 ≥ {MIN_WIN}，按累计跌幅取最差 {MIN_WIN} 个"
    else:
        selected = strict + rest[: max(0, MIN_WIN - len(strict))]
        rule_note = (f"全部为负窗口仅 {len(strict)} 个 < {MIN_WIN}，全取后按累计跌幅从其余窗口补足至 "
                     f"{len(selected)} 个（放宽已披露）")
    WINDOWS[s] = dict(pool=pool, valid=valid, strict=strict, selected=selected, note=rule_note,
                      invalid_n=invalid_n)
    if selected:
        cal = {c: float(np.median([w["fac"][c] for w in selected])) for c in ["hs300", "zz500", "cyb", "spx", "fx"]}
        cal_dy = {t: float(np.median([w["dy"][t] for w in selected])) for t in TENORS}
    else:
        cal = {c: np.nan for c in ["hs300", "zz500", "cyb", "spx", "fx"]}
        cal_dy = {t: np.nan for t in TENORS}
    CALIB[s] = dict(fac=cal, dy=cal_dy)
    nm = rules_scen.set_index("scenario_id").loc[s, "scenario"]
    print(f"\n{s} {nm}: 候选窗口 {len(pool)}（可用 {len(valid)}，因国债截断剔除 {invalid_n}）；{rule_note}")
    print(f"   校准冲击(中位数): 沪深300 {cal['hs300']*100:.2f}% | 中证500 {cal['zz500']*100:.2f}% | "
          f"创业板 {cal['cyb']*100:.2f}% | 标普500(USD) {cal['spx']*100:.2f}% | USDCNH {cal['fx']*100:.2f}%")
    print("   国债Δy(bp): " + " | ".join(f"{t} {cal_dy[t]*100:+.2f}" for t in TENORS))
    print(f"   选定窗口明细（前{min(len(selected),25)}个）：")
    for w in selected[:25]:
        print(f"      {w['start'].date()} → {w['end'].date()}  组合累计 {w['cum']*100:6.2f}%  全负={w['allneg']}")

R["WINDOWS"], R["CALIB"] = WINDOWS, CALIB

# ============================================================================
# S6. 压力测试：4方案 × 4情景 × 2套冲击（四部分贡献拆分）
# ============================================================================
sec("R6 压力测试（4方案 × 4情景 × 2套冲击；四部分贡献之和 = 组合损益；人民币现金贡献恒为0）")


def parse_committee_dy(s):
    d = {}
    for kv in s.split(","):
        k, v = kv.split(":")
        d[k.strip()] = float(v)
    return {t: d[t] for t in TENORS}   # 单位：百分点(pp)；+0.10pp = +10bp

COMM_SHOCK = {}
for r_ in comm.itertuples():
    COMM_SHOCK[r_.scenario_id] = dict(eq=r_.cn_equity_shock, spx=r_.spx_usd_shock,
                                      fx=r_.usdcnh_shock, dy=parse_committee_dy(r_.cgb_shock_bp))
SCEN_NAME = rules_scen.set_index("scenario_id")["scenario"].to_dict()


def stress_one(w, eq300, eq905, eqcyb, spx, fx, dy):
    """返回四部分贡献与合计（占净值比例，负=损失）；dy 单位：百分点pp。"""
    c_eq = w[0] * eq300 + w[1] * eq905 + w[2] * eqcyb
    c_spx = w[5] * ((1.0 + spx) * (1.0 + fx) - 1.0)     # 复合折算
    c_usd = w[4] * fx
    c_cgb = w[3] * (-float(sum(DC[t] * dy[t] for t in TENORS)) / 100.0)
    tot = c_eq + c_spx + c_usd + c_cgb
    return dict(eq=c_eq, spx=c_spx, usd=c_usd, cgb=c_cgb, total=tot)


STRESS = {}     # STRESS[(plan, scen, setname)] = dict
for pname in STRESS_PLANS:
    w = PLAN_W[pname]
    for s in ["S1", "S2", "S3", "S4"]:
        cs = COMM_SHOCK[s]
        STRESS[(pname, s, "委员会沿用")] = stress_one(w, cs["eq"], cs["eq"], cs["eq"],
                                                      cs["spx"], cs["fx"], cs["dy"])
        cb = CALIB[s]
        STRESS[(pname, s, "历史校准")] = stress_one(w, cb["fac"]["hs300"], cb["fac"]["zz500"],
                                                    cb["fac"]["cyb"], cb["fac"]["spx"],
                                                    cb["fac"]["fx"], cb["dy"])
# 当前组合（补充参考）
for s in ["S1", "S2", "S3", "S4"]:
    cs = COMM_SHOCK[s]
    STRESS[("当前组合", s, "委员会沿用")] = stress_one(W_CUR, cs["eq"], cs["eq"], cs["eq"],
                                                      cs["spx"], cs["fx"], cs["dy"])
    cb = CALIB[s]
    STRESS[("当前组合", s, "历史校准")] = stress_one(W_CUR, cb["fac"]["hs300"], cb["fac"]["zz500"],
                                                     cb["fac"]["cyb"], cb["fac"]["spx"],
                                                     cb["fac"]["fx"], cb["dy"])

print("委员会沿用冲击参数（cgb_shock_bp 字段数值为百分点pp，+0.10pp=+10bp）：")
for s in ["S1", "S2", "S3", "S4"]:
    cs = COMM_SHOCK[s]
    print(f"  {s} {SCEN_NAME[s]}: 境内权益 {cs['eq']*100:+.2f}% | 标普USD {cs['spx']*100:+.2f}% | "
          f"USDCNH {cs['fx']*100:+.2f}% | Δy " + ",".join(f"{t}{cs['dy'][t]*100:+.0f}bp" for t in TENORS))

MAXLOSS = {}
for pname in list(STRESS_PLANS) + ["当前组合"]:
    print(f"\n—— {pname}（{PLAN_PROPOSER[pname]}）压力损益矩阵（占净值%，负=损失）——")
    print(f"{'情景':<14}{'冲击套':<8}{'境内权益':>10}{'标普CNY':>10}{'美元现金':>10}{'国债':>10}{'合计':>10}")
    ml, ml_src = 0.0, None
    for s in ["S1", "S2", "S3", "S4"]:
        for setn in ["委员会沿用", "历史校准"]:
            d = STRESS[(pname, s, setn)]
            print(f"{s+' '+SCEN_NAME[s]:<14}{setn:<8}{d['eq']*100:>9.2f}%{d['spx']*100:>9.2f}%"
                  f"{d['usd']*100:>9.2f}%{d['cgb']*100:>9.2f}%{d['total']*100:>9.2f}%")
            if -d["total"] > ml:
                ml, ml_src = -d["total"], (s, setn)
    MAXLOSS[pname] = (ml, ml_src)
    print(f"  → 最大压力损失 {pct(ml)}，来源：{ml_src[0]} {SCEN_NAME[ml_src[0]]}（{ml_src[1]}冲击）")
R["STRESS"], R["MAXLOSS"] = STRESS, MAXLOSS

# ============================================================================
# S7. 九项约束逐条检查
# ============================================================================
sec("R7 九项约束逐条检查（C1–C9；C9 仅对拟推荐方案适用）")

CHECK_ROWS = {}
for pname in PLAN_W:
    w = PLAN_W[pname]
    s_ = STATS[pname]
    ml = MAXLOSS[pname][0]
    rows = []
    rows.append(("C1", "权重合计=100%", w.sum(), abs(w.sum() - 1.0) <= C1_TOL,
                 f"合计={pct(w.sum())}（容差{C1_TOL*100:.2f}pp）"))
    eq_sum = w[:3].sum()
    rows.append(("C2", f"境内权益≤{LIM['L2_eq_max']*100:.0f}%", eq_sum, eq_sum <= LIM["L2_eq_max"] + 1e-12,
                 f"{pct(eq_sum)}" + (f" 超限{pct(eq_sum - LIM['L2_eq_max'])}" if eq_sum > LIM["L2_eq_max"] else "")))
    rows.append(("C3", f"人民币现金∈[{LIM['L3_lo']*100:.0f}%,{LIM['L3_hi']*100:.0f}%]", w[6],
                 LIM["L3_lo"] - 1e-12 <= w[6] <= LIM["L3_hi"] + 1e-12, f"{pct(w[6])}"))
    rows.append(("C4", f"国债≥{LIM['L4_lo']*100:.0f}%", w[3], w[3] >= LIM["L4_lo"] - 1e-12,
                 f"{pct(w[3])}" + (f" 缺口{pct(LIM['L4_lo'] - w[3])}" if w[3] < LIM["L4_lo"] else "")))
    fx_exp = w[4] + w[5]
    rows.append(("C5", f"外币敞口≤{LIM['L5_max']*100:.0f}%", fx_exp, fx_exp <= LIM["L5_max"] + 1e-12,
                 f"美元现金{pct(w[4])}+QDII{pct(w[5])}={pct(fx_exp)}"
                 + (f" 超限{pct(fx_exp - LIM['L5_max'])}" if fx_exp > LIM["L5_max"] else "")))
    rows.append(("C6", f"1日ES99≤{LIM['L6_es99']*100:.1f}%", s_["es99"], s_["es99"] <= LIM["L6_es99"] + 1e-12,
                 f"{pct(s_['es99'])}" + (f" 超限{pct(s_['es99'] - LIM['L6_es99'])}" if s_["es99"] > LIM["L6_es99"] else "")))
    rows.append(("C7", f"10日VaR99≤{LIM['L7_var99_10']*100:.1f}%", s_["var99_10"],
                 s_["var99_10"] <= LIM["L7_var99_10"] + 1e-12,
                 f"{pct(s_['var99_10'])}" + (f" 超限{pct(s_['var99_10'] - LIM['L7_var99_10'])}" if s_["var99_10"] > LIM["L7_var99_10"] else "")))
    rows.append(("C8", f"最大压力损失≤{LIM['L8_stress']*100:.1f}%", ml, ml <= LIM["L8_stress"] + 1e-12,
                 f"{pct(ml)}" + (f" 超限{pct(ml - LIM['L8_stress'])}" if ml > LIM["L8_stress"] else "")
                 + f"（来源 {MAXLOSS[pname][1][0]}/{MAXLOSS[pname][1][1]}）"))
    if pname == "方案D(推荐)":
        rows.append(("C9", f"推荐方案压力损失≤{LIM['L9_stress_rec']*100:.1f}%", ml,
                     ml <= LIM["L9_stress_rec"] + 1e-12,
                     f"{pct(ml)}，缓冲余量 {pct(LIM['L9_stress_rec'] - ml)}"))
    else:
        rows.append(("C9", "仅对拟推荐方案适用", np.nan, None, "不适用（非拟推荐方案）"))
    CHECK_ROWS[pname] = rows

for pname, rows in CHECK_ROWS.items():
    print(f"\n—— {pname}（{PLAN_PROPOSER[pname]}）——")
    for cid, desc, val, ok, msg in rows:
        status = {True: "通过", False: "未通过", None: "N/A"}[ok]
        print(f"  {cid} {desc:<28} [{status}]  {msg}")
R["CHECK_ROWS"] = CHECK_ROWS

# ============================================================================
# S8. 调仓执行：交易清单、现金路径、换手率；推荐方案唯一性验证
# ============================================================================
sec("R8 推荐方案调仓执行（先卖出后买入 vs 先买入后卖出）与唯一性验证")

delta = (W_REC - W_CUR) * NAV_TOTAL     # 万元
legs_cn = {"EQ_000300": "沪深300指数基金", "EQ_000905": "中证500指数基金",
           "EQ_399006": "创业板指数基金", "CGB": "中长期国债组合",
           "USD_CASH": "美元现金及存款", "SPX": "标普500 QDII基金",
           "CNY_CASH": "人民币现金及货基"}
sells = [(legs_cn[l], -d) for l, d in zip(LEG_ORDER, delta) if d < -1e-9]
# 人民币现金及货基的增量是卖出未再投资的"残差"，不是主动买入交易，
# 因此不进入交易清单与现金扣款路径（现金路径终点自然回到目标 20%）。
buys = [(legs_cn[l], d) for l, d in zip(LEG_ORDER, delta) if d > 1e-9 and l != "CNY_CASH"]
residual_cash = float(delta[LEG_ORDER.index("CNY_CASH")]) if "CNY_CASH" in LEG_ORDER else 0.0
turnover = sum(a for _, a in sells) / NAV_TOTAL
print("交易清单（按执行顺序，金额万元）：")
for i, (nm, amt) in enumerate(sells, 1):
    print(f"  {i}. 卖出 {nm:<12} {amt:10.2f} 万元")
for i, (nm, amt) in enumerate(buys, len(sells) + 1):
    print(f"  {i}. 买入 {nm:<12} {amt:10.2f} 万元")
print(f"  （人民币现金及货基 +{residual_cash:.2f} 万元 = 卖出回笼 − 买入国债的残差，非交易指令）")
print(f"单向换手率 = 卖出合计/净值 = {sum(a for _, a in sells):.2f}/{NAV_TOTAL:.2f} = {pct(turnover)}")
print("QDII 结算规则：本次推荐方案不涉及标普500 QDII 申赎（权重不变），T+7 规则不触发。")

cash0 = W_CUR[6]
# 路径1：先卖出后买入（规则顺序）
path_sell_first = [cash0]
c = cash0
for nm, amt in sells:
    c += amt / NAV_TOTAL          # 卖出资金当日可用
    path_sell_first.append(c)
for nm, amt in buys:
    c -= amt / NAV_TOTAL          # 买入国债当日扣款
    path_sell_first.append(c)
# 路径2：先买入后卖出（对照）
path_buy_first = [cash0]
c = cash0
for nm, amt in buys:
    c -= amt / NAV_TOTAL
    path_buy_first.append(c)
for nm, amt in sells:
    c += amt / NAV_TOTAL
    path_buy_first.append(c)

print(f"\n现金占比路径（下限 {pct(CASH_FLOOR)}，净值 {NAV_TOTAL:.0f} 万元）：")
print("  先卖出后买入：" + " → ".join(f"{x*100:.2f}%" for x in path_sell_first))
print(f"    最低点 {min(path_sell_first)*100:.2f}%，"
      f"{'未击穿' if min(path_sell_first) >= CASH_FLOOR - 1e-12 else '击穿'} {CASH_FLOOR*100:.0f}% 下限")
print("  先买入后卖出：" + " → ".join(f"{x*100:.2f}%" for x in path_buy_first))
print(f"    最低点 {min(path_buy_first)*100:.2f}%，"
      f"{'未击穿' if min(path_buy_first) >= CASH_FLOOR - 1e-12 else '击穿'} {CASH_FLOOR*100:.0f}% 下限")
R["exec"] = dict(sells=sells, buys=buys, turnover=turnover,
                 path_sell_first=path_sell_first, path_buy_first=path_buy_first)

# ---- 唯一性验证：0.5% 步长网格搜索（美元现金与QDII固定10%，五项自由权重合计80%）----
print("\n[唯一性验证] 网格搜索：固定 w_usd=10%, w_spx=10%（recommendation_rule 前提），"
      "五项自由权重步长0.5%，合计80%；通过全部九项（C9按≤7%）为可行。")
unit = 0.005
TOTU = int(round(0.80 / unit))          # 160
wcur5_u = np.array([0.25, 0.15, 0.10, 0.20, 0.10]) / unit   # [50,30,20,40,20]

# 每(情景,冲击套)的“损失”系数：loss = W·v；拆分固定腿贡献
V_rows = []
for s in ["S1", "S2", "S3", "S4"]:
    for setn in ["委员会沿用", "历史校准"]:
        if setn == "委员会沿用":
            cs = COMM_SHOCK[s]
            e3 = e5 = e9 = cs["eq"]; spx = cs["spx"]; fx = cs["fx"]; dy = cs["dy"]
        else:
            cb = CALIB[s]
            e3, e5, e9 = cb["fac"]["hs300"], cb["fac"]["zz500"], cb["fac"]["cyb"]
            spx, fx, dy = cb["fac"]["spx"], cb["fac"]["fx"], cb["dy"]
        v5 = np.array([-e3, -e5, -e9,
                       float(sum(DC[t] * dy[t] for t in TENORS)) / 100.0, 0.0])
        const = 0.10 * (-((1 + spx) * (1 + fx) - 1)) + 0.10 * (-fx)
        V_rows.append((v5, const))
V5 = np.array([v for v, _ in V_rows], dtype=np.float32)
Vconst = np.array([c_ for _, c_ in V_rows], dtype=np.float32)

# 预取收益矩阵（自由5腿 + 固定腿）
Rf = LEGS[["EQ_000300", "EQ_000905", "EQ_399006", "CGB", "CNY_CASH"]].values.astype(np.float32)
fixed_part = (0.10 * LEGS["USD_CASH"].values + 0.10 * LEGS["SPX"].values).astype(np.float32)
Tn = Rf.shape[0]
cumF = np.concatenate([[0.0], np.cumsum(np.log1p(fixed_part))]).astype(np.float32)

surv = []
for x1 in range(TOTU + 1):
    Rm = TOTU - x1
    A_, B_ = np.meshgrid(np.arange(Rm + 1), np.arange(Rm + 1), indexing="ij")
    msk = (A_ + B_) <= Rm
    a = A_[msk].astype(np.int32); b = B_[msk].astype(np.int32)
    rem = Rm - a - b
    cnt = rem + 1
    x2 = np.repeat(a, cnt); x3 = np.repeat(b, cnt)
    x4 = np.arange(cnt.sum()) - np.repeat(np.cumsum(cnt) - cnt, cnt)
    x5 = np.repeat(rem, cnt) - x4
    U = np.stack([np.full(x2.shape, x1, dtype=np.int32), x2, x3, x4, x5], axis=1)
    # 静态限额（单位化）
    ok = ((U[:, 4] >= int(round(LIM["L3_lo"] / unit))) & (U[:, 4] <= int(round(LIM["L3_hi"] / unit))
          ) & (U[:, 3] >= int(round(LIM["L4_lo"] / unit)))
          & (U[:, 0] + U[:, 1] + U[:, 2] <= int(round(LIM["L2_eq_max"] / unit))))
    U = U[ok]
    if len(U) == 0:
        continue
    Wf = U.astype(np.float32) * np.float32(unit)
    sells_u = np.clip(wcur5_u.astype(np.float32) - U.astype(np.float32), 0, None).sum(axis=1) * np.float32(unit)
    keep = sells_u <= 0.255  # 预留缓冲：单向换手≤25.5%以内参与搜索
    U, Wf, sells_u = U[keep], Wf[keep], sells_u[keep]
    if len(U) == 0:
        continue
    losses = Wf @ V5.T + Vconst          # n×8 最大压力损失
    mx = losses.max(axis=1)
    keep2 = mx <= LIM["L9_stress_rec"] + 1e-9   # C9（作为拟推荐候选全部按≤7%）
    if keep2.any():
        surv.append((U[keep2], Wf[keep2], sells_u[keep2], mx[keep2]))

if surv:
    U = np.concatenate([s[0] for s in surv]); Wf = np.concatenate([s[1] for s in surv])
    sells_u = np.concatenate([s[2] for s in surv]); mx = np.concatenate([s[3] for s in surv])
    print(f"  静态+C8/C9 压力过滤后存活 {len(U)} 个组合，逐一计算 ES99/VaR99_10d ...")
    keep3 = np.ones(len(U), dtype=bool)
    CH = 20000
    es_all = np.full(len(U), np.nan, dtype=np.float32)
    v10_all = np.full(len(U), np.nan, dtype=np.float32)
    k99 = max(1, int(np.floor(0.01 * Tn)))
    for i0 in range(0, len(U), CH):
        i1 = min(i0 + CH, len(U))
        Pm = Wf[i0:i1] @ Rf.T + fixed_part          # chunk×T
        srt = -np.partition(Pm, k99 - 1, axis=1)[:, :k99]
        es_all[i0:i1] = srt.mean(axis=1)
        L = np.log1p(np.maximum(Pm, -0.999999))
        C = np.cumsum(L, axis=1)
        C = np.concatenate([np.zeros((i1 - i0, 1), dtype=np.float32), C], axis=1)
        rollm = np.expm1(C[:, WIN_LEN:] - C[:, :-WIN_LEN])
        v10_all[i0:i1] = -np.percentile(rollm, 1, axis=1)
        keep3[i0:i1] = (es_all[i0:i1] <= LIM["L6_es99"] + 1e-9) & (v10_all[i0:i1] <= LIM["L7_var99_10"] + 1e-9)
    Uf, Wff, tof, mxf = U[keep3], Wf[keep3], sells_u[keep3], mx[keep3]
    esf, v10f = es_all[keep3], v10_all[keep3]
    print(f"  通过全部九项的可行组合数 = {len(Uf)}")
    if len(Uf):
        Tmin = tof.min()
        at_min = tof <= Tmin + 1e-9
        print(f"  网格内最小单向换手率 = {Tmin*100:.2f}%，达到该换手率的可行组合 {int(at_min.sum())} 个")
        order = np.lexsort((mxf, tof))
        print("  可行组合按(换手率,最大压力损失)排序前10：")
        for i in order[:10]:
            w5 = Wff[i] * 100
            print(f"    w300={w5[0]:.1f} w905={w5[1]:.1f} wcyb={w5[2]:.1f} wcgb={w5[3]:.1f} wcny={w5[4]:.1f} "
                  f"| 换手 {tof[i]*100:.2f}% | 最大压力 {mxf[i]*100:.2f}% | ES99 {esf[i]*100:.2f}% | VaR99_10d {v10f[i]*100:.2f}%")
        # 同换手率下与推荐方案最接近的比例结构组合 & 最优替代
        alt = order[at_min[order]][0]
        R["uniq"] = dict(n_feasible=int(len(Uf)), Tmin=float(Tmin), n_at_min=int(at_min.sum()),
                         best_alt=Wff[alt].copy(), best_alt_metrics=(float(tof[alt]), float(mxf[alt]), float(esf[alt]), float(v10f[alt])))
        print(f"  推荐方案(精确权重,网格外): 换手 {pct(turnover)} | 最大压力 {pct(MAXLOSS['方案D(推荐)'][0])} | "
              f"ES99 {pct(STATS['方案D(推荐)']['es99'])} | VaR99_10d {pct(STATS['方案D(推荐)']['var99_10'])}")
        # —— 唯一性：同换手率预算（≤推荐方案）下的次优组合比较 ——
        bud = tof <= turnover + 1e-9
        ib = int(np.argmin(np.where(bud, mxf, np.inf)))
        w5b = Wff[ib] * 100
        print(f"  同换手率预算（≤{turnover*100:.2f}%）内可行组合 {int(bud.sum())} 个；其中最大压力损失最小者：")
        print(f"    w300={w5b[0]:.1f} w905={w5b[1]:.1f} wcyb={w5b[2]:.1f} wcgb={w5b[3]:.1f} wcny={w5b[4]:.1f} "
              f"| 换手 {tof[ib]*100:.2f}% | 最大压力 {mxf[ib]*100:.2f}% | ES99 {esf[ib]*100:.2f}% | VaR99_10d {v10f[ib]*100:.2f}%")
        # 规则结构族（境内权益 25:15:10 同比例、现金 20%、权益+国债=60%）在预算内的网格点
        prop = (bud & (np.abs(3 * Wff[:, 0] - 5 * Wff[:, 1]) < 1e-5)
                & (np.abs(2 * Wff[:, 0] - 5 * Wff[:, 2]) < 1e-5)
                & (np.abs(Wff[:, 4] - 0.20) < 1e-6)
                & (np.abs(Wff[:, 0] + Wff[:, 1] + Wff[:, 2] + Wff[:, 3] - 0.60) < 1e-5))
        mlD_, esD_, v10D_ = MAXLOSS["方案D(推荐)"][0], STATS["方案D(推荐)"]["es99"], STATS["方案D(推荐)"]["var99_10"]
        weak_dom = bud & (mxf <= mlD_ + 1e-9) & (esf <= esD_ + 1e-9) & (v10f <= v10D_ + 1e-9)
        print(f"  预算内满足 recommendation_rule 同比例结构的网格组合 = {int(prop.sum())} 个"
              f"（缩减系数 k=0.6/0.7/0.8/0.9 的近似点；k=0.59 的推荐方案本身不在 0.5% 网格上）")
        for i in np.where(prop)[0][:6]:
            w5 = Wff[i] * 100
            print(f"    k≈{(w5[0]/25):.2f}: w300={w5[0]:.1f} w905={w5[1]:.1f} wcyb={w5[2]:.1f} wcgb={w5[3]:.1f} wcny={w5[4]:.1f} "
                  f"| 换手 {tof[i]*100:.2f}% | 最大压力 {mxf[i]*100:.2f}%")
        print(f"  预算内在(最大压力,ES99,VaR99_10d)三指标上均不劣于推荐方案的组合 = {int(weak_dom.sum())} 个，"
              f"其中满足规则同比例结构的 = {int((weak_dom & prop).sum())} 个")
        R["uniq"].update(budget_n=int(bud.sum()),
                         budget_best_w=Wff[ib].copy(),
                         budget_best_metrics=(float(tof[ib]), float(mxf[ib]), float(esf[ib]), float(v10f[ib])),
                         n_prop=int(prop.sum()), n_weak_dom=int(weak_dom.sum()),
                         n_weak_dom_prop=int((weak_dom & prop).sum()))
    else:
        R["uniq"] = dict(n_feasible=0)
else:
    print("  无可行组合")
    R["uniq"] = dict(n_feasible=0)

# ============================================================================
# S9. 反向压力测试（最小马氏距离）与距离对比
# ============================================================================
sec("R9 反向压力测试：令推荐方案损失=7%缓冲线的最小马氏距离情景")

# 因子矩阵：10日滚动窗口累计变动（基点日 t → t+10），仅用国债实际观测期内的窗口
fac_cols = ["hs300", "zz500", "cyb", "spx", "fx"]
n_td = len(TD)
rowsZ = []
for i in range(0, n_td - WIN_LEN):
    end = TD[i + WIN_LEN]
    if end > CGB_LAST_REAL:
        break
    z = [P[c].iloc[i + WIN_LEN] / P[c].iloc[i] - 1.0 for c in fac_cols]
    z.append(Y["10Y"].iloc[i + WIN_LEN] - Y["10Y"].iloc[i])   # pp
    rowsZ.append(z)
Z = np.array(rowsZ, dtype=float)
mu = Z.mean(axis=0)
Sg = np.cov(Z, rowvar=False)
Sinv = np.linalg.inv(Sg)
print(f"历史10日窗口样本 n={len(Z)}（窗口终点≤{CGB_LAST_REAL.date()}，避免国债截断期污染）")
print("因子均值：", ", ".join(f"{c}={mu[i]*100:.2f}%" if i < 5 else f"Δy10y={mu[i]*100:.1f}bp"
                             for i, c in enumerate(fac_cols + ["Δy10y"])))

wD = W_REC
# z6 = Δy10Y（平行移位代理，单位 pp）：损失贡献 = w_cgb × DC_SUM × z6 / 100
c_lin = np.array([-wD[0], -wD[1], -wD[2], -wD[5], -(wD[5] + wD[4]), DC_SUM * wD[3] / 100.0])
q_bi = -wD[5]

def loss_z(z):
    return float(c_lin @ z + q_bi * z[3] * z[4])

def maha(z):
    d = z - mu
    return float(np.sqrt(d @ Sinv @ d))

TARGET = LIM["L9_stress_rec"]     # 0.07

# KKT 定点迭代：z = mu + s·Σ·g(z)，g=∇loss(z)，s=λ/2；两根中取马氏距离较小者
z = mu.copy()
for it in range(1000):
    g = c_lin.copy()
    g[3] += q_bi * z[4]
    g[4] += q_bi * z[3]
    v = Sg @ g
    A_ = q_bi * v[3] * v[4]
    B_ = c_lin @ v + q_bi * (mu[3] * v[4] + mu[4] * v[3])
    C_ = loss_z(mu) - TARGET
    if abs(A_) < 1e-14:
        roots = [-C_ / B_] if abs(B_) > 1e-14 else [0.0]
    else:
        disc = max(B_ * B_ - 4 * A_ * C_, 0.0)
        roots = [(-B_ + np.sqrt(disc)) / (2 * A_), (-B_ - np.sqrt(disc)) / (2 * A_)]
    cands = []
    for s_ in roots:
        zz = mu + s_ * v
        if abs(loss_z(zz) - TARGET) < 1e-8:
            cands.append(zz)
    if not cands:
        break
    z_new = min(cands, key=lambda zz: float((zz - mu) @ Sinv @ (zz - mu)))
    if np.max(np.abs(z_new - z)) < 1e-13:
        z = z_new
        break
    z = z_new
z_star = z
assert abs(loss_z(z_star) - TARGET) < 1e-8, f"反向压力约束未精确满足: {loss_z(z_star)}"
D_star = maha(z_star)
print(f"\n反向压力情景（推荐方案损失={TARGET*100:.2f}%，最小马氏距离解）：")
lbls = ["沪深300(10日)", "中证500(10日)", "创业板(10日)", "标普500USD(10日)", "USDCNH(10日)"]
for i, l in enumerate(lbls):
    print(f"  {l:<18} {z_star[i]*100:+8.2f}%")
print(f"  {'Δy10Y(平行移位代理)':<18} {z_star[5]*100:+8.2f}bp")
print(f"  组合损失 = {loss_z(z_star)*100:.2f}% | 最小马氏距离 = {D_star:.3f}")
# 最优性数值验证：切向扰动
gr = c_lin.copy(); gr[3] += q_bi * z_star[4]; gr[4] += q_bi * z_star[3]
rng = np.random.default_rng(7)
ok_opt = True
for _ in range(300):
    u = rng.normal(size=6)
    u = u - (u @ Sinv @ gr) / (gr @ Sinv @ gr) * gr
    for eps in (1e-4, 1e-3):
        zp = z_star + eps * u
        # 投影回约束面（沿∇loss方向牛顿一步）
        for _k in range(50):
            f = loss_z(zp) - TARGET
            gg = c_lin.copy(); gg[3] += q_bi * zp[4]; gg[4] += q_bi * zp[3]
            step = f / (gg @ gg)
            zp = zp - step * gg
            if abs(f) < 1e-12:
                break
        if maha(zp) < D_star - 1e-8:
            ok_opt = False
print(f"  切向扰动数值验证最小性：{'通过' if ok_opt else '未通过'}")

# 各情景向量与距离
def scen_vec(eq3, eq5, eq9, spx, fx, dy):
    dypar = float(sum(DC[t] * dy[t] for t in TENORS)) / DC_SUM
    return np.array([eq3, eq5, eq9, spx, fx, dypar])

DIST = {}
print("\n各情景马氏距离与推荐方案损失：")
for s in ["S1", "S2", "S3", "S4"]:
    cs = COMM_SHOCK[s]
    zv = scen_vec(cs["eq"], cs["eq"], cs["eq"], cs["spx"], cs["fx"], cs["dy"])
    cb = CALIB[s]
    zc = scen_vec(cb["fac"]["hs300"], cb["fac"]["zz500"], cb["fac"]["cyb"],
                  cb["fac"]["spx"], cb["fac"]["fx"], cb["dy"])
    DIST[(s, "委员会沿用")] = (maha(zv), loss_z(zv), zv)
    DIST[(s, "历史校准")] = (maha(zc), loss_z(zc), zc)
    print(f"  {s} {SCEN_NAME[s]}: 委员会 D={DIST[(s,'委员会沿用')][0]:.3f} 损失={DIST[(s,'委员会沿用')][1]*100:.2f}%"
          f" | 校准 D={DIST[(s,'历史校准')][0]:.3f} 损失={DIST[(s,'历史校准')][1]*100:.2f}%")

# 历史最差窗口（对推荐方案损失最大的历史10日窗口）
loss_hist = Z @ c_lin + q_bi * Z[:, 3] * Z[:, 4]
ih = int(np.argmax(loss_hist))
print(f"\n历史窗口中对推荐方案损失最大者：损失 {loss_hist[ih]*100:.2f}%，马氏距离 {maha(Z[ih]):.3f}")
print("  因子：" + ", ".join(f"{lbls[i]}={Z[ih][i]*100:+.2f}%" for i in range(5))
      + f", Δy10y={Z[ih][5]*100:+.2f}bp")
print(f"  窗口区间：{TD[ih].date()} → {TD[ih+WIN_LEN].date()}")

# 裕度与放大倍数
mlD, srcD = MAXLOSS["方案D(推荐)"]
margin = TARGET - mlD
z_base = DIST[srcD][2]
def loss_scaled(k):
    zz = mu + k * (z_base - mu)
    return loss_z(zz)
lo, hi = 0.0, 100.0
assert loss_scaled(0) < TARGET < loss_scaled(hi), "放大倍数二分区间无效"
for _ in range(200):
    mid = (lo + hi) / 2
    if loss_scaled(mid) < TARGET:
        lo = mid
    else:
        hi = mid
k_amp = (lo + hi) / 2
print(f"\n推荐方案最大压力损失 {pct(mlD)}（{srcD[0]}/{srcD[1]}）；对 {TARGET*100:.0f}% 缓冲线裕度 = {pct(margin)}")
print(f"将最大损失情景自历史均值向该情景整体放大 {k_amp:.2f} 倍即触及 7% 缓冲线")
print("反向压力情景 vs 最大损失情景（因子级倍数）：")
for i, l in enumerate(lbls + ["Δy10y"]):
    b = z_base[i]
    ratio = z_star[i] / b if abs(b) > 1e-9 else np.nan
    print(f"  {l:<18} 反向 {z_star[i]*100:+8.2f}{'%' if i<5 else 'bp'} vs 情景 {b*100:+8.2f}{'%' if i<5 else 'bp'}  倍数 {ratio:.2f}")
R["rev"] = dict(z_star=z_star, D_star=D_star, DIST=DIST, loss_hist_max=float(loss_hist[ih]),
                D_hist_max=maha(Z[ih]), k_amp=float(k_amp), margin=float(margin),
                mlD=float(mlD), srcD=srcD, Z=Z, mu=mu, lbls=lbls, win_hist=(TD[ih], TD[ih+WIN_LEN]))

# ============================================================================
# S10. 监测指标 M1–M8
# ============================================================================
sec("R10 八个监测指标（阈值读取自 template_monitor.csv）")


def parse_thr(txt):
    txt = txt.strip().replace("+", "")
    if txt.endswith("bp"):
        return float(txt[:-2]) / 10000.0 * 100.0        # bp → 百分点数值（与序列同单位）
    if txt.endswith("%"):
        return float(txt[:-1]) / 100.0
    if "个百分点" in txt:
        return float(txt.replace("个百分点", ""))
    return float(txt)

mon_rows = []
tpl = monitor_tpl.set_index("monitor_id")

# M1 沪深300 20日收益
v = P["hs300"].iloc[-1] / P["hs300"].iloc[-21] - 1.0
mon_rows.append(("M1", v, ASOF, v < parse_thr(tpl.loc["M1", "threshold"])))
# M2 USDCNH 20日变化
v = P["fx"].iloc[-1] / P["fx"].iloc[-21] - 1.0
mon_rows.append(("M2", v, ASOF, v > parse_thr(tpl.loc["M2", "threshold"])))
# M3 DR007 近20日均值 vs 前60日均值（bp）
dr_td = DR_AL.dropna()
v = (dr_td.iloc[-20:].mean() - dr_td.iloc[-80:-20].mean())   # 百分点
mon_rows.append(("M3", v, dr_td.index[-1], v > parse_thr(tpl.loc["M3", "threshold"])))
# M4 10Y国债 20个交易日累计变动（实际观测，截至截断日）
y10v = CGB_RAW["10Y"].reindex(TD).dropna()
v = y10v.iloc[-1] - y10v.iloc[-21]
mon_rows.append(("M4", v, y10v.index[-1], v > parse_thr(tpl.loc["M4", "threshold"])))
# M5 美债10Y 20个交易日累计变动（对齐ff）
v = UST10_AL.iloc[-1] - UST10_AL.iloc[-21]
mon_rows.append(("M5", v, ASOF, v > parse_thr(tpl.loc["M5", "threshold"])))
# M6 PPI 同比 vs 3个月前（个百分点）
v = float(ppi_m.iloc[-1] - ppi_m[ppi_m.index[-1] - 3])
mon_rows.append(("M6", v, ppi["date"].max(), v > parse_thr(tpl.loc["M6", "threshold"])))
# M7 PMI 最新月值
v = float(pmi_m.iloc[-1])
mon_rows.append(("M7", v, pmi["date"].max(), v < parse_thr(tpl.loc["M7", "threshold"])))
# M8 社融存量同比最新月值（%）
v = float(afre_yoy.dropna().iloc[-1])
mon_rows.append(("M8", v / 100.0, afre["date"].max(), v / 100.0 < parse_thr(tpl.loc["M8", "threshold"])))

print("| monitor_id | 指标 | 阈值 | 方向 | 最新值 | 数据截至 | 状态 | 是否触发 |")
print("|---|---|---|---|---|---|---|---|")
fmtmap = {"M1": lambda x: f"{x*100:+.2f}%", "M2": lambda x: f"{x*100:+.2f}%",
          "M3": lambda x: f"{x*100:+.2f}bp", "M4": lambda x: f"{x*100:+.2f}bp",
          "M5": lambda x: f"{x*100:+.2f}bp", "M6": lambda x: f"{x:+.2f}个百分点",
          "M7": lambda x: f"{x:.2f}", "M8": lambda x: f"{x*100:.2f}%"}
for mid, v, asof, trg in mon_rows:
    print(f"| {mid} | {tpl.loc[mid,'indicator']} | {tpl.loc[mid,'threshold']} | {tpl.loc[mid,'direction']} | "
          f"{fmtmap[mid](v)} | {pd.Timestamp(asof).date()} | {'预警' if trg else '正常'} | {'是' if trg else '否'} |")
R["mon_rows"] = mon_rows

# ============================================================================
# S11. 图表
# ============================================================================
sec("R11 生成 10 张图表")
C1 = "#1f77b4"; C2 = "#ff7f0e"; C3 = "#2ca02c"; C4 = "#d62728"; C5 = "#9467bd"; CG = "#7f7f7f"

# ---- chart01 数据覆盖与缺口 ----
fig, ax = plt.subplots(figsize=(13, 8))
series_rows = [
    ("沪深300(两段拼接)", EQ_RAW["沪深300"], None),
    ("中证500(两段拼接)", EQ_RAW["中证500"], None),
    ("创业板指(两段拼接)", EQ_RAW["创业板指"], None),
    ("标普500", SPX_RAW, None),
    ("USD/CNH(两段拼接)", FX_RAW, None),
    ("中债国债1Y", CGB_RAW["1Y"], None),
    ("中债国债2Y", CGB_RAW["2Y"], None),
    ("中债国债5Y", CGB_RAW["5Y"], None),
    ("中债国债10Y", CGB_RAW["10Y"], None),
    ("中债国债30Y", CGB_RAW["30Y"], None),
    ("Shibor(两段拼接)", _sh1w, None),
    ("DR007", DR_RAW, None),
    ("LPR_1Y", lpr1.set_index("date")["lpr_1y"].dropna(), None),
    ("LPR_5Y", lpr5.set_index("date")["lpr_5y"].dropna(), None),
    ("制造业PMI", pmi.set_index("date")["pmi_mfg"], "M"),
    ("社融存量", afre.set_index("date")["afre_stock"], "M"),
    ("PPI同比", ppi.set_index("date")["ppi_yoy"], "M"),
    ("美债10Y", UST10_RAW, None),
    ("美债M2", ustm2.set_index("date")["yield_pct"], None),
    ("美债M4", ustm4.set_index("date")["yield_pct"], None),
]
for i, (nm, s, _m) in enumerate(series_rows):
    y = len(series_rows) - i
    ax.barh(y, (s.index.max() - s.index.min()).days, left=s.index.min(), height=0.55,
            color=C1, alpha=0.75, edgecolor="none")
    if s.index.max() < ASOF:
        ax.barh(y, (ASOF - s.index.max()).days, left=s.index.max(), height=0.55,
                color="none", edgecolor=C4, hatch="////", alpha=0.9)
    if s.index.min() > TD[0]:
        ax.barh(y, (s.index.min() - TD[0]).days, left=TD[0], height=0.55, color=CG, alpha=0.35)
for nm, dt in [("沪深300", pd.Timestamp("2026-09-12")), ("中证500", pd.Timestamp("2026-09-12"))]:
    i = [j for j, (n_, _, _) in enumerate(series_rows) if n_.startswith(nm)][0]
    y = len(series_rows) - i
    ax.plot([dt], [y], marker="x", color=C4, ms=10, mew=2.5)
ax.axvline(ASOF, color="k", lw=1.5, ls="--")
ax.text(ASOF, len(series_rows) + 0.9, f" 分析截至日 {ASOF.date()}", va="bottom", fontsize=10)
ax.set_yticks(range(1, len(series_rows) + 1))
ax.set_yticklabels([n for n, _, _ in reversed(series_rows)], fontsize=9)
ax.set_xlim(TD[0] - pd.Timedelta(days=60), ASOF + pd.Timedelta(days=120))
ax.xaxis.set_major_locator(mdates.YearLocator())
ax.xaxis.set_major_formatter(mdates.DateFormatter("%Y"))
ax.set_title("图1 数据覆盖与缺口：各序列实际覆盖区间（蓝）、截断缺口（红斜线）、结构性起点前（灰）、"
             "休市日异常记录（×）", fontsize=11)
ax.legend(handles=[Patch(color=C1, alpha=.75, label="实际覆盖"),
                   Patch(facecolor="none", edgecolor=C4, hatch="////", label="截断/未发布缺口"),
                   Patch(color=CG, alpha=.35, label="序列起点前（结构性）"),
                   plt.Line2D([], [], marker="x", color=C4, ls="", ms=9, mew=2,
                              label="2026-09-12(周六)异常记录已剔除")],
          loc="lower right", fontsize=9)
fig.tight_layout()
fig.savefig(f"{CHART_DIR}/FIN3-WKN-149_chart01_数据覆盖与缺口.png", bbox_inches="tight")
plt.close(fig)

# ---- chart02 方案累计净值 ----
fig, ax = plt.subplots(figsize=(12, 6.5))
colors = {"当前组合": CG, "方案A": C2, "方案B": C3, "方案C": C5, "方案D(推荐)": C4}
for k in ["当前组合", "方案A", "方案B", "方案C", "方案D(推荐)"]:
    nav = np.cumprod(1 + PORT_S[k].values)
    ax.plot(PORT_S[k].index, nav, lw=1.3, color=colors[k],
            label=f"{k}（期末 {nav[-1]:.3f}）")
ax.axhline(1.0, color="k", lw=0.6, ls=":")
ax.set_title("图2 各方案历史累计净值（2018-01-03 至 2026-09-15，权重每日再平衡）")
ax.set_ylabel("累计净值（期初=1.000）")
ax.legend(fontsize=9)
ax.grid(alpha=0.3)
fig.tight_layout()
fig.savefig(f"{CHART_DIR}/FIN3-WKN-149_chart02_方案累计净值.png", bbox_inches="tight")
plt.close(fig)

# ---- chart03 风险指标与限额 ----
fig, axes = plt.subplots(1, 2, figsize=(12, 5.5))
names = list(PLAN_W.keys())
xs = np.arange(len(names))
for ax, key, limv, ttl in [
    (axes[0], "es99", LIM["L6_es99"], f"1日 ES99（限额 {LIM['L6_es99']*100:.1f}%）"),
    (axes[1], "var99_10", LIM["L7_var99_10"], f"10日 VaR99（限额 {LIM['L7_var99_10']*100:.1f}%）")]:
    vals = [STATS[k][key] * 100 for k in names]
    bars = ax.bar(xs, vals, color=[C4 if v > limv * 100 else C1 for v in vals], alpha=0.85)
    ax.axhline(limv * 100, color=C4, ls="--", lw=1.6, label="限额线")
    for b, v in zip(bars, vals):
        ax.text(b.get_x() + b.get_width() / 2, v + 0.05, f"{v:.2f}%", ha="center", fontsize=9)
    ax.set_xticks(xs)
    ax.set_xticklabels(names, fontsize=9)
    ax.set_title(ttl)
    ax.set_ylabel("%")
    ax.legend(fontsize=9)
fig.suptitle("图3 各组合历史风险指标与限额参考线（红色=超限）", y=1.0)
fig.tight_layout()
fig.savefig(f"{CHART_DIR}/FIN3-WKN-149_chart03_风险指标与限额.png", bbox_inches="tight")
plt.close(fig)

# ---- chart04 情景合格月份 ----
fig, ax = plt.subplots(figsize=(13, 4.6))
months_idx = {m: i for i, m in enumerate(IDENT_M)}
for si, s in enumerate(["S1", "S2", "S3", "S4"]):
    y = 3 - si
    for m in scen_months[s]:
        ax.plot([months_idx[m]], [y], marker="|", ms=14, mew=2.2,
                color=[C1, C2, C3, C4][si])
    ax.text(len(IDENT_M) + 1, y, f"{s} {SCEN_NAME[s]}（{len(scen_months[s])}个月）",
            va="center", fontsize=9)
ticks = [i for i, m in enumerate(IDENT_M) if m.month == 1]
ax.set_xticks(ticks)
ax.set_xticklabels([str(IDENT_M[i].year) for i in ticks])
ax.set_yticks([])
ax.set_xlim(-1, len(IDENT_M) + 22)
ax.set_title("图4 四情景月度识别结果（2018-02 至 2026-08；竖线=该月命中情景规则）")
ax.grid(axis="x", alpha=0.3)
fig.tight_layout()
fig.savefig(f"{CHART_DIR}/FIN3-WKN-149_chart04_情景合格月份.png", bbox_inches="tight")
plt.close(fig)

# ---- chart05 历史窗口校准冲击 ----
fig, axes = plt.subplots(1, 2, figsize=(13.5, 5.5))
scens = ["S1", "S2", "S3", "S4"]
xs = np.arange(4)
wd = 0.16
cols = [C1, C2, C3, C4, C5]
facnames = ["hs300", "zz500", "cyb", "spx", "fx"]
faclbl = ["沪深300", "中证500", "创业板", "标普500(USD)", "USDCNH"]
for j, (f, l) in enumerate(zip(facnames, faclbl)):
    vals = [CALIB[s]["fac"][f] * 100 for s in scens]
    axes[0].bar(xs + (j - 2) * wd, vals, wd, label=l, color=cols[j], alpha=0.85)
axes[0].axhline(0, color="k", lw=0.8)
axes[0].set_xticks(xs)
axes[0].set_xticklabels([f"{s}\n{SCEN_NAME[s]}" for s in scens], fontsize=9)
axes[0].set_ylabel("10日累计变动 %")
axes[0].set_title("价格/汇率类因子校准冲击（选定窗口中位数）")
axes[0].legend(fontsize=8)
axes[0].grid(axis="y", alpha=0.3)
for j, t in enumerate(TENORS):
    vals = [CALIB[s]["dy"][t] * 100 for s in scens]
    axes[1].bar(xs + (j - 2) * wd, vals, wd, label=t, color=cols[j], alpha=0.85)
axes[1].axhline(0, color="k", lw=0.8)
axes[1].set_xticks(xs)
axes[1].set_xticklabels([f"{s}\n{SCEN_NAME[s]}" for s in scens], fontsize=9)
axes[1].set_ylabel("10日累计变动 bp")
axes[1].set_title("中债国债各期限校准冲击（选定窗口中位数）")
axes[1].legend(fontsize=8)
axes[1].grid(axis="y", alpha=0.3)
fig.suptitle("图5 各情景历史窗口校准冲击（同类窗口不少于20个，取因子累计变动中位数）", y=1.0)
fig.tight_layout()
fig.savefig(f"{CHART_DIR}/FIN3-WKN-149_chart05_历史窗口校准冲击.png", bbox_inches="tight")
plt.close(fig)

# ---- chart06 两套冲击对比 ----
fig, ax = plt.subplots(figsize=(11, 6))
xs = np.arange(4)
wd = 0.35
dcomm = [-STRESS[("方案D(推荐)", s, "委员会沿用")]["total"] * 100 for s in scens]
dcal = [-STRESS[("方案D(推荐)", s, "历史校准")]["total"] * 100 for s in scens]
mx_all_comm = [max(-STRESS[(p, s, "委员会沿用")]["total"] for p in STRESS_PLANS) * 100 for s in scens]
mx_all_cal = [max(-STRESS[(p, s, "历史校准")]["total"] for p in STRESS_PLANS) * 100 for s in scens]
ax.bar(xs - wd / 2, dcomm, wd, label="委员会沿用冲击·推荐方案损失", color=C1, alpha=0.85)
ax.bar(xs + wd / 2, dcal, wd, label="历史校准冲击·推荐方案损失", color=C2, alpha=0.85)
ax.plot(xs - wd / 2, mx_all_comm, "v", color=C1, ms=9, label="委员会冲击·四方案最大损失")
ax.plot(xs + wd / 2, mx_all_cal, "v", color=C2, ms=9, label="校准冲击·四方案最大损失")
ax.axhline(LIM["L8_stress"] * 100, color=C4, ls="--", lw=1.6, label=f"L8 压力损失上限 {LIM['L8_stress']*100:.0f}%")
ax.axhline(LIM["L9_stress_rec"] * 100, color=C4, ls=":", lw=1.6, label=f"L9 推荐缓冲线 {LIM['L9_stress_rec']*100:.0f}%")
ax.set_xticks(xs)
ax.set_xticklabels([f"{s}\n{SCEN_NAME[s]}" for s in scens], fontsize=9)
ax.set_ylabel("压力损失 %（正=损失）")
ax.set_title("图6 委员会沿用冲击 vs 历史校准冲击：严格程度对比")
ax.legend(fontsize=8.5, ncol=2)
ax.grid(axis="y", alpha=0.3)
fig.tight_layout()
fig.savefig(f"{CHART_DIR}/FIN3-WKN-149_chart06_两套冲击对比.png", bbox_inches="tight")
plt.close(fig)

# ---- chart07 方案决策与限额 ----
fig, ax = plt.subplots(figsize=(10.5, 6))
names = list(PLAN_W.keys())
vals = [MAXLOSS[k][0] * 100 for k in names]
srcs = [MAXLOSS[k][1] for k in names]
bars = ax.bar(names, vals, color=[C4 if v > LIM["L8_stress"] * 100 else
                                   (C2 if v > LIM["L9_stress_rec"] * 100 else C3) for v in vals], alpha=0.85)
ax.axhline(LIM["L8_stress"] * 100, color=C4, ls="--", lw=1.8,
           label=f"L8 最大压力损失上限 {LIM['L8_stress']*100:.0f}%")
ax.axhline(LIM["L9_stress_rec"] * 100, color=C2, ls=":", lw=1.8,
           label=f"L9 推荐方案缓冲线 {LIM['L9_stress_rec']*100:.0f}%")
for b, v, s_ in zip(bars, vals, srcs):
    ax.text(b.get_x() + b.get_width() / 2, v + 0.12, f"{v:.2f}%\n({s_[0]}/{s_[1][:3]})",
            ha="center", fontsize=8.5)
ax.set_ylabel("最大压力损失 %（4情景×2套冲击）")
ax.set_ylim(0, max(vals) * 1.25)
ax.set_title("图7 各方案最大压力损失与限额线")
ax.legend(fontsize=9)
ax.grid(axis="y", alpha=0.3)
fig.tight_layout()
fig.savefig(f"{CHART_DIR}/FIN3-WKN-149_chart07_方案决策与限额.png", bbox_inches="tight")
plt.close(fig)

# ---- chart08 调仓现金路径 ----
fig, ax = plt.subplots(figsize=(10.5, 6))
x_lbl = ["初始", "步骤1", "步骤2", "步骤3", "步骤4", "完成"]
ax.plot(range(len(path_sell_first)), [x * 100 for x in path_sell_first], "o-", color=C3, lw=2,
        label="先卖出后买入（规则顺序）")
ax.plot(range(len(path_buy_first)), [x * 100 for x in path_buy_first], "s--", color=C4, lw=2,
        label="先买入后卖出（对照）")
ax.axhline(CASH_FLOOR * 100, color=C4, ls=":", lw=2, label=f"现金下限 {CASH_FLOOR*100:.0f}%")
for i, (a, b) in enumerate(zip(path_sell_first, path_buy_first)):
    ax.annotate(f"{a*100:.2f}%", (i, a * 100), textcoords="offset points", xytext=(0, 9),
                ha="center", fontsize=9, color=C3)
    ax.annotate(f"{b*100:.2f}%", (i, b * 100), textcoords="offset points", xytext=(0, -16),
                ha="center", fontsize=9, color=C4)
ax.set_xticks(range(len(path_sell_first)))
ax.set_xticklabels(["初始", "第1笔", "第2笔", "第3笔", "第4笔(完成)"], fontsize=9)
ax.set_ylabel("人民币现金及货基占比 %")
ax.set_title("图8 调仓执行现金占比路径（先卖后买 vs 先买后卖，8% 下限线）")
ax.legend(fontsize=9)
ax.grid(alpha=0.3)
fig.tight_layout()
fig.savefig(f"{CHART_DIR}/FIN3-WKN-149_chart08_调仓现金路径.png", bbox_inches="tight")
plt.close(fig)

# ---- chart09 反向压力测试 ----
fig, axes = plt.subplots(1, 2, figsize=(13.5, 5.8))
zs = R["rev"]["z_star"]
lbl5 = ["沪深300", "中证500", "创业板", "标普500USD", "USDCNH"]
xs = np.arange(5)
worst_set = R["rev"]["srcD"]
zw = R["rev"]["DIST"][worst_set][2]
axes[0].bar(xs - 0.2, [zs[i] * 100 for i in range(5)], 0.4, label="反向压力情景（最可能，D最小）", color=C4, alpha=0.85)
axes[0].bar(xs + 0.2, [zw[i] * 100 for i in range(5)], 0.4,
            label=f"推荐方案最大损失情景（{worst_set[0]}/{worst_set[1]}）", color=C1, alpha=0.85)
axes[0].axhline(0, color="k", lw=0.8)
axes[0].set_xticks(xs)
axes[0].set_xticklabels(lbl5, fontsize=9)
axes[0].set_ylabel("10日累计变动 %")
axes[0].set_title(f"价格/汇率因子对比（反向情景损失={TARGET*100:.0f}%，D={R['rev']['D_star']:.2f}）")
axes[0].legend(fontsize=8.5)
axes[0].grid(axis="y", alpha=0.3)
items = [("反向压力情景", R["rev"]["D_star"], zs[5] * 100)]
for s in scens:
    items.append((f"{s}委员会", R["rev"]["DIST"][(s, "委员会沿用")][0],
                  R["rev"]["DIST"][(s, "委员会沿用")][2][5] * 100))
    items.append((f"{s}校准", R["rev"]["DIST"][(s, "历史校准")][0],
                  R["rev"]["DIST"][(s, "历史校准")][2][5] * 100))
items.append(("历史最差窗口", R["rev"]["D_hist_max"], R["rev"]["Z"][int(np.argmax(R["rev"]["Z"] @ c_lin + q_bi * R["rev"]["Z"][:, 3] * R["rev"]["Z"][:, 4]))][5] * 100))
xs2 = np.arange(len(items))
axes[1].bar(xs2, [it[1] for it in items], color=[C4 if it[0] == "反向压力情景" else C1 for it in items], alpha=0.8)
for i2, it in enumerate(items):
    axes[1].text(i2, it[1] + 0.08, f"D={it[1]:.2f}\nΔy={it[2]:+.0f}bp", ha="center", fontsize=7.6)
axes[1].set_xticks(xs2)
axes[1].set_xticklabels([it[0] for it in items], rotation=40, ha="right", fontsize=8.5)
axes[1].set_ylabel("马氏距离 D")
axes[1].set_title("各情景马氏距离（越近=越“可能”）")
axes[1].grid(axis="y", alpha=0.3)
fig.suptitle("图9 反向压力测试：触及7%缓冲线的最小马氏距离情景 vs 既有情景", y=1.0)
fig.tight_layout()
fig.savefig(f"{CHART_DIR}/FIN3-WKN-149_chart09_反向压力测试.png", bbox_inches="tight")
plt.close(fig)

# ---- chart10 监测指标触发状态 ----
fig, axes = plt.subplots(2, 4, figsize=(15, 7))
mon_info = []
for (mid, v, asof, trg), (_, row) in zip(mon_rows, monitor_tpl.iterrows()):
    thr = parse_thr(row["threshold"])
    below = "低于" in row["direction"]
    mon_info.append((mid, row["indicator"], row["threshold"], v, thr, trg, below, asof))
for ax, (mid, ind, thrtxt, v, thr, trg, below, asof) in zip(axes.ravel(), mon_info):
    is_bp = mid in ("M3", "M4", "M5")
    disp_v = v * 100 if is_bp else (v * 100 if mid in ("M1", "M2", "M8") else v)
    disp_t = thr * 100 if is_bp else (thr * 100 if mid in ("M1", "M2", "M8") else thr)
    unit = "bp" if is_bp else ("%" if mid in ("M1", "M2", "M8") else "")
    ax.bar([0], [disp_v], color=C4 if trg else C3, alpha=0.85, width=0.5)
    ax.axhline(disp_t, color=C4, ls="--", lw=1.8)
    ax.text(0, disp_v, f" {disp_v:+.2f}{unit}", ha="center",
            va="bottom" if disp_v >= 0 else "top", fontsize=9)
    ax.text(0.42, disp_t, f" 阈值{thrtxt}", ha="right", va="bottom", fontsize=8, color=C4)
    ax.set_title(f"{mid} {ind}\n截至{pd.Timestamp(asof).date()}：{'触发' if trg else '正常'}",
                 fontsize=9.5, color=C4 if trg else "#222222")
    ax.set_xticks([])
    ax.grid(axis="y", alpha=0.3)
    lo, hi = min(disp_v, disp_t), max(disp_v, disp_t)
    pad = max(abs(hi - lo) * 0.6, abs(hi) * 0.25 + 0.1)
    ax.set_ylim(lo - pad, hi + pad)
fig.suptitle("图10 八个监测指标最新值与阈值（红=触发，绿=正常）", y=1.0)
fig.tight_layout()
fig.savefig(f"{CHART_DIR}/FIN3-WKN-149_chart10_监测指标触发状态.png", bbox_inches="tight")
plt.close(fig)

print("已生成 10 张图表于", CHART_DIR)
for f in sorted(os.listdir(CHART_DIR)):
    print("  ", f)

sec("完成：以上全部数值可由本脚本从 input_files 原始快照复算")
